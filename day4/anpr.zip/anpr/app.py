# coding: utf-8
"""Two-stage sensor LPR inference using a rolling-buffer pipeline.

- stage1: sensor input, rolling-buffer master
- stage2: sensor input, rolling-buffer slave

The slave consumes exactly one synchronization token per stage1 result. When
stage1 finds no plate, stage2 receives a dummy request instead of running NPU
inference so that the master/slave pipeline stays in lockstep.
"""

import queue
import threading
from pathlib import Path

import cv2
import numpy as np

import tachy_rt.core.functions as rt_core
from inference.tachy_inference_helper import TachyInferenceHelper
from lpr.lpr_serializer_v2 import Serializer


def recover_stale_runtime(
    interface,
    master_name,
    slave_name,
    input_h,
    input_w,
    rolling_buf_num,
):
    """Release a stale rolling sync queue, then remove old instances."""
    # A stale master can block runtime-side instance destruction in put_sync().
    # reset=True resets every sensor TX and invalidates the shared sync queue,
    # allowing the following deinit requests to complete. The normal setup
    # below configures the master/slave sensors again after this cleanup pass.
    ratio = rt_core.get_sensor_ratio(input_h, input_w)
    if not rt_core.enable_sensor(
        interface,
        2,
        ratio,
        ratio,
        dtype=rt_core.DTYPE_FLOAT16,
        rolling_buf=True,
        rolling_buf_num=rolling_buf_num,
        rolling_buf_rule=rt_core.ROLLING_BUF_MASTER,
        inverse_data=False,
        reset=True,
    ):
        err = rt_core.get_last_error_code()
        raise RuntimeError("startup sensor reset failed (error: {})".format(err))

    # Stop the master while the reset-created sync queue is still valid, then
    # remove the dependent slave. A missing instance is normal on first run.
    for name in (master_name, slave_name):
        rt_core.deinit_instance(interface, name)


def open_camera(device, width, height, fps):
    cap = cv2.VideoCapture(device, cv2.CAP_V4L2)
    if not cap.isOpened():
        raise RuntimeError("카메라 열기 실패")
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"YUYV"))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    return cap


def draw_annotations(frame, anno, scale_x, scale_y, labels, colors):
    """Draw stage1 annotations expressed in the REF coordinate space."""
    if anno is None or len(anno) == 0:
        return frame

    h, w = frame.shape[:2]
    for det in anno:
        prob = float(det[0])
        cls = int(det[1])
        x0 = int(round(det[2] * scale_x))
        y0 = int(round(det[3] * scale_y))
        x1 = int(round(det[4] * scale_x))
        y1 = int(round(det[5] * scale_y))

        x0 = max(0, min(x0, w - 1))
        y0 = max(0, min(y0, h - 1))
        x1 = max(0, min(x1, w - 1))
        y1 = max(0, min(y1, h - 1))

        label = labels[cls] if 0 <= cls < len(labels) else str(cls)
        color = colors[cls % len(colors)]
        cv2.rectangle(frame, (x0, y0), (x1, y1), color, 2)
        cv2.putText(
            frame,
            "{} {:.2f}".format(label, prob),
            (x0, max(12, y0 - 5)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            color,
            1,
            cv2.LINE_AA,
        )
    return frame


def stage1_producer(stage1, stop, submitted):
    """Submit stage1 requests and publish one token per successful request."""
    try:
        while not stop.is_set():
            stage1.process()
            submitted.put(True)
            stop.wait(0.001)
    finally:
        # FIFO ordering guarantees that the consumer drains every submitted
        # master request before it sees this sentinel.
        submitted.put(None)


def stage1_result_worker(
    stage1,
    submitted,
    stage2_jobs,
    shared,
    ref_w,
    ref_h,
    plate_class,
):
    """Receive/decode stage1 results and enqueue ordered stage2 jobs."""
    full_frame = np.array([[0, 0, ref_w - 1, ref_h - 1]], dtype=np.float32)

    try:
        while True:
            token = submitted.get()
            if token is None:
                break

            result1 = stage1.get_result()
            anno = stage1.decode(result1, full_frame)
            plates = anno[anno[:, 1] == plate_class] if len(anno) else anno

            with shared["lock"]:
                shared["anno"] = anno

            # Never discard or overwrite a job: rolling-buffer slave requests
            # must consume master sync tokens in the same FIFO order.
            stage2_jobs.put(plates)
    finally:
        stage2_jobs.put(None)


def stage2_worker(stage2, stage2_jobs, serializer, ref_w, ref_h):
    """Consume ordered stage1 jobs and run one matching slave request each."""
    while True:
        plates = stage2_jobs.get()
        if plates is None:
            break

        n_plate = len(plates)
        if n_plate < 1:
            # The rolling-buffer slave must consume one sync token for every
            # master result, even when there is no plate to infer.
            stage2.instance.process(n_batch=0)
            stage2.get_result()
            continue

        boxes = plates[:, 2:6].copy()
        boxes[:, 0::2] = np.clip(boxes[:, 0::2], 0, ref_w - 1)
        boxes[:, 1::2] = np.clip(boxes[:, 1::2], 0, ref_h - 1)
        crop_boxes = boxes.astype(np.int32)

        crop = np.empty((1, n_plate, 4), dtype=np.int32)
        crop[0][:] = crop_boxes
        raw = np.empty((1, 3), dtype=np.int32)
        raw[0][:] = [ref_h, ref_w, 3]
        data = [[None] for _ in range(n_plate)]

        stage2.instance.process(
            data=data,
            n_batch=1,
            raw=raw,
            crop=crop,
        )
        result2 = stage2.get_result()
        chars = stage2.decode(result2, crop_boxes.astype(np.float32))

        strings = serializer.main(plates, chars)
        print("--------------")
        for row in strings:
            print(row[0].decode("utf-8"))


def main(max_frames=None):
    project_root = Path(__file__).resolve().parent
    config_dir = project_root / "configs"
    model_dir = project_root / "models"
    interface = "spi:host"
    master_name = "stage1_master"
    slave_name = "stage2_slave"
    rolling_buf_num = 5

    serializer = Serializer({
        "BASE_CTG_FILE": str(config_dir / "category2index_DPI-CD-81_OCR.json")
    })

    # Camera, annotation reference, and display coordinate spaces.
    cam_device = "/dev/video0"
    cam_w, cam_h, cam_fps = 1920, 1080, 30
    ref_w, ref_h = 1920, 1080
    display_w, display_h = 960, 540
    labels = ("plate", "car", "human")
    colors = ((0, 255, 0), (255, 0, 0), (0, 0, 255))
    plate_class = labels.index("plate")
    stage1_input_h, stage1_input_w = 160, 288

    # Unblock stale rolling-buffer workers and clean up their instances before
    # creating the new master/slave pipeline.
    recover_stale_runtime(
        interface,
        master_name,
        slave_name,
        stage1_input_h,
        stage1_input_w,
        rolling_buf_num,
    )

    # Stage1: sensor rolling-buffer master.
    stage1 = TachyInferenceHelper(
        model_path=str(model_dir / "model_160x288x3_inv-f.tachyrt"),
        post_config_path=str(config_dir / "post_stage1.json"),
        itf=interface,
        name=master_name,
        input_method=rt_core.INPUT_FMT_SENSOR,
        rolling_buf=True,
        rolling_buf_num=rolling_buf_num,
        rolling_buf_rule=rt_core.ROLLING_BUF_MASTER,
        reorder=False,
    )
    stage1.setup()

    # Stage2: sensor rolling-buffer slave. reset=False keeps the master sensor
    # configuration intact while enabling the second sensor channel.
    stage2 = TachyInferenceHelper(
        model_path=str(model_dir / "model_80x192x3_inv-f.tachyrt"),
        post_config_path=str(config_dir / "post_stage2.json"),
        itf=interface,
        name=slave_name,
        input_method=rt_core.INPUT_FMT_SENSOR,
        rolling_buf=True,
        rolling_buf_num=rolling_buf_num,
        rolling_buf_rule=rt_core.ROLLING_BUF_SLAVE,
        reset=False,
        reorder=False,
    )
    stage2.setup()

    cap = open_camera(cam_device, cam_w, cam_h, cam_fps)
    scale_x = display_w / float(ref_w)
    scale_y = display_h / float(ref_h)

    stop = threading.Event()
    submitted = queue.Queue()
    # BS3 rolling sync capacity is rolling_buf_num - 2. Keeping the same
    # bound prevents host jobs from running ahead of retained sensor frames.
    stage2_jobs = queue.Queue(maxsize=max(1, rolling_buf_num - 2))
    shared = {"lock": threading.Lock(), "anno": None}

    producer = threading.Thread(
        target=stage1_producer,
        args=(stage1, stop, submitted),
        daemon=True,
    )
    stage1_results = threading.Thread(
        target=stage1_result_worker,
        args=(
            stage1,
            submitted,
            stage2_jobs,
            shared,
            ref_w,
            ref_h,
            plate_class,
        ),
        daemon=True,
    )
    stage2_results = threading.Thread(
        target=stage2_worker,
        args=(stage2, stage2_jobs, serializer, ref_w, ref_h),
        daemon=True,
    )
    stage2_results.start()
    stage1_results.start()
    producer.start()

    n = 0
    try:
        while not stop.is_set():
            ok, frame = cap.read()
            if not ok:
                print("프레임 읽기 실패")
                break

            with shared["lock"]:
                anno = shared["anno"]

            disp = cv2.resize(frame, (display_w, display_h))
            draw_annotations(disp, anno, scale_x, scale_y, labels, colors)
            cv2.imshow("LPR v2: sensor master + sensor slave", disp)
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord("q")):
                stop.set()
                break

            n += 1
            if max_frames is not None and n >= max_frames:
                break
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        # Both workers keep draining until every submitted master request has
        # one matching real or dummy slave request.
        producer.join()
        stage1_results.join()
        stage2_results.join()

        # No rolling-buffer request remains, so runtime-side instance workers
        # can now terminate without blocking in the shared sync queue.
        rt_core.deinit_instance(interface, master_name)
        rt_core.deinit_instance(interface, slave_name)
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
