"""Shared utilities for inference and LPR post-processing."""
