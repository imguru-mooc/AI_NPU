"""License-plate recognition post-processing."""
