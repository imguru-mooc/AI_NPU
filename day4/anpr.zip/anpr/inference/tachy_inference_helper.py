# coding: utf-8

import copy
import io
import json
import os
from typing import Optional

import numpy as np
from . import trt_parser
from .yolov4 import Decoder

import tachy_rt.core.functions as rt_core

BASE_INF_CFG = {
    "global": {
        "name": "example...",
        "data_type": rt_core.DTYPE_FLOAT16,
        "buf_num": 5,
        "max_batch": 5,
        "npu_mask": -1,
    },
    "input": [
        {
            "method": rt_core.INPUT_FMT_SENSOR,
            "std": 255.0,
            "mean": 0.0,
            "tx": -1,
        }
    ],
    "output": {
        "reorder": True,
    }
}


class TachyInferenceHelper:
    """Inference helper for tachy_rt.

    Usage:
        helper = TachyInferenceHelper(
            model_path="/Path/to/model_160x288x3_inv-f.tachyrt",
            post_config_path="/Path/to/post_stage1.json",
            input_method=rt_core.INPUT_FMT_SENSOR,
            rolling_buf=True,
            rolling_buf_num=5,
            rolling_buf_rule=rt_core.ROLLING_BUF_MASTER,
        )
        helper.setup()
        helper.process()                    # 요청 (producer)
        result = helper.get_result()        # 수신 (consumer, blocking)
        anno = helper.decode(result, reference)

    - process() 와 get_result() 는 한 타임에 묶지 않는다. 멀티스레딩에서는
      producer 스레드가 keep_requesting() 으로 process() 를 계속 던지고,
      consumer 스레드가 get_result()/decode() 로 결과를 소비한다.
    - One helper handles one model. Use multiple instances for multiple stages.
    - Sensor tx is auto-allocated only for sensor inputs: first helper tx=2,
      second sensor helper tx=3, third raises.
    - Binary/JPEG inputs do not enable or allocate a sensor channel.
    - ratio is auto-computed: default/Master -> rt_core.get_sensor_ratio(h, w)
      from SHAPES_INPUT of the post config, Slave -> 1 (same as main.py).
    """

    # auto tx allocation: 2 -> 3, then error
    _next_tx = 2
    _max_tx = 3

    def __init__(self,
                 model_path: str,
                 post_config_path: str,
                 itf: str = "spi:host",
                 name: Optional[str] = None,
                 rolling_buf: bool = False,
                 rolling_buf_num: Optional[int] = None,
                 rolling_buf_rule: Optional[int] = None,  # rt_core.ROLLING_BUF_MASTER / SLAVE
                 dtype: int = rt_core.DTYPE_FLOAT16,
                 reset: bool = True,
                 input_method: int = rt_core.INPUT_FMT_SENSOR,
                 reorder: bool = True) -> None:
        self.model_path = model_path
        self.post_config_path = post_config_path
        self.itf = itf
        # name: auto-generate from model filename when not given
        self.name = name if name else os.path.splitext(os.path.basename(model_path))[0]
        self.dtype = dtype
        self.reset = reset
        self.input_method = input_method
        self.reorder = reorder

        supported_input_methods = (
            rt_core.INPUT_FMT_BINARY,
            rt_core.INPUT_FMT_SENSOR,
            rt_core.INPUT_FMT_JPEG,
        )
        if self.input_method not in supported_input_methods:
            raise ValueError("unsupported input_method: {}".format(self.input_method))

        self.rolling_buf = rolling_buf
        self.rolling_buf_num = rolling_buf_num
        self.rolling_buf_rule = rolling_buf_rule
        if self.rolling_buf:
            if self.rolling_buf_num is None:
                self.rolling_buf_num = 5
            if self.rolling_buf_rule is None:
                raise ValueError("rolling_buf=True requires rolling_buf_rule "
                                 "(rt_core.ROLLING_BUF_MASTER or rt_core.ROLLING_BUF_SLAVE)")
            if self.rolling_buf_rule not in (rt_core.ROLLING_BUF_MASTER,
                                             rt_core.ROLLING_BUF_SLAVE):
                raise ValueError("rolling_buf_rule must be rt_core.ROLLING_BUF_MASTER "
                                 "or rt_core.ROLLING_BUF_SLAVE")
            if self.input_method != rt_core.INPUT_FMT_SENSOR:
                raise ValueError("rolling_buf is supported only for sensor input")

        # Sensor inputs consume a physical tx channel; image inputs do not.
        self.tx = (self._allocate_tx()
                   if self.input_method == rt_core.INPUT_FMT_SENSOR else -1)

        self.post_cfg = {}
        self.cfg = {}
        self.instance = None
        self.decoder = None
        self.output_dim = 0 # prob(1) + classes(N) + bbox(4)

    # -------------------------------------------------------------- private
    @classmethod
    def _allocate_tx(cls):
        if cls._next_tx > cls._max_tx:
            raise RuntimeError("no sensor tx available: at most 2 helpers "
                               "(tx=2, tx=3) are supported")
        tx = cls._next_tx
        cls._next_tx += 1
        return tx

    @staticmethod
    def _load_json(path):
        with io.open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _make_cfg(self):
        cfg = copy.deepcopy(BASE_INF_CFG)
        cfg["global"]["name"] = self.name
        cfg["input"][0]["method"] = self.input_method
        cfg["output"]["reorder"] = self.reorder
        if self.rolling_buf:
            cfg["global"]["buf_num"] = self.rolling_buf_num
        return cfg

    def _get_ratio(self):
        if self.rolling_buf and self.rolling_buf_rule == rt_core.ROLLING_BUF_SLAVE:
            return 1  # rolling buf slave: ratio = 1 (same as main.py)
        h, w = self.post_cfg["SHAPES_INPUT"][:2]
        return rt_core.get_sensor_ratio(h, w)

    def _enable_sensor(self):
        ratio = self._get_ratio()
        kwargs = {
            "dtype": self.dtype,
            "rolling_buf": self.rolling_buf,
            "inverse_data": False,
            "reset": self.reset,
        }
        self.cfg["input"][0]["tx"] = self.tx
        if self.rolling_buf:
            kwargs["rolling_buf_rule"] = self.rolling_buf_rule
        if not rt_core.enable_sensor(self.itf, self.tx, ratio, ratio, **kwargs):
            err = rt_core.get_last_error_code()
            raise RuntimeError("enable sensor fail (tx: {}, error: {})".format(
                self.tx, err
            ))

    def _load_model(self):
        rt_core.save_model(self.itf, self.name,
                           rt_core.MODEL_STORAGE_MEMORY,
                           self.model_path, overwrite=True)

    def _make_instance(self):
        ret = rt_core.make_instance(self.itf, self.name, self.name,
                              "frame_spliter", self.cfg)
        if not ret:
            err = rt_core.get_last_error_code()
            raise RuntimeError("make instance fail (error: {})".format(err))
        return ret

    def _connect_instance(self):
        ret, instance = rt_core.connect_instance(self.itf, self.name)
        if not ret:
            err = rt_core.get_last_error_code()
            rt_core.deinit_instance(self.itf, self.name)
            raise RuntimeError("connect instance fail (error: {})".format(err))
        return instance

    def _make_decoder(self):
        return Decoder(self.post_cfg)

    def _update_post_config(self):
        output_shape = []
        len_anchors = []
        desc = {}
        anchors = self.post_cfg["ANCHORS"]
        
        for i in range(len(anchors)):
            len_anchors.append(len(anchors[i]))
        _,_,desc,_= trt_parser.load_model(self.model_path)

        for i in range(desc['n_block']):
            if desc['blocks'][i]['is_logit']:
                output_shape.append(desc['blocks'][i]['output_shape'])
        for i in range(len(output_shape)):
            output_shape[i][2] = int(output_shape[i][2] / len_anchors[i])
        self.post_cfg["SHAPES_OUTPUT"] = output_shape
        self.post_cfg["SHAPES_INPUT"] = desc['blocks'][0]['input_shape']
        self.output_dim = desc['blocks'][-1]['output_shape'][-1]

    # --------------------------------------------------------------- public
    def setup(self):
        self.post_cfg = self._load_json(self.post_config_path)  # 1. post config
        self._update_post_config()
        
        # 2. tx: already allocated in __init__ -> self.tx
        self.cfg = self._make_cfg()                              # 3. cfg

        if self.input_method == rt_core.INPUT_FMT_SENSOR:
            self._enable_sensor()                                # 4. sensor enable
        self._load_model()                                       # 5. model save
        rt_core.deinit_instance(self.itf, self.name)             # 6. deinit old instance
        self._make_instance()                                    # 7. make instance
        self.instance = self._connect_instance()                 #    connect instance
        self.decoder = self._make_decoder()                      # 8. decoder
        return self

    def process(self, data=None, n_batch=1, raw=None, crop=None):
        """Submit ONE inference request (non-blocking).

        멀티스레딩 파이프라인에서는 process() 와 get_result() 를 한 타임에
        묶지 않는다. NPU 큐(rolling buf)를 채우기 위해 producer 쪽에서
        process() 를 계속 호출하고, consumer 쪽에서 get_result()/decode() 로
        결과를 소비한다. keep_requesting() 참고.
        """
        self.instance.process(data=data, n_batch=n_batch, raw=raw, crop=crop)

    def keep_requesting(self, stop_event, interval: float = 0.0):
        """process() 를 stop_event 가 set 될 때까지 계속 요청 (producer 루프).

        별도 스레드에서 실행해 NPU 파이프라인을 항상 채워 둔다.
        interval 이 0 이면 tight loop, 양수면 그 간격만큼 쉬며 요청한다.
        """
        while not stop_event.is_set():
            self.process()
            if interval:
                stop_event.wait(interval)

    def get_result(self):
        """Block until the NPU finishes one request; return the result dict."""
        return self.instance.get_result()  # wait until npu done, return is logit information

    def decode(self, result, reference):
        """get_result() 로 얻은 result 하나를 annotation 으로 디코드.

        get_result() 를 내부에서 호출하지 않는다 (process/get_result 분리).
        """
        return self.decoder.main(result["buf"].reshape(-1, self.output_dim), reference)


if __name__ == "__main__":
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # stage1 - object detection (yolov4), rolling buf master
    stage1 = TachyInferenceHelper(
        os.path.join(project_root, "models", "model_160x288x3_inv-f.tachyrt"),
        os.path.join(project_root, "configs", "post_stage1.json"),
    )

    stage1.setup()

    for i in range(10):
        stage1.process()
        result = stage1.get_result()
        anno = stage1.decode(
            result, np.array([[0, 0, 1920 - 1, 1080 - 1]], dtype=np.float32)
        )
        boxes = anno[..., 2:6]
        print("[INFO] Inference count:", i, "\tresults:", boxes)
