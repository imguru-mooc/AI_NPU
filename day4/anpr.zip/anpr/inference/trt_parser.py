import argparse

import numpy as np
import commentjson

from easydict import EasyDict

def parse_args():
    parser = argparse.ArgumentParser(description="TachyRT instruction copier")
    parser.add_argument(
        "--model-path", required=True,
        help="tachyrt 모델 파일 경로"
    )
    return parser.parse_args()



#####################
### tachyrt parse ###
#####################

partition = {
    "header": 0,
    "instruction": 1,
    "descriptor": 2,
    "parameter": 3
}

def _parse_header(data):
    '''
    1. header data(name) -> 30 byte
    2. header data(date) -> 14 byte
    2. header data(bs_ver) -> 4 byte
    3. header data(rt_ver) -> 4 byte
    '''
    _header = commentjson.loads(data.tobytes().decode())
    return _header

def _parse_instruction(data):
    '''
    1. instruction data
    '''
    _instruction = data[:]
    return _instruction


def _parse_descriptor(data):
    '''
    1. descriptor layer len
    2. descriptor data
    '''
    _descriptor = EasyDict(commentjson.loads(data.tobytes().decode()))

    # _n_block = _descriptor.n_block
    # _input_format = _descriptor.input_format
    # _input_block  = _descriptor.input_block
    # _input_shape  = _descriptor.input_shape
    # _output_block = _descriptor.output_block
    # _output_shape = _descriptor.output_shape
    return _descriptor

def _parse_parameter(data):
    '''
    1. parameter data
    '''
    _parameter = data[:]

    return _parameter

def load_model(file):
    data = np.fromfile(file, np.uint8)

    offset = 0
    header = {} 
    instr = ""
    desc = {}
    param = ""
    while offset < data.nbytes:
        part, length = data[offset:offset+8].view(np.uint32)[:2]
        offset += 8

        if partition["header"] == part:
            header = _parse_header(data[offset:offset+length])
        elif partition["instruction"] == part:
            instr = _parse_instruction(data[offset:offset+length])
        elif partition["descriptor"] == part:
            desc = _parse_descriptor(data[offset:offset+length])
        elif partition["parameter"] == part:
            param = _parse_parameter(data[offset:offset+length])

        # _parse(partition, data[offset:offset + length])
        offset += length
    return header, instr, desc, param

if __name__ == "__main__":
    args = parse_args()
    header, instr, desc, param = load_model(args.model_path)
    print(desc)
