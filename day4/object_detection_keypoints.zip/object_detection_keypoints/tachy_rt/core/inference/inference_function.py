import copy
import numpy as np
from easydict import EasyDict
from tachy_rt.core.sender import *
from tachy_rt.core.inference.instance.instance_frame_spliter import instance_fs
from tachy_rt.core.inference.instance.instance_standalone import StandaloneReader
from tachy_rt.utils.logger import *
from tachy_rt.utils.constants import *
from tachy_rt.utils.app_class import *
from tachy_rt.utils.functions_global import *
from tachy_rt.interface.interface_spi import SPI as itf_spi
from tachy_rt.interface.interface_tcp_c import TCP as itf_tcp_c
from tachy_rt.interface.interface_pipe import PIPE as itf_pipe
from tachy_rt.interface.interface_uds_c import UDS_C as itf_uds_c

req_inf = {}
req_inf["channel"] = {}
req_inf["function"] = "inference"
req_inf["parameter"] = {}

def _make_instance(interface:str, model:str, instance:str, algorithm:str, config:dict, mode:int=STATUS_MANUAL):
    request_json = copy.deepcopy(req_inf)
    request_json["sub_function"] = "make_instance"
    request_json["channel"] = set_interface(interface)

    request_json["parameter"]["name_model"] = model
    request_json["parameter"]["name_instance"] = instance
    request_json["parameter"]["name_algorithm"] = algorithm
    request_json["parameter"]["config"] = config
    request_json["parameter"]["mode"] = mode

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, interface)

    return code, status

def _make_standalone_instance(interface:str,
                              model:str,
                              instance:str,
                              algorithm:str,
                              config:dict,
                              spi_type:str="host",
                              poll_interval:float=0.005):
    code, status = _make_instance(interface,
                                  model,
                                  instance,
                                  algorithm,
                                  config,
                                  mode=STATUS_AUTO)
    if not status:
        return code, False, None

    try:
        output = config.get("output", {})
        post_process = output.get("post_process", {})
        effective_reorder = output.get("reorder", False)
        if post_process.get("type"):
            effective_reorder = True

        reader = StandaloneReader(instance,
                                  spi_type=spi_type,
                                  poll_interval=poll_interval,
                                  reorder=effective_reorder)
    except Exception as exc:
        logger.error("Failed to initialize standalone reader: {}".format(exc))
        _deinit_instance(interface, instance)
        return ERROR_INF_MI_STANDALONE_MEMORY, False, None

    return code, True, reader

def _connect_instance(interface:str, instance:str):
    request_json = copy.deepcopy(req_inf)
    request_json["sub_function"] = "connect_instance"
    request_json["channel"] = set_interface(interface)

    request_json["parameter"]["name_instance"] = instance
    if "local" in interface:
        request_json["parameter"]["frontend"] = {
            # "mode": INTERFACE_PIPE,
            "mode": INTERFACE_UDS_SERVER,
            "name": os.path.join('/tmp', get_random_string(10))
        }
        request_json["parameter"]["backend"] = {
            # "mode": INTERFACE_PIPE,
            "mode": INTERFACE_UDS_SERVER,
            "name": os.path.join('/tmp', get_random_string(10))
        }
        # itf_fe = itf_pipe(request_json["parameter"]["frontend"])
        # itf_be = itf_pipe(request_json["parameter"]["backend"])
        itf_fe = itf_uds_c(request_json["parameter"]["frontend"])
        itf_be = itf_uds_c(request_json["parameter"]["backend"])
    elif "ethernet" in interface or "tcp" in interface:
        request_json["parameter"]["frontend"] = {
            "mode": INTERFACE_TCP_SERVER,
            "ip": interface.split(":")[-1],
            "port": random.randrange(41000, 42000)
        }
        request_json["parameter"]["backend"] = {
            "mode": INTERFACE_TCP_SERVER,
            "ip": interface.split(":")[-1],
            "port": random.randrange(41000, 42000)
        }
        itf_fe = itf_tcp_c(request_json["parameter"]["frontend"])
        itf_be = itf_tcp_c(request_json["parameter"]["backend"])
    elif "spi" in interface:
        request_json["parameter"]["frontend"] = {
            "type": interface.split(":")[-1],
            "mode": INTERFACE_SPI,
            "interval_read": 5,
            "interval_write": 5,
            "interval_tmout": 0
        }
        request_json["parameter"]["backend"] = {
            "type": interface.split(":")[-1],
            "mode": INTERFACE_SPI,
            "interval_read": 5,
            "interval_write": 5,
            "interval_tmout": 0
        }
        itf_fe = itf_spi(request_json["parameter"]["frontend"])
        itf_be = itf_spi(request_json["parameter"]["backend"])

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, interface)

    if status:
        itf_fe.set_memory_config(reply["parameter"]["frontend"])
        itf_be.set_memory_config(reply["parameter"]["backend"])
        instance = instance_fs(itf_fe, itf_be, reply["parameter"])
    else:
        instance = None

    return code, status, instance

def _deinit_instance(interface:str, instance:str):
    request_json = copy.deepcopy(req_inf)
    request_json["sub_function"] = "deinit_instance"
    request_json["channel"] = set_interface(interface)
    request_json["parameter"]["name_instance"] = instance

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, interface)

    return code, status
