import os
import fcntl
import ioctl
import ctypes
import multiprocessing
import threading
import time
from contextlib import nullcontext

import numpy as np


class tachy_bs_spi_data(ctypes.Structure):
    _fields_ = [
        ("addr", ctypes.c_uint),
        ("size", ctypes.c_uint),
        ("data", ctypes.c_void_p)
    ]


class HostInterface(object):
    TACHY_BS_SPI_CMD_READ = ioctl.IOCTL.IORW(
        'd', 0, ctypes.sizeof(tachy_bs_spi_data)
    ).op
    TACHY_BS_SPI_CMD_WRITE = ioctl.IOCTL.IORW(
        'd', 1, ctypes.sizeof(tachy_bs_spi_data)
    ).op
    TACHY_BS_SPI_CMD_SET_AUTO = ioctl.IOCTL.IORW(
        'd', 2, ctypes.sizeof(tachy_bs_spi_data)
    ).op
    TACHY_BS_SPI_CMD_READ_SYNC = ioctl.IOCTL.IORW(
        'd', 3, ctypes.sizeof(tachy_bs_spi_data)
    ).op

    TACHY_BS_SPI_CMD_HOST_SELF_RESET = ioctl.IOCTL.IOW(
        'd', 0xF0, ctypes.sizeof(ctypes.c_ulong)
    ).op
    TACHY_BS_SPI_CMD_SYS_RESET = ioctl.IOCTL.IOW(
        'd', 0xF1, ctypes.sizeof(ctypes.c_ulong)
    ).op
    TACHY_BS_SPI_CMD_SET_CPU_RESET = ioctl.IOCTL.IOW(
        'd', 0xF2, ctypes.sizeof(ctypes.c_ulong)
    ).op
    TACHY_BS_SPI_CMD_CLEAR_CPU_RESET = ioctl.IOCTL.IOW(
        'd', 0xF3, ctypes.sizeof(ctypes.c_ulong)
    ).op

    SYS_DEVICE = '/dev/tachy-bs-0-sys'
    DATA_DEVICE = '/dev/tachy-bs-0-data'
    TRANSACTION_ATTEMPTS = 3
    RECOVERY_INTERVAL = 0.003

    lock = multiprocessing.Lock()

    def __init__(self, sys_device=SYS_DEVICE, data_device=DATA_DEVICE):
        self.sys_device = sys_device
        self.data_device = data_device
        self.fd_sys = None
        self.fd_data = None
        self.fd_sync = None
        self.sync_lock = threading.Lock()
        self._open_devices()

    def _open_devices(self):
        fd_sys = None
        try:
            fd_sys = os.open(self.sys_device, os.O_RDWR)
            fd_data = os.open(self.data_device, os.O_RDWR)
        except Exception:
            if fd_sys is not None:
                try:
                    os.close(fd_sys)
                except OSError:
                    pass
            raise

        self.fd_sys = fd_sys
        self.fd_data = fd_data

    def _close_devices(self, include_sync=True):
        names = ('fd_data', 'fd_sys', 'fd_sync') if include_sync else (
            'fd_data', 'fd_sys')
        for name in names:
            fd = getattr(self, name, None)
            if fd is not None:
                try:
                    os.close(fd)
                except OSError:
                    pass
                setattr(self, name, None)

    def close(self):
        with self.lock:
            with self.sync_lock:
                self._close_devices()

    def initialize(self):
        with self.lock:
            with self.sync_lock:
                self._close_devices()
                self._open_devices()
        return True

    def _recover_transaction(self):
        self._close_devices(include_sync=False)
        time.sleep(self.RECOVERY_INTERVAL)
        self._open_devices()

    def _ioctl_with_retry(self, fd_name, command, arg, description):
        last_error = None
        for attempt in range(1, self.TRANSACTION_ATTEMPTS + 1):
            try:
                fd = getattr(self, fd_name)
                if fd is None:
                    self._open_devices()
                    fd = getattr(self, fd_name)
                fcntl.ioctl(fd, command, arg)
                return
            except OSError as error:
                last_error = error
                if attempt < self.TRANSACTION_ATTEMPTS:
                    try:
                        self._recover_transaction()
                    except OSError as recovery_error:
                        last_error = recovery_error

        raise IOError(
            f"Host SPI {description} failed after "
            f"{self.TRANSACTION_ATTEMPTS} attempts"
        ) from last_error

    @staticmethod
    def _validate_address(addr):
        addr = int(addr)
        if addr < 0 or addr > 0xffff_ffff:
            raise ValueError(f"Host SPI address is out of range: {addr}")
        if addr & 0x3:
            raise ValueError(
                f"Host SPI address must be aligned by 4: 0x{addr:08x}"
            )
        return addr

    @staticmethod
    def _make_arg(addr=0, size=0, data=0):
        arg = tachy_bs_spi_data()
        arg.addr = addr
        arg.size = size
        arg.data = data
        return arg

    def spi_read(self, addr, size, lock=True):
        addr = self._validate_address(addr)
        size = int(size)
        if size < 0:
            raise ValueError(
                f"Host SPI read size must not be negative: {size}"
            )
        if size == 0:
            return np.empty(0, dtype=np.uint8)

        aligned_addr = addr & ~0x7
        front_size = addr - aligned_addr
        aligned_size = ((front_size + size + 7) // 8) * 8

        context = self.lock if lock else nullcontext()
        with context:
            data = np.zeros(aligned_size, dtype=np.uint8)
            arg = self._make_arg(
                aligned_addr,
                aligned_size,
                data.ctypes.data_as(ctypes.c_void_p),
            )
            self._ioctl_with_retry(
                'fd_data',
                self.TACHY_BS_SPI_CMD_READ,
                arg,
                f"read at 0x{addr:08x} ({size} bytes)",
            )
            return data[front_size:front_size + size].copy()

    def spi_read_sync(self, addr, size):
        """Block for one device interrupt, then read the requested SPI range."""
        addr = self._validate_address(addr)
        size = int(size)
        if size < 0:
            raise ValueError(
                f"Host SPI synchronous read size must not be negative: {size}"
            )
        if size == 0:
            return np.empty(0, dtype=np.uint8)

        aligned_addr = addr & ~0x7
        front_size = addr - aligned_addr
        aligned_size = ((front_size + size + 7) // 8) * 8

        with self.sync_lock:
            if self.fd_sync is None:
                self.fd_sync = os.open(self.data_device, os.O_RDWR)

            data = np.zeros(aligned_size, dtype=np.uint8)
            arg = self._make_arg(
                aligned_addr,
                aligned_size,
                data.ctypes.data_as(ctypes.c_void_p),
            )
            try:
                fcntl.ioctl(
                    self.fd_sync,
                    self.TACHY_BS_SPI_CMD_READ_SYNC,
                    arg,
                )
            except OSError as error:
                try:
                    os.close(self.fd_sync)
                except OSError:
                    pass
                self.fd_sync = None
                raise IOError(
                    f"Host SPI synchronous read at 0x{addr:08x} "
                    f"({size} bytes) failed"
                ) from error

            return data[front_size:front_size + size].copy()

    def spi_write(self, addr, data, w_flag=None, lock=True):
        addr = self._validate_address(addr)
        data = np.ascontiguousarray(data).view(np.uint8).reshape(-1)
        if data.size == 0:
            return

        context = self.lock if lock else nullcontext()
        with context:
            aligned_addr = addr & ~0x7
            front_size = addr - aligned_addr
            write_size = ((front_size + data.nbytes + 7) // 8) * 8
            tail_size = write_size - front_size - data.nbytes
            write_data = np.empty(write_size, dtype=np.uint8)

            if front_size:
                write_data[:front_size] = self.spi_read(
                    aligned_addr,
                    8,
                    lock=False,
                )[:front_size]
            if tail_size:
                tail_addr = aligned_addr + write_size - 8
                write_data[-tail_size:] = self.spi_read(
                    tail_addr,
                    8,
                    lock=False,
                )[-tail_size:]
            write_data[front_size:front_size + data.nbytes] = data

            reset_requested = w_flag == 'cpu'
            write_error = None
            clear_error = None

            try:
                if reset_requested:
                    self._ioctl_with_retry(
                        'fd_data',
                        self.TACHY_BS_SPI_CMD_SET_CPU_RESET,
                        self._make_arg(),
                        "set CPU reset",
                    )

                arg = self._make_arg(
                    aligned_addr,
                    write_size,
                    write_data.ctypes.data_as(ctypes.c_void_p),
                )
                self._ioctl_with_retry(
                    'fd_data',
                    self.TACHY_BS_SPI_CMD_WRITE,
                    arg,
                    f"write at 0x{addr:08x} ({data.nbytes} bytes)",
                )
            except Exception as error:
                write_error = error
            finally:
                if reset_requested:
                    try:
                        self._ioctl_with_retry(
                            'fd_data',
                            self.TACHY_BS_SPI_CMD_CLEAR_CPU_RESET,
                            self._make_arg(),
                            "clear CPU reset",
                        )
                    except Exception as error:
                        clear_error = error

            if write_error is not None:
                if clear_error is not None:
                    raise IOError(
                        "Host SPI write failed and CPU reset could not be "
                        "cleared"
                    ) from write_error
                raise write_error
            if clear_error is not None:
                raise clear_error

    def cpu_reset(self):
        addr = 0x041160E0
        self.spi_write(
            addr,
            np.array([0x0], dtype=np.uint8),
            w_flag='cpu',
        )

    def dis_boot_done(self):
        addr = 0x0411601C
        data = np.array([0x100]).astype(np.uint32)
        self.spi_write(addr, data)

    def set_power(self, status):
        pass


spi = HostInterface()
