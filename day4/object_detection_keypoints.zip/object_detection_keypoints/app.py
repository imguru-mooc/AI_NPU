import json
import queue
import threading
import time
from pathlib import Path

import cv2
import numpy as np
import tachy_rt.core.functions as rt_core
import src.yolov9_post_process as post_process

from src.detection_utils import (
    detections_from_anno,
    print_detections,
    update_tracker,
)

clss_dict = {
    "0": {
        "name": "nose",
        "valid": False
    },
    "1": {
        "name": "l eye",
        "valid": False
    },
    "2": {
        "name": "r eye",
        "valid": False
    },
    "3": {
        "name": "l ear",
        "valid": False
    },
    "4": {
        "name": "r ear",
        "valid": False
    },
    "5": {
        "name": "l shoulder",
        "valid": True
    },
    "6": {
        "name": "r shoulder",
        "valid": True
    },
    "7": {
        "name": "l elbow",
        "valid": True
    },
    "8": {
        "name": "r elbow",
        "valid": True
    },
    "9": {
        "name": "l wrist",
        "valid": True
    },
    "10": {
        "name": "r wrist",
        "valid": True
    },
    "11": {
        "name": "l hip",
        "valid": True
    },
    "12": {
        "name": "r hip",
        "valid": True
    },
    "13": {
        "name": "l knee",
        "valid": True
    },
    "14": {
        "name": "r knee",
        "valid": True
    },
    "15": {
        "name": "l ankle",
        "valid": True
    },
    "16": {
        "name": "r ankle",
        "valid": True
    },
    "17": {
        "name": "pelvis",
        "valid": False
    },
    "18": {
        "name": "thorax",
        "valid": False
    },
    "19": {
        "name": "upper neck",
        "valid": True
    },
    "20": {
        "name": "head top",
        "valid": True
    }
}


class TachyModelRuntime:
    def __init__(
            self,
            model_path,
            post_process_config_path,
            interface="spi:host",
            model_name="object_detection_yolov9",
            tx=2,
            input_shape=None,
            instance_name=None,
            spi_type="host",
            poll_interval=0.0):
        self.interface = interface
        self.model_name = model_name
        self.model_path = str(model_path)
        self.post_process_config = self._load_post_process_config(
            post_process_config_path
        )
        self.tx = tx
        configured_input_shape = (
            self.post_process_config["SHAPES_INPUT"]
            if input_shape is None
            else input_shape
        )
        self.input_shape = tuple(configured_input_shape)
        self.instance_name = instance_name or model_name
        self.spi_type = spi_type
        self.poll_interval = poll_interval
        self.reader = None
        self.config = self._create_config()

    @staticmethod
    def _load_post_process_config(config_path):
        with open(config_path, "r", encoding="utf-8") as config_file:
            return json.load(config_file)

    def initialize(self):
        # Stop a previous run before changing sensor or model state.
        self.close()
        self._save_model()
        self._enable_sensor()
        self._make_instance()
        self._connect_instance()
        return True

    def close(self):
        rt_core.deinit_instance(self.interface, self.instance_name)
        self.reader = None

    def _create_config(self):
        return {
            "global": {
                "name": self.model_name,
                "data_type": rt_core.DTYPE_FLOAT16,
                "buf_num": 5,  # max: 5
                "max_batch": 1,
                "npu_mask": -1,
            },
            "input": [
                {
                    "method": rt_core.INPUT_FMT_SENSOR,
                    "std": 255.0,
                    "mean": 0.0,
                    "tx": self.tx,
                }
            ],
            "output": {
                "reorder": True,
            },
        }

    def _save_model(self):
        if not rt_core.save_model(
                self.interface,
                self.model_name,
                rt_core.MODEL_STORAGE_MEMORY,
                self.model_path,
                overwrite=True):
            raise RuntimeError(
                "save_model failed: {}".format(
                    rt_core.get_last_error_code()
                )
            )

    def _enable_sensor(self):
        ratio = rt_core.get_sensor_ratio(
            self.input_shape[0],
            self.input_shape[1],
        )
        if not rt_core.enable_sensor(
                itf=self.interface,
                tx=self.config["input"][0]["tx"],
                ratio_w=ratio,
                ratio_h=ratio,
                rolling_buf=True,
                rolling_buf_num=self.config["global"]["buf_num"],
                rolling_buf_rule=rt_core.ROLLING_BUF_MASTER,
                reset=True,
                inverse_data=False,
                inverse_sync=False,
                inverse_clock=False):
            raise RuntimeError(
                "enable_sensor failed: {}".format(
                    rt_core.get_last_error_code()
                )
            )

    def _make_instance(self):
        # status, reader = rt_core.make_standalone_instance(
        status = rt_core.make_instance(
            self.interface,
            self.model_name,
            self.instance_name,
            "frame_split",
            self.config,
        )
        if not status:
            raise RuntimeError(
                "make_instance failed: {}".format(
                    rt_core.get_last_error_code()
                )
            )

    def _connect_instance(self):
        ret, self.reader = rt_core.connect_instance(self.interface, self.model_name)

        if not ret:
            print("connect instance fail")
            print("error :", rt_core.get_last_error_code())
            exit()

class VideoPipeline:
    def __init__(
            self,
            reader,
            post_config,
            device="/dev/video0",
            width=1920,
            height=1080,
            window_name="Tachy YOLOv9 Pose",
            display_width=None,
            display_height=None,
            shutdown_timeout=5.0):
        self.reader = reader
        self.post_config = post_config
        self.post = self._post_initialize(post_config)
        self.device = device
        self.width = width
        self.height = height
        self.window_name = window_name
        self.display_width = display_width or width // 3
        self.display_height = display_height or height // 3
        self.shutdown_timeout = shutdown_timeout

        self.capture = None
        self.process_thread = None
        self.annotation_thread = None
        self.stop_event = threading.Event()
        self.process_done_event = threading.Event()
        self.result_condition = threading.Condition()
        self.submitted_results = 0
        self.consumed_results = 0
        self.detection_queue = queue.Queue(maxsize=1)
        self.detection_queue_lock = threading.Lock()
        self.error_queue = queue.Queue(maxsize=1)

    def run(self):
        self.capture = self._open_yuyv_capture()
        self.annotation_thread = threading.Thread(
            target=self._annotation_worker,
            name="standalone-annotation",
            daemon=True,
        )
        try:
            self.annotation_thread.start()
        except Exception:
            self.annotation_thread = None
            raise
        self.process_thread = threading.Thread(
            target=self._process_worker,
            name="standalone-process",
            daemon=True,
        )
        try:
            self.process_thread.start()
        except Exception:
            self.process_thread = None
            self.stop_event.set()
            self.process_done_event.set()
            with self.result_condition:
                self.result_condition.notify_all()
            raise
        self._camera_worker()

    def close(self):
        self.stop_event.set()
        with self.result_condition:
            self.result_condition.notify_all()

        deadline = time.monotonic() + self.shutdown_timeout
        for thread_name in ("process_thread", "annotation_thread"):
            worker = getattr(self, thread_name)
            if worker is None:
                continue
            remaining = max(0.0, deadline - time.monotonic())
            worker.join(timeout=remaining)
            if not worker.is_alive():
                setattr(self, thread_name, None)

        if self.capture is not None:
            self.capture.release()
            self.capture = None
        cv2.destroyAllWindows()

        live_workers = self.live_worker_names()
        if live_workers:
            raise RuntimeError(
                "workers did not stop within {:.1f}s: {}".format(
                    self.shutdown_timeout,
                    ", ".join(live_workers),
                )
            )

    def live_worker_names(self):
        return [
            worker.name
            for worker in (self.process_thread, self.annotation_thread)
            if worker is not None and worker.is_alive()
        ]

    def _post_initialize(self, post_config):
        post = post_process.Decoder(post_config)
        return post

    def _open_yuyv_capture(self):
        capture = cv2.VideoCapture(self.device, cv2.CAP_V4L2)
        if not capture.isOpened():
            raise RuntimeError("cannot open {} with V4L2".format(self.device))

        if not capture.set(
                cv2.CAP_PROP_FOURCC,
                cv2.VideoWriter_fourcc(*"YUYV")):
            capture.release()
            raise RuntimeError(
                "{} does not accept YUYV format".format(self.device)
            )

        capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
        capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        capture.set(cv2.CAP_PROP_CONVERT_RGB, 1)

        actual_fourcc = int(capture.get(cv2.CAP_PROP_FOURCC))
        actual_format = "".join(
            chr((actual_fourcc >> (8 * index)) & 0xFF) for index in range(4)
        )
        if actual_format not in ("YUYV", "YUY2"):
            capture.release()
            raise RuntimeError(
                "{} opened as {}, not YUYV".format(self.device, actual_format)
            )
        return capture

    @staticmethod
    def _to_bgr(frame, capture_width):
        if frame.ndim == 3 and frame.shape[2] == 3:
            return frame
        if frame.ndim == 3 and frame.shape[2] == 2:
            return cv2.cvtColor(frame, cv2.COLOR_YUV2BGR_YUY2)
        if frame.ndim == 2 and frame.shape[1] == capture_width * 2:
            yuyv = frame.reshape(frame.shape[0], capture_width, 2)
            return cv2.cvtColor(yuyv, cv2.COLOR_YUV2BGR_YUY2)
        if frame.ndim == 2:
            return cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
        raise RuntimeError(
            "unsupported camera frame shape: {}".format(frame.shape)
        )

    def _draw_detections(self, frame, detections):
        for anno in detections:
            obj = anno[0 : 1]
            box = anno[1 : 5].astype(np.int32)
            pos = anno[
                5 : 5 + self.post_config["N_JOINTS"] * 2
            ].reshape(-1, 2).astype(np.int32)
            print(f"[INFO]: Probability : {obj}")
            print(f"[INFO]: Box : {box}")
            print(f"[INFO]: Pos : {pos}")
            # for p in pos:
            for i in range(len(pos)):
                if clss_dict[str(i)]["valid"]:
                    cv2.circle(
                        frame,
                        (pos[i][0], pos[i][1]),
                        10,
                        (0, 0, 255),
                        -1,
                    )

    def _put_latest_detections(self, detections):
        # Post-processing buffers can be reused by the producer.  Publish an
        # independent snapshot, and replace the queued value atomically so the
        # camera thread always receives the newest complete result.
        detections = np.asarray(detections).copy()
        with self.detection_queue_lock:
            try:
                self.detection_queue.get_nowait()
            except queue.Empty:
                pass
            self.detection_queue.put_nowait(detections)

    def _get_latest_detections(self, current_detections):
        # Keep using the last result when inference has not published a new
        # value yet. This intentionally has no expiration timeout.
        with self.detection_queue_lock:
            try:
                return self.detection_queue.get_nowait()
            except queue.Empty:
                return current_detections

    def _report_worker_error(self, error):
        try:
            self.error_queue.put_nowait(error)
        except queue.Full:
            pass
        self.stop_event.set()
        with self.result_condition:
            self.result_condition.notify_all()

    def _process_worker(self):
        try:
            while not self.stop_event.is_set():
                self.reader.process()
                with self.result_condition:
                    self.submitted_results += 1
                    self.result_condition.notify()
        except Exception as error:
            self._report_worker_error(error)
        finally:
            self.process_done_event.set()
            with self.result_condition:
                self.result_condition.notify_all()

    def _annotation_worker(self):
        while True:
            with self.result_condition:
                self.result_condition.wait_for(
                    lambda: (
                        self.consumed_results < self.submitted_results
                        or self.process_done_event.is_set()
                    )
                )
                if (
                    self.consumed_results >= self.submitted_results
                    and self.process_done_event.is_set()
                ):
                    break

            try:
                result = self.reader.get_result()
            except Exception as error:
                self._report_worker_error(error)
                break

            with self.result_condition:
                self.consumed_results += 1
                self.result_condition.notify_all()

            try:
                detections = self.post.main(
                    result["buf"].view(np.float32),
                    np.array(
                        [[0, 0, self.width - 1, self.height - 1]],
                        dtype=np.float32,
                    ),
                )

                self._put_latest_detections(detections)
                current_time = time.time()
                timestamp = time.strftime(
                    "%Y-%m-%d %H:%M:%S",
                    time.localtime(current_time),
                )
                timestamp = "{}.{:03d}".format(
                    timestamp,
                    int(current_time % 1 * 1000),
                )
                print(
                    "[INFO {}] Detections: {}".format(
                        timestamp,
                        len(detections),
                    )
                )
            except Exception as error:
                # Stop submitting work, but keep draining already submitted
                # results so the process worker cannot remain blocked.
                self._report_worker_error(error)

    def _camera_worker(self):
        detections = []
        capture_width = int(self.capture.get(cv2.CAP_PROP_FRAME_WIDTH))

        while True:
            try:
                worker_error = self.error_queue.get_nowait()
            except queue.Empty:
                worker_error = None
            if worker_error is not None:
                raise worker_error
            if self.stop_event.is_set():
                break

            success, camera_frame = self.capture.read()
            if not success:
                raise RuntimeError("failed to read {}".format(self.device))
            frame = self._to_bgr(camera_frame, capture_width)

            detections = self._get_latest_detections(detections)

            if len(detections) > 0:
                self._draw_detections(frame, detections)
            display_frame = cv2.resize(
                frame,
                (self.display_width, self.display_height),
                interpolation=cv2.INTER_AREA,
            )
            cv2.imshow(self.window_name, display_frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord("q")):
                self.stop_event.set()
                break


def main():
    base_dir = Path(__file__).resolve().parent
    model_path = (
        base_dir
        / "params/people_detection_yolov9-pose_xwn4/model_256x416x3_inv-f.tachyrt"
    )
    post_process_config_path = (
        base_dir
        / "configs/people_detection_yolov9-pose/post_process_256x416x3.json"
    )
    model_runtime = TachyModelRuntime(
        model_path=model_path,
        post_process_config_path=post_process_config_path,
    )
    video_pipeline = None
    shutdown_error = None
    try:
        model_runtime.initialize()
        video_pipeline = VideoPipeline(model_runtime.reader, model_runtime.post_process_config)
        video_pipeline.run()
    except KeyboardInterrupt:
        pass
    finally:
        if video_pipeline is not None:
            try:
                video_pipeline.close()
            except RuntimeError as error:
                shutdown_error = error

        if video_pipeline is None or not video_pipeline.live_worker_names():
            model_runtime.close()
        else:
            print(
                "[ERROR] Runtime deinit skipped while workers are active: {}".format(
                    ", ".join(video_pipeline.live_worker_names())
                )
            )

        if shutdown_error is not None:
            raise shutdown_error


if __name__ == "__main__":
    main()
