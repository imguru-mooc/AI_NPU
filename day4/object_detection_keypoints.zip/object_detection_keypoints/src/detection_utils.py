import numpy as np
import supervision as sv


def detections_from_anno(anno: np.ndarray) -> sv.Detections:
    anno = np.asarray(anno, dtype=np.float32)

    if anno.ndim != 2 or anno.shape[1] != 6:
        raise ValueError(
            "anno must have shape (N, 6): "
            "objectness, category, x0, y0, x1, y1"
        )

    # 잘못된 한 개의 annotation이 전체 tracker 상태를 손상시키지 않도록 제외합니다.
    anno = anno[np.all(np.isfinite(anno), axis=1)]
    xyxy = anno[:, 2:6].copy()
    if len(xyxy) > 0:
        x0 = np.minimum(xyxy[:, 0], xyxy[:, 2])
        y0 = np.minimum(xyxy[:, 1], xyxy[:, 3])
        x1 = np.maximum(xyxy[:, 0], xyxy[:, 2])
        y1 = np.maximum(xyxy[:, 1], xyxy[:, 3])
        xyxy[:, 0] = x0
        xyxy[:, 1] = y0
        xyxy[:, 2] = x1
        xyxy[:, 3] = y1

        valid_area = (x1 > x0) & (y1 > y0)
        anno = anno[valid_area]
        xyxy = xyxy[valid_area]

    return sv.Detections(
        xyxy=xyxy,
        confidence=anno[:, 0].astype(np.float32),
        class_id=anno[:, 1].astype(np.int32),
    )


def create_tracker():
    if not hasattr(sv, "ByteTrack"):
        print(
            "supervision.ByteTrack is not available. "
            "Printing detections without tracking."
        )
        return None
    return sv.ByteTrack()


def update_tracker(tracker, detections: sv.Detections) -> sv.Detections:
    """ByteTrack을 갱신하고 추적 ID가 포함된 검출 결과를 반환합니다."""
    if tracker is None:
        return detections

    # supervision 버전에 따라 새 API의 메서드명이 update()일 수 있습니다.
    for method_name in ("update_with_detections", "update"):
        update = getattr(tracker, method_name, None)
        if callable(update):
            return update(detections)

    raise RuntimeError(
        "Installed tracker provides neither "
        "update_with_detections() nor update()."
    )


def print_detections(detections) -> None:
    return

