# Object Detection Tracking 실행 방법

## 1. Tachy Shield 부팅

```bash
cd boot
python boot.py
```

부팅이 완료되면 다음 메시지가 출력됩니다.

```text
[INFO] Success to boot. Check the status via uart or other api
Success to boot.
```

## 2. 객체 검출 실행

```bash
cd ../object_detection_tracking
python app.py
```

## 3. 실행 결과

카메라 영상에 검출 영역이 표시되며, 터미널에는 다음과 같이 검출 개수, 클래스, 신뢰도 및 좌표가 출력됩니다.

```text
[INFO 2026-08-20 22:13:36.337] Detections: 0
[INFO 2026-08-20 22:13:36.377] Detections: 1
track_id=#8 class_id=0 confidence=0.6343 box=[ 47.884617 -11.337891 717.9808   666.2988  ]
[INFO 2026-08-20 22:13:36.405] Detections: 1
track_id=#8 class_id=0 confidence=0.2063 box=[ 59.423077 -19.77539  727.21155  655.75195 ]
[INFO 2026-08-20 22:13:36.442] Detections: 1
```

종료하려면 영상 창에서 `q` 또는 `Esc` 키를 누릅니다.
