import os
import argparse

from importlib.metadata import version, PackageNotFoundError
from packaging.version import Version

import tachy_rt.core.functions as rt_core

def create_args():
    def get_parser():
        """
        Get the parser.
        :return: parser
        """
    
        parser = argparse.ArgumentParser(description='Deep learning example script')
    
        parser.add_argument('--path_firmware', type=str,
                            help='Uploading firmware)',
                            default='./boot_binary')

        args = parser.parse_args()
        args.interface = "spi:host"

        return args
    
    args = get_parser()

    return args

def boot(args):
    if 'spi' not in args.interface:
        return
    os.system("sudo chown ${USER}:${USER} /dev/tachy*")
    os.system("pinctrl set 4 op dl; sleep 3; pinctrl set 4 op dh")

    ''' Upload firmware to device '''

    data = {
        "spl" : {
            "path" : os.path.join(args.path_firmware, "spl.bin"),
            "addr" : "0x0"
        },
        "uboot" : {
            "path" : os.path.join(args.path_firmware, "u-boot.bin"),
            "addr" : "0x2000_0000"
        },
        "kernel" : {
            "path" : os.path.join(args.path_firmware, "image.ub"),
            "addr" : "0x4000_0000"
        },
        "fpga" : {
            "path" : os.path.join(args.path_firmware, "fpga_top.bin"),
            "addr" : "0x3000_0000"
        }}
    spi_type = args.interface.split(":")[-1]
    ret = rt_core.boot(spi_type, rt_core.DEV_TACHY_SHIELD, data)
    if ret:
        print("Success to boot.")
    else:
        print("Failed to boot")
        print("Error code :", rt_core.get_last_error_code())
        exit(-1)

if __name__ == '__main__':
    ''' Parse arguments '''
    args = create_args()

    ''' Boot tachy-bs '''
    boot(args)


