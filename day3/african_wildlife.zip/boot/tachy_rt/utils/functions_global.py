import os, sys
import zlib
import platform
import numpy as np
import commentjson
import base64
import random
import string

from tachy_rt.utils.logger import *

def get_random_string(length):
    letters = string.ascii_lowercase + string.ascii_uppercase
    result_str = ''.join(random.choice(letters) for i in range(length))

    return result_str

def json_load(path):
    if os.path.exists(path):
        with open(path, "r") as f:
            return commentjson.load(f)
    else:
        logger.error("ERROR : Json file is not exist {}".format(path))
        exit(-1)

def hwd_2_xywh(arr):
    if type(arr) == list: arr = np.array(arr)
    if arr.ndim == 1: arr = arr.reshape(-1, arr.shape[0])
    assert(arr.ndim == 2)

    shape = [arr.shape[0], 4]
    ret = np.zeros(shape, np.int32)
    ret[..., 0] = 0
    ret[..., 1] = 0
    ret[..., 2] = arr[..., 1] - 1
    ret[..., 3] = arr[..., 0] - 1

    return ret

def xywh_2_hwd(arr):
    if type(arr) == list: arr = np.array(arr)
    if arr.ndim == 1: arr = arr.reshape(-1, arr.shape[0])
    assert(arr.ndim == 2)

    shape = [arr.shape[0], 3]
    ret = np.zeros(shape, np.int32)
    ret[..., 0] = arr[..., 3] - arr[..., 1] + 1
    ret[..., 1] = arr[..., 2] - arr[..., 0] + 1
    ret[..., 2] = 3

    return ret

def get_os():
    return platform.system()

def append_crc32(data):
    value = np.array([calculate_crc32(data)], np.uint32).view(data.dtype)
    data = np.concatenate([data, value])
    return data

def calculate_crc32(data):
    crc32_value = zlib.crc32(data)
    return crc32_value

def is_crc32_valid(data, crc32_checksum):
    calculated_crc32 = zlib.crc32(data) & 0xFFFFFFFF
    return calculated_crc32 == crc32_checksum

def progressbar(it, prefix="", size=60, display=True): # Python3.3+
    count = len(it)
    def show(j):
        x = int(size*j/count)
        if display:
            print("{}[{}{}] {}/{}".format(prefix, "#"*x, "."*(size-x), j, count), 
                    end='\r', file=sys.stdout, flush=True)
    show(0)
    for i, item in enumerate(it):
        yield item
        show(i+1)

    if display:
        print("", flush=True, file=sys.stdout)

def base64_encode(bin):
    return base64.b64encode(bin)

def base64_decode(bin):
    return base64.b64decode(bin)

def set_interface(itf):
    ret = {}
    if "ethernet" in itf:
        ret["type"] = "tcp"
        ret["ip"] = itf.split(':')[1]
        ret["port"] = 40000
    elif "tcp" in itf:
        ret["type"] = "tcp"
        ret["ip"] = itf.split(':')[1]
        ret["port"] = 40000
    elif "spi" in itf:
        ret = {}
        ret["type"] = itf.split(':')[0]
        ret["mode"] = itf.split(':')[1]
    elif "local" in itf:
        ret = {}
        ret["type"] = itf
    return ret

def preprocess_crop(boxes, org_w, org_h):
    size_matrix = np.array([[org_w, org_h]])
    w = boxes[..., 2:3] - boxes[..., 0:1]
    h = boxes[..., 3:4] - boxes[..., 1:2]
    sizes = np.concatenate([w, h], axis=-1)
    scale_ratio = size_matrix / sizes

    ret = np.concatenate([boxes[..., :4], w, h, scale_ratio * 100], axis=-1)
    return ret.astype(np.uint16)
