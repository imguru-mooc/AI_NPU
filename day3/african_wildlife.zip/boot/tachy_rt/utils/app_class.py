import ctypes
from tachy_rt.utils.constants import *

class ApplicationProtocol(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("index",  ctypes.c_int),
        ("n_batch",ctypes.c_int),
        ("cmd",    ctypes.c_int),
        ("length", ctypes.c_int)
    ]
