# -*- coding:utf-8 -*-

import time
import threading

import numpy as np
from .spi_api import FtdiSpiInterface

CMD_WRITE   = 0x80
CMD_READ    = 0x00

class TachyHostInterface(FtdiSpiInterface):
    def __init__(self, url, cs=0, freq=20e6, mode=3):
        FtdiSpiInterface.__init__(self, url, cs, freq, mode)
        self.t_lock = threading.Lock()


    def _get_addr_split(self, addr):
        return (addr >> 24) & 0xFF, (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, addr & 0xFF


    def boot(self):
        rst_gpio_no = 7 + 8
        rst_gpio = 1 << rst_gpio_no

        # set Direction Out
        self.gpio_ctrl.set_direction(rst_gpio, rst_gpio & 0xff00)
        # Clear GPIO
        self.gpio_ctrl.write(0)
        # SET GPIO
        self.gpio_ctrl.write(rst_gpio)


    def spi_read(self, addr: int, data_len: int, chunk_size=65280) -> np.ndarray: 
        self.t_lock.acquire()
        size_of_byte_align = 8

        if data_len < 0:
            self.t_lock.release()
            return np.array([], dtype=np.uint8)

        addr_remainder = addr % size_of_byte_align
        if addr_remainder:
            addr = addr - addr_remainder
            data_len = data_len + addr_remainder

        read_data = np.empty(data_len, dtype=np.uint8)
        iter_num = int(data_len/chunk_size)
        rest_len = data_len % chunk_size

        for i in range(0, iter_num):
            addr0, addr1, addr2, addr3 = self._get_addr_split(addr)
            self.slave.write([CMD_READ, addr0, addr1, addr2, addr3], start=True, stop=False)
            time.sleep(0.000001)  # delay 1us
            read_data[i*chunk_size:i*chunk_size+chunk_size] = self.slave.read(chunk_size, start=False, stop=True)

            addr += chunk_size

        if rest_len > 0:
            addr0, addr1, addr2, addr3 = self._get_addr_split(addr)
            self.slave.write([CMD_READ, addr0, addr1, addr2, addr3], start=True, stop=False)
            read_data[iter_num*chunk_size:] = self.slave.read(rest_len, start=False, stop=True)

        if addr_remainder:
            read_data = read_data[addr_remainder:]

        self.t_lock.release()
        return read_data


    def spi_write(self, addr: int, data: np.ndarray, chunk_size:int = 65280):
        self.t_lock.acquire()
        size_of_byte_align = 8
        if data.size <= 0:
            self.t_lock.release()
            return
        data = data.view(np.uint8)
        offset = 0

        addr_remainder = addr % size_of_byte_align
        if addr_remainder:
            addr = addr - addr_remainder
            addr0, addr1, addr2, addr3 = self._get_addr_split(addr)
            front_data = np.empty(size_of_byte_align, dtype=np.uint8)

            # Read front data
            self.slave.write([CMD_READ, addr0, addr1, addr2, addr3], start=True, stop=False)
            front_data[:size_of_byte_align - addr_remainder] = self.slave.read(addr_remainder, start=False, stop=True)
            front_data[size_of_byte_align - addr_remainder:] = data[:size_of_byte_align - addr_remainder]

            # Write front data
            self.slave.write([CMD_WRITE, addr0, addr1, addr2, addr3], start=True, stop=False)
            self.slave.write(front_data, start=False, stop=False)

            addr += size_of_byte_align
            data = data[size_of_byte_align - addr_remainder:]

        iter_num = int(data.nbytes/chunk_size)
        rest_len = data.nbytes % chunk_size

        for _ in range(0, iter_num):
            addr0, addr1, addr2, addr3 = self._get_addr_split(addr)

            self.slave.write([CMD_WRITE, addr0, addr1, addr2, addr3], start=True, stop=False)
            self.slave.write(data[offset:offset + chunk_size], start=False, stop=False)

            offset += chunk_size
            addr += chunk_size

        if rest_len > 0:
            addr0, addr1, addr2, addr3 = self._get_addr_split(addr)
            self.slave.write([CMD_WRITE, addr0, addr1, addr2, addr3], start=True, stop=False)
            self.slave.write(data[offset:offset + chunk_size], start=False, stop=True)

        self.t_lock.release()
        return

    def gpio_in(self, gpio_number: int) -> int:
        gpio = self.spi_ctrl.gpio_pins & (1 << gpio_number)
        direction = self.gpio_ctrl.direction & ~(1 << gpio_number)
        self.gpio_ctrl.set_direction(gpio, direction)
        return self.gpio_ctrl.direction

    def gpio_out(self, gpio_number: int) -> int:
        gpio = self.spi_ctrl.gpio_pins | (1 << gpio_number)
        direction = self.gpio_ctrl.direction | (1 << gpio_number)

        self.gpio_ctrl.set_direction(gpio, direction)
        return self.gpio_ctrl.direction

    def _reset(self, addr=0x041160E0):
        data = np.array([0x0], dtype=np.uint8)
        addr0, addr1, addr2, addr3 = self._get_addr_split(addr)
        self.slave.write([0x82, addr0, addr1, addr2, addr3], start=True, stop=False)
        self.slave.write(data, start=False, stop=True)
        self.slave.write(b'\xC0')

    def host_boot(self, spl_file_path, uboot_file_path, uboot_addr=0x20000000):
        self.spi_write(0x041160B0, np.array([0x0], dtype=np.uint8))

        spl = np.fromfile(spl_file_path, dtype=np.uint8)
        # write spl to address 0x00000000
        self.spi_write(0x00000000, spl)

        # cpu reset
        self._reset()

        spi_ret = self.spi_read(0x041160B0, 0x4)
        while spi_ret[0] == 0:
            spi_ret = self.spi_read(0x041160B0, 0x4)

        uboot = np.fromfile(uboot_file_path, dtype=np.uint8)

        # write u-boot to address 0x20000000
        self.spi_write(uboot_addr, uboot)
        self.spi_write(0x041160B0, np.array([uboot_addr], dtype=np.uint64).view(np.uint8))

spi = TachyHostInterface('ftdi://ftdi:2232h/2')
