import logging

# Tachy Engine Logger
logger = logging.getLogger('tachy_rt')
logger.setLevel(logging.INFO) # 모든 레벨의 로그를 Handler들에게 전달해야 합니다.
formatter = logging.Formatter('[%(asctime)s %(filename)20s -> %(funcName)23s():%(lineno)4s]  %(levelname)s: %(message)s', '%Y-%m-%d %H:%M:%S')

# INFO 레벨 이상의 로그를 콘솔에 출력하는 Handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)
