from pyftdi import spi as ft_spi
from pyftdi import serialext as ft_uart
from pyftdi import ftdi as ft_ftdi
import multiprocessing

import os
import time
import numpy as np

class HostInterface(object):
    lock = multiprocessing.Lock()

    def __init__(self, chip_name, spi_ch=2, cs=0, freq=10E6, mode=3, uart_ch=0, baudrate=115200, interval=0.005):
        self.spi_ctrl = ft_spi.SpiController()
        self.spi_ctrl.configure('ftdi://ftdi:{}/{}'.format(chip_name, spi_ch))
        self.gpio_ctrl = self.spi_ctrl.get_gpio()

        self.slave = self.spi_ctrl.get_port(cs=cs, freq=freq, mode=mode)
        self.gpio_pins = 0x0
        self.gpio_status = 0x0

        self.last_write = 0.0
        self.interval = interval

        if uart_ch:
            self.port = ft_uart.serial_for_url('ftdi://ftdi:{}/{}'.format(chip_name, uart_ch), baudrate=baudrate)

    def read_dummy(self, addr, size):
        cmd = np.concatenate((np.array([0x00], dtype=np.uint8), addr), axis=0)
        self.slave.write(cmd.tobytes(), stop=False)

        dummy = np.empty((size), dtype=np.uint8)
        for i in range(0, size, 20000):
            if i + 20000 > size:
                dummy[i:] = np.array(self.slave.read(size - i, start=False), dtype=np.uint8)
            else:
                dummy[i:i+20000] = np.array(self.slave.read(20000, start=False, stop=False), dtype=np.uint8)

        return dummy.view(np.uint8)

    def spi_write(self, addr, data, w_flag=None):
        self.lock.acquire()

        # reshape data 
        if data.ndim != 1:
            data = data.reshape(-1,)

        # select command from flag
        if w_flag == 'cpu':
            cmd = np.array([0x82], dtype=np.uint8)
        elif w_flag == 'sys':
            cmd = np.array([0x81], dtype=np.uint8)
        else:
            cmd = np.array([0x80], dtype=np.uint8)
    
        # convert address
        cvt_addr = np.array([addr], dtype=np.uint32).view(np.uint8)[::-1]
        f_dummy_size = cvt_addr[3] & 0x7
        r_dummy_size = 8 - ((f_dummy_size + data.nbytes) % 8)

        # read front dummy
        if f_dummy_size == 0:
            dst_addr = cvt_addr
        else:
            dst_addr = np.concatenate((cvt_addr[:3], np.array([cvt_addr[3] & 0xf8], dtype=np.uint8)), axis=0)
            dummy = self.read_dummy(dst_addr, 8)
            f_dummy = dummy[:f_dummy_size]

        # read rear dummy
        if r_dummy_size != 0:
            r_dummy_addr = np.array([addr+data.nbytes], dtype=np.uint32).view(np.uint8)[::-1]
            dummy = self.read_dummy(r_dummy_addr, 8)
            r_dummy = dummy[8-r_dummy_size:]

        # write command, address
        w_data = np.concatenate((cmd, dst_addr), axis=0)
        self.slave.write(w_data.tobytes(), stop=False)

        # write front dummy
        if f_dummy_size != 0:
            f_dummy = dummy[:f_dummy_size]
            self.slave.write(f_dummy.tobytes(), start=False, stop=False)

        for i in range(0, data.nbytes, 20000):
            if i + 20000 > data.nbytes:
                # write rear dummy
                if r_dummy_size == 0:
                    self.slave.write(data[i:i+20000].tobytes(), start=False)
                else:
                    self.slave.write(data[i:i+20000].tobytes(), start=False, stop=False)
                    self.slave.write(r_dummy.tobytes(), start=False)
            else:
                self.slave.write(data[i:i+20000].tobytes(), start=False, stop=False)

        self.last_write = time.time()
        self.lock.release()

    def spi_read(self, addr, size):
        self.lock.acquire()

        diff = time.time() - self.last_write
        if diff < self.interval: time.sleep(self.interval)

        if size <= 0: return np.array([])

        # convert address
        cvt_addr = np.array([addr], dtype=np.uint32).view(np.uint8)[::-1]

        f_dummy_size = cvt_addr[3] & 0x7
        r_dummy_size = 8 - ((f_dummy_size + size) % 8)
        if f_dummy_size == 0:
            dst_addr = cvt_addr
        else:
            dst_addr = np.concatenate((cvt_addr[:3], np.array([cvt_addr[3] & 0xf8], dtype=np.uint8)), axis=0)

        dummy = self.read_dummy(dst_addr, f_dummy_size + size + r_dummy_size)

        self.lock.release()

        return dummy[f_dummy_size:f_dummy_size + size]
    
    def set_direction_out(self, gpio_num):
        # read direction status
        prev_direction = self.spi_ctrl.direction

        # Preserve existing pins, direction
        gpio = self.gpio_pins | (1 << gpio_num)
        direction = (prev_direction | (1 << gpio_num)) & 0xff00

        # set direction
        self.gpio_ctrl.set_direction(gpio, direction)
        self.gpio_pins = self.spi_ctrl.gpio_pins
    
    def set_direction_in(self, gpio_num):
        # read direction status
        prev_direction = self.spi_ctrl.direction

        # Preserve existing pins, direction
        gpio = self.gpio_pins | (1 << gpio_num)
        direction = (~(1 << gpio_num) & 0xfff0) & prev_direction

        # set direction
        self.gpio_ctrl.set_direction(gpio, direction)
        self.gpio_pins = self.spi_ctrl.gpio_pins

    def set_power(self, status: bool):
        # set power gpio as out
        self.set_direction_out(6 + 8)
        self.set_direction_out(7 + 8)

        # set sram boot
        self.gpio_write(6 + 8, 0)

        # do power reset
        time.sleep(0.01)
        self.gpio_write(7 + 8, False)
        time.sleep(0.01)
        self.gpio_write(7 + 8, status)
        time.sleep(0.01)

    def gpio_write(self, gpio_num, val):
        if val:
            val = self.gpio_status | (1 << gpio_num)
        else:
            val = self.gpio_status & (~(1 << gpio_num) & 0xffff)

        self.gpio_ctrl.write(val)
        self.gpio_status = val

    def gpio_read(self, gpio_num):
        ret = (self.gpio_ctrl.read() >> gpio_num) & 1

        return ret

    def file_write(self, dst_addr, file_name):
        file_info = np.fromfile(file_name, dtype=np.uint8)
        self.spi_write(dst_addr, file_info)

    def host_boot(self, spl_file, uboot_file, uboot_addr=0x20000000):
        self.spi_write(0x041160B0, np.array([0x0], dtype=np.uint8))
        # write spl to address 0x00000000
        spl_addr = 0x00000000
        self.file_write(spl_addr, spl_file)

        # cpu reset
        self._reset('cpu')

        spi_ret = self.spi_read(0x041160B0, 0x4)
        while spi_ret[0] == 0:
            spi_ret = self.spi_read(0x041160B0, 0x4)

        # # write u-boot to address 0x20000000
        self.file_write(uboot_addr, uboot_file)

        self.spi_write(0x041160B0, np.array([uboot_addr], dtype=np.uint64).view(np.uint8))

    def _reset(self, flag):
        addr = 0x041160E0
        # CPU Reset
        self.spi_write(addr, np.array([0x0], dtype=np.uint8), w_flag=flag)
        # HOST Refresh
        self.slave.write(b'\xC0')

    def uart_write(self, data):
        self.port.write(data)

    def uart_read(self, size):
        ret = self.port.read(size)
        return ret
