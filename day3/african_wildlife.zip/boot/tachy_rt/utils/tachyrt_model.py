import base64
import datetime
import commentjson
import numpy as np
from easydict import EasyDict
from tachy_rt.utils.logger import logger

class tachyrt_model:
    def __init__(self):
        self.partition = {
            "header": 0,
            "instruction": 1,
            "descriptor": 2,
            "parameter": 3
        }
        self.__version__ = 2
        logger.info("init tachyrt_model v{}".format(float(self.__version__)))

    def load_model(self, file):
        data = np.fromfile(file, np.uint8)

        offset = 0
        while offset < data.nbytes:
            partition, length = data[offset:offset+8].view(np.uint32)[:2]
            offset += 8

            self._parse(partition, data[offset:offset + length])
            offset += length

        return self

    def build_model(self, inst: np.array, desc: dict, param: np.array):
        assert(type(inst) == np.ndarray)
        assert(type(desc) == dict)
        assert(type(param) == np.ndarray)

        _dict = {}
        self._header = self._set_header(_dict)
        self._inst   = self._set_inst(_dict, inst)
        self._desc   = self._set_desc(_dict, desc)
        self._param  = self._set_param(_dict, param)

        data_header = np.frombuffer(commentjson.dumps(self._header).encode(), np.uint8)
        data_inst = self._inst
        data_desc = np.frombuffer(commentjson.dumps(self._desc).encode(), np.uint8)
        data_param = self._param
        size_header = len(data_header)
        size_inst = len(data_inst)
        size_desc = len(data_desc)
        size_param = len(data_param)

        data = np.concatenate([
            np.array([self.partition["header"]], np.uint32).view(np.uint8),
            np.array([size_header], np.uint32).view(np.uint8),
            data_header,

            np.array([self.partition["instruction"]], np.uint32).view(np.uint8),
            np.array([size_inst], np.uint32).view(np.uint8),
            data_inst,

            np.array([self.partition["descriptor"]], np.uint32).view(np.uint8),
            np.array([size_desc], np.uint32).view(np.uint8),
            data_desc,

            np.array([self.partition["parameter"]], np.uint32).view(np.uint8),
            np.array([size_param], np.uint32).view(np.uint8),
            data_param,
        ])

        return data

    def get_info(self):
        '''
        1. header
        '''
        print(self._header)

    def _set_header(self, _dict):
        _dict["header"] = {}
        _dict["header"]["date"] = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        _dict["header"]["bs_ver"] = 2
        _dict["header"]["rt_ver"] = 2

        return _dict["header"]

    def _set_inst(self, _dict, inst):
        '''
        1. instruction partition
        2. instruction partition size
        3. instruction data
        '''
        inst = inst.view(np.uint8).reshape(-1)
        assert((inst.size % 32) == 0), "Instruction must be ended without exit layer"

        return inst

    def _set_desc(self, _dict, desc):
        '''
        1. descriptor partition
        2. descriptor partition size
        2. descriptor n_layer
        3. descriptor data
        '''
        return desc

    def _set_param(self, _dict, param):
        '''
        1. parameter partition
        2. parameter partition size
        3. parameter data
        '''
        param = param.view(np.uint8).reshape(-1)
        return param

    def _get_rt_ver(self):
        return self.__version__

    def _parse(self, partition, data):
        if self.partition["header"] == partition:
            self._parse_header(data)
        elif self.partition["instruction"] == partition:
            self._parse_instruction(data)
        elif self.partition["descriptor"] == partition:
            self._parse_descriptor(data)
        elif self.partition["parameter"] == partition:
            self._parse_parameter(data)

    def _parse_header(self, data):
        '''
        1. header data(name) -> 30 byte
        2. header data(date) -> 14 byte
        2. header data(bs_ver) -> 4 byte
        3. header data(rt_ver) -> 4 byte
        '''
        self._header = commentjson.loads(data.tobytes().decode())

    def _parse_instruction(self, data):
        '''
        1. instruction data
        '''
        self._instruction = data[:]

        return True

    def _parse_descriptor(self, data):
        '''
        1. descriptor layer len
        2. descriptor data
        '''
        self._descriptor = EasyDict(commentjson.loads(data.tobytes().decode()))

        self._n_block = self._descriptor.n_block

        self._input_format = self._descriptor.input_format
        self._input_block  = self._descriptor.input_block
        self._input_shape  = self._descriptor.input_shape
        self._output_block = self._descriptor.output_block
        self._output_shape = self._descriptor.output_shape

    def _parse_parameter(self, data):
        '''
        1. parameter data
        '''
        self._parameter = data[:]

        return True

    def _extract_desc_from_inst(self, inst):
        pass

    def get_n_layer_inst(self, n_layer):
        offset = n_layer * 32
        ret = self._instruction[offset:offset+32].view(np.uint32)
        return ret

    def get_n_layer_param(self, n_layer):
        offset = n_layer * 8
        offset_next = (n_layer+1) * 8
        base = self._instruction.view(np.uint32)[5].byteswap()
        start = self._instruction.view(np.uint32)[offset+5].byteswap()
        end = -1 if n_layer == (self.n_layer-1) else self._instruction.view(np.uint32)[offset_next+5].byteswap()

        offset = start - base
        size = end - start

        ret = self._parameter[offset:offset+size]
        return ret

    def get_n_layer_input_size(self, n_layer):
        size = int(np.prod(self._descriptor[n_layer].input_shape)) * 2
        return size

    def get_n_layer_output_size(self, n_layer):
        size = int(np.prod(self._descriptor[n_layer].output_shape)) * 2
        return size

    @property
    def input_shape(self):
        return self._input_shape

    @property
    def output_shape(self):
        return self._output_shape

    @property
    def instruction(self):
        return self._instruction

    @property
    def parameter(self):
        return self._parameter

    @property
    def n_layer(self):
        return self._descriptor["n_block"]

    @property
    def descriptor(self):
        return self._descriptor
