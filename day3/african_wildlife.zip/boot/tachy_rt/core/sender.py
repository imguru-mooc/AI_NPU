import os, sys
import time
import socket
import math
import contextvars
from contextlib import contextmanager
import numpy as np
from tachy_rt.utils.logger import *
from tachy_rt.utils.constants import *
from tachy_rt.utils.functions_global import *

if get_os() == "Linux":
    import posix_ipc as pi

SPI_REQUEST_POLL_TIMEOUT = 5.0
SPI_REPLY_POLL_TIMEOUT = 30.0
SPI_POLL_INTERVAL = 0.001
SPI_REQUEST_REANNOUNCE_INTERVAL = 1.2
SPI_REQUEST_REANNOUNCE_ATTEMPTS = 4
SPI_STABLE_READ_ATTEMPTS = 3
SPI_DATA_WRITE_ATTEMPTS = 3
SPI_WINDOW_SIZE = 0x0004_0000
_REQUEST_POLL_TIMEOUT_OVERRIDE = contextvars.ContextVar(
    "spi_request_poll_timeout_override",
    default=None,
)


@contextmanager
def request_poll_timeout(seconds):
    seconds = float(seconds)
    if seconds <= 0:
        raise ValueError("SPI request poll timeout must be positive")
    token = _REQUEST_POLL_TIMEOUT_OVERRIDE.set(seconds)
    try:
        yield
    finally:
        _REQUEST_POLL_TIMEOUT_OVERRIDE.reset(token)


def _read_stable_block(spi, addr, size):
    samples = []
    for _ in range(SPI_STABLE_READ_ATTEMPTS):
        current = spi.spi_read(addr, size).copy()
        for sample in samples:
            if np.array_equal(current, sample):
                return current
        samples.append(current)
        time.sleep(SPI_POLL_INTERVAL)

    raise IOError(
        f"Unstable SPI read at 0x{addr:08x} ({size} bytes): "
        f"no matching samples in {SPI_STABLE_READ_ATTEMPTS} attempts"
    )


def _write_verified_block(spi, addr, data):
    expected = np.ascontiguousarray(data).view(np.uint8).reshape(-1)
    last_actual = None
    for _ in range(SPI_DATA_WRITE_ATTEMPTS):
        spi.spi_write(addr, data)
        for _ in range(2):
            actual = spi.spi_read(addr, expected.size)
            if np.array_equal(actual, expected):
                return
            last_actual = actual

    mismatch = int(np.flatnonzero(last_actual != expected)[0])
    raise IOError(
        f"SPI write verification failed at 0x{addr + mismatch:08x}: "
        f"expected=0x{int(expected[mismatch]):02x}, "
        f"actual=0x{int(last_actual[mismatch]):02x}"
    )


def _valid_spi_buffer(value, header):
    value = int(value)
    return (
        header < value < header + SPI_WINDOW_SIZE
        and value & 0x7 == 0
    )


def _wait_spi_value(spi, addr, predicate, description, timeout=None):
    if timeout is None:
        timeout = _REQUEST_POLL_TIMEOUT_OVERRIDE.get()
        if timeout is None:
            timeout = SPI_REQUEST_POLL_TIMEOUT
    deadline = time.monotonic() + timeout
    candidate = None
    matches = 0
    while True:
        value = spi.spi_read(addr, 4).view(np.int32)[0]
        if predicate(value):
            if candidate == value:
                matches += 1
            else:
                candidate = value
                matches = 1
            if matches >= 2:
                return value
        else:
            candidate = None
            matches = 0
        if time.monotonic() >= deadline:
            raise TimeoutError(
                f"SPI timeout waiting for {description} at 0x{addr:08x}; "
                f"last value={int(value)}"
            )
        time.sleep(SPI_POLL_INTERVAL)


def _wait_request_buffer_address(spi, total_size, allow_reannounce=False):
    header = INTERFACE_SPI_READER_HEADER
    addr_register = header
    total_size_register = header + 0x8
    predicate = lambda value: _valid_spi_buffer(value, header)

    if not allow_reannounce:
        return _wait_spi_value(
            spi,
            addr_register,
            predicate,
            "request buffer address",
        )

    timeout = _REQUEST_POLL_TIMEOUT_OVERRIDE.get()
    if timeout is None:
        timeout = SPI_REQUEST_POLL_TIMEOUT
    deadline = time.monotonic() + timeout
    reannounce_count = 0
    last_snapshot = None

    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(
                "SPI timeout waiting for request buffer address at "
                f"0x{addr_register:08x}; last header={last_snapshot}, "
                f"reannounced={reannounce_count}"
            )

        if reannounce_count < SPI_REQUEST_REANNOUNCE_ATTEMPTS:
            wait_timeout = min(SPI_REQUEST_REANNOUNCE_INTERVAL, remaining)
        else:
            wait_timeout = remaining

        try:
            return _wait_spi_value(
                spi,
                addr_register,
                predicate,
                "request buffer address",
                timeout=wait_timeout,
            )
        except TimeoutError as error:
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    "SPI timeout waiting for request buffer address at "
                    f"0x{addr_register:08x}; last header={last_snapshot}, "
                    f"reannounced={reannounce_count}"
                ) from error

        try:
            snapshot = _read_stable_block(spi, header, 16).view(np.int32)
        except IOError:
            continue

        addr, signal, current_size, buffer_size = map(int, snapshot)
        last_snapshot = {
            "addr": addr,
            "signal": signal,
            "total_size": current_size,
            "buffer_size": buffer_size,
        }

        if predicate(addr):
            return addr

        if current_size == total_size:
            continue

        is_idle_reset = (
            addr == -1
            and signal == -1
            and current_size == -1
            and 0 < buffer_size <= SPI_WINDOW_SIZE
        )
        if is_idle_reset and reannounce_count < SPI_REQUEST_REANNOUNCE_ATTEMPTS:
            reannounce_count += 1
            spi.spi_write(
                total_size_register,
                np.array([total_size], np.uint32),
            )
            continue

        raise IOError(
            "Unexpected SPI request header while waiting for buffer address: "
            f"{last_snapshot}"
        )


def send(data, itf):
    data = append_crc32(data)
    display = console_handler.level <= logging.INFO

    if "local" in itf:
        reply = _send_uds(data, display=display)
    elif "spi" in itf or "usb" in itf:
        reply = _send_spi(data, spi_type=itf.split(":")[1], display=display)
    elif "ethernet" in itf or "tcp" in itf:
        reply = _send_tcp(data, itf.split(":")[1], display=display)
    else:
        logger.error(f"Invalid Interface \'{itf}\'")
        exit()

    code = reply["parameter"]["code"]
    status = True if code == 0 else False
    return code, status, reply

def _send_pipe(data, display):
    """Send tachy-rt on local system

    1. check if host is tachy device
    2. check if pipe is exist(name : "/tmp/tachy_rt")
    3. build tft binary and write to shm
    4. make shared memory
    5. send message to pipe 
    6. get result code

    Returns:
    if None, it means cannot detect any device.
    else New ``tachy_engine`` instance.
    """

    if not os.path.exists(INTERFACE_LOCAL_PIPE_R) or not os.path.exists(INTERFACE_LOCAL_PIPE_W):
        logger.error("Pipe doesn't exist")
        exit()

    size_err = np.array([data.nbytes, 0], np.uint32)
    with open(INTERFACE_LOCAL_PIPE_R, 'wb') as f:
        ''' Write 8byte data (size, err)'''
        f.write(size_err.tobytes())

        ''' Write data'''
        cnt = math.ceil(data.nbytes / 10000)
        for i in progressbar(range(cnt), "Sending: ", display=display):
            f.write(data.view(np.uint8)[i*10000:i*10000+10000])

    logger.info("waiting reply")
    with open(INTERFACE_LOCAL_PIPE_W, 'rb') as f:
        size_err = np.frombuffer(f.read(8), np.uint32)
        size = size_err[0]
        err  = size_err[1]
        if err != 0:
            reply = {"parameter": {"code": err}}
            return reply

        reply = f.read(size_err[0])
    logger.info("received reply")

    reply = commentjson.loads(reply)
    return reply

def _send_uds(data, display):
    def connect(uds_file):
        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(60)
            sock.connect(uds_file)
            return True, sock
        except:
            return False, None

    def send_data(sock):
        sent = 0
        left = np.array([data.nbytes, 0], np.uint32) # [n_bytes, error code]

        sock.send(left.tobytes())

        try:
            cnt = math.ceil(left[0] / 10000)
            for i in progressbar(range(cnt), "Sending: ", display=display):
                sock.send(data[sent:sent+10000])
                sent += 10000
            return True
        except Exception as e:
            return False

    def recv_data(sock):
        try:
            recvd = 0
            logger.info("waiting reply")
            size_err = np.frombuffer(sock.recv(8, socket.MSG_WAITALL), np.uint32)
            size = size_err[0]
            err  = size_err[1]
            if err != 0:
                reply = {"parameter": {"code": err}}
                return True, reply

            reply = bytearray(size)
            while recvd < size:
                buf = sock.recv(size - recvd)
                reply[recvd:recvd+len(buf)] = buf[:]
                recvd += len(buf)

            logger.info("received reply")
            return True, reply
        except:
            return False, None
    """Send tachy-rt on unix socket

    Returns:
    if None, it means cannot detect any device.
    else New ``tachy_engine`` instance.
    """
    if not os.path.exists(INTERFACE_LOCAL_UDS):
        logger.error("Unix domain socket doesn't exist")
        exit()

    is_suc, sock = connect(INTERFACE_LOCAL_UDS)
    if not is_suc:
        logger.error(f"Cannot connect to {INTERFACE_LOCAL_UDS}")
        exit()

    is_suc = send_data(sock)
    if not is_suc:
        logger.error(f"Error occurs when sending data")
        sock.close()
        exit()

    is_suc, reply = recv_data(sock)
    if not is_suc:
        logger.error(f"Error occurs when receiving data")
        sock.close()
        exit()

    reply = commentjson.loads(reply)
    return reply

def _send_tcp(data, ip, display):
    def connect(ip, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(60)
            sock.connect((ip,INTERFACE_ETHERNET_PORT))
            return True, sock
        except:
            return False, None

    def send_data(sock):
        sent = 0
        left = np.array([data.nbytes, 0], np.uint32) # [n_bytes, error code]

        sock.send(left.tobytes())

        try:
            cnt = math.ceil(left[0] / 10000)
            for i in progressbar(range(cnt), "Sending: ", display=display):
                sock.send(data[sent:sent+10000])
                sent += 10000
            return True
        except Exception as e:
            return False

    def recv_data(sock):
        try:
            recvd = 0
            logger.info("waiting reply")
            size_err = np.frombuffer(sock.recv(8, socket.MSG_WAITALL), np.uint32)
            size = size_err[0]
            err  = size_err[1]
            if err != 0:
                reply = {"parameter": {"code": err}}
                return True, reply

            reply = bytearray(size)
            while recvd < size:
                buf = sock.recv(size - recvd)
                reply[recvd:recvd+len(buf)] = buf[:]
                recvd += len(buf)

            logger.info("received reply")
            return True, reply
        except:
            return False, None

    """Send tachy-rt on ethernet system

    Returns:
    if None, it means cannot detect any device.
    else New ``tachy_engine`` instance.
    """
    is_suc, sock = connect(ip,INTERFACE_ETHERNET_PORT)
    if not is_suc:
        logger.error(f"Cannot connect to {ip}")
        exit()

    is_suc = send_data(sock)
    if not is_suc:
        logger.error(f"Error occurs when sending data")
        sock.close()
        exit()

    is_suc, reply = recv_data(sock)
    if not is_suc:
        logger.error(f"Error occurs when receiving data")
        sock.close()
        exit()

    reply = commentjson.loads(reply)
    return reply

def _send_spi(data, spi_type, display):
    def load_spi(spi_type):
        if spi_type == "ftdi":
            # from tachy_rt.utils import tachy_api
            # spi = tachy_api.spi
            from tachy_rt.utils import spi_bs_ftdi
            spi = spi_bs_ftdi.spi
            status = True
        elif spi_type == "host":
            from tachy_rt.utils import spi_bs_host
            spi = spi_bs_host.spi
            status = True
        else:
            spi = None
            status = False

        return status, spi

    """Scan tachy-rt on spi line

    Currently, only SPI connections using FTDI Chip 2232h are available.

    1. check if device is alive
    2. build tft binary and write to spi
    3. get result code

    Returns:
    if None, it means cannot detect any device.
    else New ``tachy_engine`` instance.
    """
    is_suc, spi = load_spi(spi_type)
    if not is_suc:
        logger.error(f"Cannot load spi \'{spi_type}\'")
        exit()

    _spi_write(
        spi,
        np.array([data.nbytes, 0], np.uint32),
        display,
        allow_request_reannounce=True,
    )
    _spi_write(spi, data, display)

    logger.info("waiting reply")
    length = _spi_read(spi, 4, display).view(np.int32)[0]
    reply = _spi_read(spi, length, display).tobytes()
    
    reply = commentjson.loads(reply)

    return reply

def _spi_read(spi, size, display):
    cnt        = 0
    addr       = 0
    read_data  = []

    ''' 1. wait until total size is valid '''
    total_size = _wait_spi_value(
        spi,
        INTERFACE_SPI_WRITER_HEADER + 0x8,
        lambda value: value > 0,
        "reply size",
        timeout=SPI_REPLY_POLL_TIMEOUT,
    )

    ''' 2. reset total size '''
    spi.spi_write(INTERFACE_SPI_WRITER_HEADER + 0x8, np.array([0xffff_ffff], np.uint32))

    ''' 3. calc cnt '''
    buffer_size = _read_stable_block(
        spi,
        INTERFACE_SPI_WRITER_HEADER + 0xC,
        4,
    ).view(np.int32)[0]
    if not 0 < buffer_size <= SPI_WINDOW_SIZE:
        raise IOError(f"Invalid SPI reply buffer size: {int(buffer_size)}")
    cnt = math.ceil(total_size / buffer_size)
    if cnt <= 0:
        return np.array([], dtype=np.uint8)

    for i in progressbar(range(cnt), "Receiving: ", display=display):
        ''' 4. wait until addr is valid '''
        addr = _wait_spi_value(
            spi,
            INTERFACE_SPI_WRITER_HEADER,
            lambda value: _valid_spi_buffer(
                value,
                INTERFACE_SPI_WRITER_HEADER,
            ),
            "reply buffer address",
            timeout=SPI_REPLY_POLL_TIMEOUT,
        )

        ''' 5. reset addr '''
        spi.spi_write(INTERFACE_SPI_WRITER_HEADER, np.array([0xffff_ffff], np.uint32))

        ''' 6. read data from addr '''
        stt = 0
        end = 0
        max_size = buffer_size * (i+1)

        if max_size > total_size: # Total size를 넘어가는 경우(마지막 Index)
            stt = buffer_size * i
            end = max_size - (max_size - total_size)
        else:
            stt = buffer_size * i
            end = buffer_size * (i + 1)
        read_data.append(_read_stable_block(spi, addr, end-stt))

        ''' 7. set done signal '''
        spi.spi_write(INTERFACE_SPI_WRITER_HEADER + 0x4, np.array([1], np.uint32))

    return np.concatenate(read_data)

def _spi_write(spi, data, display, allow_request_reannounce=False):
    cnt         = 0
    buffer_size = 0

    ''' 1. wait until total size is available '''
    _wait_spi_value(
        spi,
        INTERFACE_SPI_READER_HEADER + 0x8,
        lambda value: value == -1,
        "available request slot",
    )

    ''' 2. set total size '''
    total_size = data.nbytes
    spi.spi_write(INTERFACE_SPI_READER_HEADER + 0x8, np.array([data.nbytes], np.uint32))

    ''' 3. calc cnt '''
    buffer_size = _read_stable_block(
        spi,
        INTERFACE_SPI_READER_HEADER + 0xC,
        4,
    ).view(np.int32)[0]
    if not 0 < buffer_size <= SPI_WINDOW_SIZE:
        raise IOError(f"Invalid SPI request buffer size: {int(buffer_size)}")
    cnt = math.ceil(data.nbytes / buffer_size)
    if cnt <= 0:
        return np.array([], dtype=np.uint8)

    ''' 4. do send loop '''
    for i in progressbar(range(cnt), "Sending: ", display=display):
        ''' 4-1) wait until addr is valid and read addr '''
        addr = _wait_request_buffer_address(
            spi,
            total_size,
            allow_reannounce=allow_request_reannounce and i == 0,
        )

        ''' 4-2) reset addr '''
        spi.spi_write(INTERFACE_SPI_READER_HEADER, np.array([0xffff_ffff], np.uint32))

        ''' 4-3) write data '''
        stt = 0;
        end = 0;
        max_size = buffer_size * (i + 1)

        if max_size > total_size: # Total size를 넘어가는 경우(마지막 Index)
            stt = buffer_size * i
            end = stt + (buffer_size - (max_size - total_size))
        else:
            stt = buffer_size * i
            end = buffer_size * (i + 1)

        _write_verified_block(spi, addr, data[stt:end])

        ''' 5. write done signal '''
        spi.spi_write(INTERFACE_SPI_READER_HEADER + 0x4, np.array([1], np.uint32))
