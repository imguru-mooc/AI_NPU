from abc import *

class instance(metaclass=ABCMeta):
    @abstractmethod
    def process(self, data=None):
        ...

    @abstractmethod
    def deinit(self):
        ...
