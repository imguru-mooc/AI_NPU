import os, sys
import numpy as np
from turbojpeg import TurboJPEG, TJPF_RGB, TJPF_BGR, TJFLAG_PROGRESSIVE, TJFLAG_FASTUPSAMPLE, TJFLAG_FASTDCT
from tachy_rt.utils.constants import *

try:
    jpeg = TurboJPEG()
except:
    jpeg = None
    print("[WARNING] Cannot find turbojpeg library")


def cvt_input_binary(_input:np.ndarray, data_type:int):
    if data_type == DTYPE_FLOAT16 : _input = _input.transpose(0, 1, 3, 2).astype(np.float16).byteswap() # (b, h, d, w)
    elif data_type == DTYPE_UINT8 : _input = _input.transpose(0, 1, 3, 2) # (b, h, d, w)
    else:
        print("error dtype :", data_type)
        exit()

    return _input

def cvt_input_jpeg(_input:np.ndarray):
    global jpeg
    enc_img = jpeg.encode(_input, pixel_format=TJPF_BGR, quality=80) # img(rgb), format(bgr)
    enc_img = np.frombuffer(enc_img, np.uint8)
    enc_img = np.concatenate([np.array([enc_img.size], np.uint32).view(np.uint8), enc_img]).reshape(1,1,1,enc_img.size+4) # [b, h, d, w]

    return enc_img

def cvt_input_sensor(_input:np.ndarray):
    return np.empty(0)
