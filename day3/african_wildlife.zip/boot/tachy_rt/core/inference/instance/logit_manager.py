import os, sys
import numpy as np
from tachy_rt.utils.constants import *

def cvt_logit_order(n_batch:int, output_shape:list, logit:np.ndarray) -> np.ndarray:
    arr = []
    offset = 0
    for batch in range(n_batch):
        for shape in output_shape:
            h, w, dummy_d, valid_d = shape
            arr.append(logit[offset : offset+h*w*dummy_d].byteswap().reshape(h, dummy_d, w)[:, :valid_d, :].transpose(0, 2, 1).reshape(-1))
            offset += h*w*dummy_d

    if len(arr) > 0: ret = np.concatenate(arr)
    else:            ret = np.empty((0), dtype=np.float32)
    return ret.astype(np.float32)
