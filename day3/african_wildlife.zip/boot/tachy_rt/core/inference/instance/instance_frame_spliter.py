import time
import math
import commentjson
import ctypes
import numpy as np
import tachy_rt.core.functions as rt_core
import tachy_rt.core.inference.instance.input_manager as input_manager
import tachy_rt.core.inference.instance.logit_manager as logit_manager
from queue import Queue
from tachy_rt.utils.logger import *
from tachy_rt.utils.constants import *
from tachy_rt.utils.app_class import *
from tachy_rt.core.inference.instance.instance import *
from threading import Thread

class instance_fs(instance):
    def __init__(self, fe, be, config):
        '''Set default values of properties

        Properties
        ----------
        self.fe          : pipe,   path for request
        self.be          : pipe,   path to get result
        self.config      : dict,   configuration with default values
        self.status      : int,    status for inference(STATUS_MANUAL or STATUS_AUTO)
        self.process_cnt : int,    the number of times the process method has been called (also indicates the current buffer number)
        self.done_cnt    : int,    the number of times the get_result method was called to get the result
        self.max_buf     : int,    max number of buffer
        self.pre_process : string, inference mode
        self.lm          : class,  logit manager
        self.im          : class,  input manager
        self.stt_q       : queue,  stores numbers of buffers that can be processed
        '''
        self.fe = fe
        self.be = be
        self.config = config
        self.process_cnt = -1
        self.done_cnt = -1
        self.buf_num = -1
        self.max_batch = -1
        self.pre_prcess = None
        self.stt_q = None

        self._init()

    def _init(self):
        '''Initialize tachy engine

        The initialization sequence is as follows
         1) Init properties
         2) Get configuration
         3) create logit mamanger, input manager object

        '''
        self.process_cnt = 0
        self.done_cnt = 0
        self.name         = self.config["algorithm_config"]["name"]
        self.buf_num      = self.config["algorithm_config"]["buf_num"]
        self.max_batch    = self.config["algorithm_config"]["max_batch"]
        self.data_type    = self.config["algorithm_config"]["data_type"]
        self.input_shape  = self.config["algorithm_config"]["input_shape"]
        self.output_shape = self.config["algorithm_config"]["output_shape"]
        self.input_method = self.config["algorithm_config"]["input_format"]
        self.input_num    = len(self.input_method)
        self.reorder = self.config["algorithm_config"]["reorder"]

        # if use picture mode
        self.raw  = []
        self.crop = []
        for i, method in enumerate(self.input_method):
            if method == INPUT_FMT_SENSOR:
                ratio = rt_core.get_sensor_ratio(self.input_shape[i][0], self.input_shape[i][1])
                org_w = 1920 // ratio
                org_h = 1080 // ratio
                self.raw.append([org_h,org_w,3])
                self.crop.append([0,0,org_w-1,org_h-1])
            else:
                self.raw.append(self.input_shape[i])
                self.crop.append([0,0,self.input_shape[i][1]-1,self.input_shape[i][0]-1])
        self.raw  = np.array(self.raw).astype(np.uint32)
        self.crop = np.tile(np.array(self.crop).reshape(-1,1,4), (1,self.max_batch,1)).astype(np.uint32)

        self.stt_q = Queue(maxsize=self.buf_num)
        for i in range(self.buf_num):
            self.stt_q.put(i)

    def process(self, data=None, n_batch=1, raw=None, crop=None):
        self.stt_q.get()
        index = self._get_cur_idx()

        if n_batch > self.max_batch:
            print("Batch size error(max : {}, cur : {})".format(self.max_batch, n_batch))
            exit(-1)

        if data is not None and len(data) > 0:
            self._set_input(data)
            n_batch = len(data)

        if n_batch > 0:
            crop_n_resize = self._merge_raw_crop(raw, crop)
        else:
            crop_n_resize = np.empty(0)

        cmd = CMD_APPLICATION_INFERENCE if n_batch != 0 else CMD_APPLICATION_INFERENCE_DUMMY

        self._write(index=index, n_batch=n_batch, cmd=cmd, _length=crop_n_resize.nbytes, data=crop_n_resize)
        self.process_cnt += 1

    '''
    data.shape = (B,H,W,D)
    When call process_batch func, number of input must be 1
    TODO: Later, letting the compiler set the batch to width flag
    '''
    def process_batch(self, data):
        batch = data.shape[0]
        n_batch = self.input_shape[0][1]
        loop_cnt = math.ceil(batch / n_batch)

        th = Thread(target=self._process_batch, args=(batch, n_batch, data))
        th.start()

        logits = []
        for i in range(loop_cnt):
            _dict = self.get_result()
            logits.append(_dict['buf'])
            self.done_cnt += 1
        th.join()

        out_d = self.output_shape[-1][-1]
        valid = loop_cnt * n_batch
        if (batch % n_batch) > 0:
            valid -= (n_batch - (batch % n_batch))
        return np.array(logits, np.float16).reshape(-1, out_d)[:valid, ...]

    def get_result(self):
        '''Get inference done signal from tachy_rt and read logit from logit manager

        on local environment, uses shared memory for performance

        returns
        -------
        dict : Dictionary
            same as the return value of the self._read method

        '''
        _dict = self._read()

        if self.reorder:
            _dict['buf'] = _dict['buf'].view(np.float32)
        else:
            _dict['buf'] = _dict['buf'].view(np.float16)
            _dict['buf'] = logit_manager.cvt_logit_order(_dict['n_batch'], self.output_shape, _dict['buf'])

        self.stt_q.put(_dict['index'])
        self.done_cnt += 1
        return _dict

    def deinit(self):
        self._write(index=0, n_batch=0, cmd=CMD_DEINIT, _length=0, data=None)

    def _write(self, index, n_batch, cmd, _length, data):
        '''Send request to tachy_rt

        Arguments
        ---------
        index   : buffer index
        n_batch : num of inputs(only valid when process method is called)
        cmd     : command
        data    : data about command

        '''
        protocol = ApplicationProtocol(index=index,
                                       n_batch=n_batch,
                                       cmd=cmd,
                                       length=_length)
        self.fe.send(ctypes.sizeof(protocol), bytearray(protocol))
        if _length > 0: self.fe.send(_length, data.tobytes())

    def _read(self):
        ''' Receive data from interface layer

        Returns
        -------
        dict : dictionary
            dictionary have 5 information
            dict['index']   = index for current buffer(only valid when read reply of process method)
            dict['n_batch'] = number of input(only valid when read reply of process method)
            dict['cmd']     = command for request
            dict['length']  = length for arguments
            dict['buf']     = arguments for reply

        '''
        ret = ApplicationProtocol()
        protocol_recv = self.be.receive(ctypes.sizeof(ApplicationProtocol))
        ctypes.memmove(ctypes.pointer(ret), protocol_recv, ctypes.sizeof(ApplicationProtocol))
        buf = np.zeros(ret.length, np.uint8)

        read_len = 0
        while read_len < ret.length:
            tmp = np.frombuffer(self.be.receive(ret.length - read_len), np.uint8)
            buf[read_len:read_len+tmp.nbytes] = tmp
            read_len += tmp.nbytes

        _dict = {
            'index': ret.index,
            'n_batch': ret.n_batch,
            'cmd': ret.cmd,
            'length': ret.length,
            'buf': buf
        }
        return _dict

    def _get_cur_idx(self):
        return self.process_cnt % self.buf_num

    def _cvt_input(self, data:np.ndarray, method:int) -> np.ndarray:
        if data is None:
            return np.empty(0)

        if method == INPUT_FMT_BINARY:
            return input_manager.cvt_input_binary(data, self.data_type)
        elif method == INPUT_FMT_JPEG:
            return input_manager.cvt_input_jpeg(data)
        elif method == INPUT_FMT_SENSOR:
            return input_manager.cvt_input_sensor(data)
        else:
            return np.empty(0)

    def _set_input(self, datas:list=None):
        '''
        shape of data must be (n, m) and each data must be numpy array(h,w,d) or None
         => n : num of batch
         => m : num of input
        example) [[image np array, None]] => 1,2 = 1 batch, 2 input
        '''
        index = self._get_cur_idx()

        # Check if datas is None
        if datas is None:
            return False

        # Check if input batch is bigger than max_batch
        n_batch = len(datas)
        n_input = self.input_num
        if n_batch > self.max_batch:
            assert("input batch({}) is bigger than max_batch({})".format(n_input, self.max_batch))

        data_to_send = []
        data_to_send.append(np.array([n_batch], np.uint32).view(np.uint8))
        data_to_send.append(np.array([n_input], np.uint32).view(np.uint8))
        for i in range(n_batch):
            # TODO: add assert
            data = datas[i]

            for j in range(self.input_num):
                d = self._cvt_input(data[j], self.input_method[j]).copy()
                data_to_send.append(np.array([d.nbytes], np.uint32).view(np.uint8).reshape(-1))
                data_to_send.append(d.view(np.uint8).reshape(-1))

        # data_to_send_2 = np.concatenate([x for x in data_to_send], dtype=np.uint8)
        data_to_send_2 = np.concatenate([x for x in data_to_send]) # for numpy version compatibility

        index = self._get_cur_idx()
        self._write(index=index, n_batch=0, cmd=CMD_APPLICATION_SET_INPUT, _length=data_to_send_2.nbytes, data=data_to_send_2)


    # For batch -> width case(TODO: merge with process method)
    def _process_batch(self, total_batch, unit_batch, data):
        total_batch = data.shape[0]
        cmd = CMD_APPLICATION_INFERENCE

        for i in range(math.ceil(total_batch / unit_batch)):
            self.stt_q.get()
            index = self._get_cur_idx()

            d = data[i*unit_batch:(i+1)*unit_batch].transpose(2, 1, 0, 3).copy() # (B,H,W,D -> W,H,B,D)

            if (d.shape[2] % unit_batch) > 0:
                d_shape = d.shape
                dummy = np.zeros((d_shape[0], d_shape[1], unit_batch, d_shape[3]), dtype=d.dtype)
                dummy[:,:,:d.shape[2],...] = d[:]
                d = dummy

            self._set_input([[d]])
            n_batch = 1

            self._write(index=index, n_batch=n_batch, cmd=cmd, _length=0, data=None)
            self.process_cnt += 1

    def _merge_raw_crop(self, raw, crop):
        '''
         => n = num of input
         => m = num of batch
        raw.shape  = (n, 3)
        crop.shape = (n, m, 4)
        '''
        if raw is None or crop is None:
            raw  = self.raw
            crop = self.crop
            # return np.empty(0)

        n_raw  = np.array([raw.shape[0]], np.int32)
        n_crop = np.array([crop.shape[0] * crop.shape[1]], np.int32)
        raw    = raw.astype(np.int32).reshape(-1)
        crop   = crop.astype(np.int32).reshape(-1)

        # return np.concatenate([n_raw, n_crop, raw, crop], dtype=np.int32)
        return np.concatenate([n_raw, n_crop, raw, crop]) # for numpy version compatibility
