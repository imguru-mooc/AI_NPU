import struct
import time

import numpy as np

import tachy_rt.core.inference.instance.logit_manager as logit_manager
from tachy_rt.utils.constants import (
    STANDALONE_ABI_VERSION,
    STANDALONE_BUFFER_CAPACITY,
    STANDALONE_DATA_FLOAT32,
    STANDALONE_META_ADDR,
    STANDALONE_OUTPUT_CAPACITY,
    STANDALONE_PUBLISH_ANNOTATION,
    STANDALONE_PUBLISH_RAW,
    STANDALONE_SLOT_CAPACITY,
    STANDALONE_STATE_ERROR,
    STANDALONE_STATE_READY,
    STANDALONE_STATE_STARTING,
)


class StandaloneReader:
    MAGIC = b"TSA1"
    HEADER = struct.Struct("<4sHHIII44x")
    SLOT_FIXED = struct.Struct("<64s9I10I")
    OUTPUT_SHAPE = struct.Struct("<4I")
    DESCRIPTOR = struct.Struct("<7I")
    SLOT_SIZE = 448
    GENERATION_OFFSET = 68
    BUFFER_GENERATION_OFFSET = 100
    DESCRIPTOR_OFFSET = 140 + (STANDALONE_OUTPUT_CAPACITY * OUTPUT_SHAPE.size)

    def __init__(self, instance_name, spi_type="host", poll_interval=0.005,
                 spi=None, reorder=True):
        self.instance_name = instance_name
        self.spi_type = spi_type
        self.poll_interval = poll_interval
        self.reorder = reorder
        self.spi = spi if spi is not None else self._load_spi(spi_type)
        self.slot_index = None
        self.state = 0
        self.last_error_code = 0
        self.last_generation = 0
        self.last_metadata_generation = 0
        self._locate_slot()

    @staticmethod
    def _load_spi(spi_type):
        if spi_type == "host":
            from tachy_rt.utils.spi_bs_host import spi
            return spi
        if spi_type == "ftdi":
            from tachy_rt.utils import spi_bs_ftdi
            return spi_bs_ftdi.spi
        raise ValueError("spi_type must be 'host' or 'ftdi'")

    def _read_bytes(self, address, size):
        data = self.spi.spi_read(address, size)
        return np.asarray(data, dtype=np.uint8).reshape(-1).tobytes()

    def _read_header(self):
        raw = self._read_bytes(STANDALONE_META_ADDR, self.HEADER.size)
        magic, version, header_size, slot_capacity, slot_size, active_slots = self.HEADER.unpack(raw)
        if magic != self.MAGIC:
            raise ValueError("invalid standalone metadata magic")
        if version != STANDALONE_ABI_VERSION:
            raise ValueError("unsupported standalone metadata version: {}".format(version))
        if header_size != self.HEADER.size or slot_size != self.SLOT_SIZE:
            raise ValueError("invalid standalone metadata layout")
        if slot_capacity <= 0 or slot_capacity > STANDALONE_SLOT_CAPACITY:
            raise ValueError("invalid standalone slot capacity")
        return {
            "header_size": header_size,
            "slot_capacity": slot_capacity,
            "slot_size": slot_size,
            "active_slots": active_slots,
        }

    def _slot_address(self, slot_index):
        return STANDALONE_META_ADDR + self.HEADER.size + (slot_index * self.SLOT_SIZE)

    def _parse_slot(self, raw):
        fixed = self.SLOT_FIXED.unpack(raw[:self.SLOT_FIXED.size])
        name = fixed[0].split(b"\0", 1)[0].decode("utf-8")
        state, generation, index, address, length, n_batch, output_count, error_code, buffer_count = fixed[1:10]
        if output_count > STANDALONE_OUTPUT_CAPACITY:
            raise ValueError("invalid standalone output count")
        if name and (buffer_count <= 0 or buffer_count > STANDALONE_BUFFER_CAPACITY):
            raise ValueError("invalid standalone buffer count")

        buffer_generations = list(fixed[10:10 + STANDALONE_BUFFER_CAPACITY])

        output_shapes = []
        offset = self.SLOT_FIXED.size
        for _ in range(output_count):
            output_shapes.append(list(self.OUTPUT_SHAPE.unpack(raw[offset:offset + self.OUTPUT_SHAPE.size])))
            offset += self.OUTPUT_SHAPE.size

        descriptor = self.DESCRIPTOR.unpack(
            raw[self.DESCRIPTOR_OFFSET:self.DESCRIPTOR_OFFSET + self.DESCRIPTOR.size])
        (publish_flags, post_type, annotation_address, annotation_length,
         annotation_count, annotation_stride, annotation_dtype) = descriptor
        if name and (publish_flags == 0 or publish_flags & ~(
                STANDALONE_PUBLISH_RAW | STANDALONE_PUBLISH_ANNOTATION)):
            raise ValueError("invalid standalone publish flags")

        return {
            "name": name,
            "state": state,
            "generation": generation,
            "index": index,
            "address": address,
            "length": length,
            "n_batch": n_batch,
            "output_count": output_count,
            "output_shapes": output_shapes,
            "error_code": error_code,
            "buffer_count": buffer_count,
            "buffer_generations": buffer_generations,
            "publish_flags": publish_flags,
            "post_type": post_type,
            "annotation_address": annotation_address,
            "annotation_length": annotation_length,
            "annotation_count": annotation_count,
            "annotation_stride": annotation_stride,
            "annotation_dtype": annotation_dtype,
        }

    def _read_slot(self, slot_index=None):
        if slot_index is None:
            slot_index = self.slot_index
        raw = self._read_bytes(self._slot_address(slot_index), self.SLOT_SIZE)
        slot = self._parse_slot(raw)
        self.state = slot["state"]
        self.last_error_code = slot["error_code"]
        return slot

    def _locate_slot(self):
        header = self._read_header()
        for slot_index in range(header["slot_capacity"]):
            slot = self._read_slot(slot_index)
            if slot["name"] == self.instance_name:
                self.slot_index = slot_index
                return
        raise ValueError("standalone instance metadata not found: {}".format(self.instance_name))

    def _read_u32(self, offset):
        raw = self._read_bytes(self._slot_address(self.slot_index) + offset, 4)
        return struct.unpack("<I", raw)[0]

    def _read_stable_slot(self):
        for _ in range(3):
            slot = self._read_slot()
            generation = self._read_u32(self.GENERATION_OFFSET)
            if slot["generation"] != 0 and slot["generation"] % 2 == 0 and slot["generation"] == generation:
                return slot
        return None

    def _read_buffer_generation(self, index):
        return self._read_u32(self.BUFFER_GENERATION_OFFSET + (index * 4))

    def _read_coherent(self, first):
        for _ in range(3):
            if first is None or first["state"] != STANDALONE_STATE_READY:
                return None
            if first["n_batch"] == 0:
                return None
            if first["index"] >= first["buffer_count"]:
                raise ValueError("invalid standalone buffer index")

            buffer_generation = first["buffer_generations"][first["index"]]
            if buffer_generation == 0 or buffer_generation % 2 != 0:
                first = self._read_stable_slot()
                continue

            has_raw = bool(first["publish_flags"] & STANDALONE_PUBLISH_RAW)
            has_annotation = bool(
                first["publish_flags"] & STANDALONE_PUBLISH_ANNOTATION)

            raw = None
            if has_raw:
                if first["address"] == 0 or first["length"] == 0:
                    raise ValueError("invalid standalone raw descriptor")
                expected_length = first["n_batch"] * sum(
                    shape[0] * shape[1] * shape[2] * 2
                    for shape in first["output_shapes"])
                if first["length"] != expected_length:
                    raise ValueError("standalone result length does not match output shapes")
                raw = self._read_bytes(first["address"], first["length"])

            annotation_raw = b""
            if has_annotation:
                if (first["annotation_address"] == 0 or
                        first["annotation_stride"] != 6 or
                        first["annotation_dtype"] != STANDALONE_DATA_FLOAT32):
                    raise ValueError("invalid standalone annotation descriptor")
                if first["annotation_count"] > 30:
                    raise ValueError("standalone annotation count exceeds maximum")
                expected_annotation_length = (
                    first["annotation_count"] * first["annotation_stride"] * 4)
                if first["annotation_length"] != expected_annotation_length:
                    raise ValueError("standalone annotation length does not match count")
                if first["annotation_length"]:
                    annotation_raw = self._read_bytes(
                        first["annotation_address"], first["annotation_length"])

            second_buffer_generation = self._read_buffer_generation(first["index"])
            if buffer_generation == second_buffer_generation and second_buffer_generation % 2 == 0:
                buf = None
                if has_raw:
                    raw_logit = np.frombuffer(raw, dtype=np.float16)
                    if self.reorder:
                        buf = logit_manager.cvt_logit_order(
                            first["n_batch"], first["output_shapes"], raw_logit)
                    else:
                        buf = raw_logit.byteswap()

                annotations = None
                if has_annotation:
                    annotations = np.frombuffer(
                        annotation_raw, dtype="<f4").copy().reshape(
                            first["annotation_count"], first["annotation_stride"])
                self.last_generation = first["generation"]
                return {
                    "index": first["index"],
                    "generation": first["generation"],
                    "buffer_generation": buffer_generation,
                    "address": first["address"],
                    "length": first["length"],
                    "n_batch": first["n_batch"],
                    "buf": buf,
                    "annotations": annotations,
                    "publish_flags": first["publish_flags"],
                    "post_type": first["post_type"],
                    "annotation_address": first["annotation_address"],
                    "annotation_length": first["annotation_length"],
                    "annotation_count": first["annotation_count"],
                    "annotation_stride": first["annotation_stride"],
                }
            print(
                "[WARN] standalone output buffer was reused while reading: "
                f"index={first['index']} "
                f"generation={buffer_generation}->{second_buffer_generation}",
                flush=True,
            )
            first = self._read_stable_slot()
        return None

    def read_latest(self):
        """Return the latest coherent result, or None before a result is ready."""
        slot = self._read_stable_slot()
        if slot is None:
            return None
        if slot["state"] == STANDALONE_STATE_ERROR:
            return None
        return self._read_coherent(slot)

    def read_metadata(self):
        """Return one metadata snapshot without reading or rechecking output memory."""
        slot = self._read_slot()
        if (slot["state"] != STANDALONE_STATE_READY or
                slot["generation"] == 0 or slot["generation"] % 2 != 0):
            return None
        if slot["index"] >= slot["buffer_count"]:
            raise ValueError("invalid standalone buffer index")

        return {
            "state": slot["state"],
            "generation": slot["generation"],
            "index": slot["index"],
            "address": slot["address"],
            "length": slot["length"],
            "n_batch": slot["n_batch"],
            "buffer_count": slot["buffer_count"],
            "buffer_generation": slot["buffer_generations"][slot["index"]],
            "error_code": slot["error_code"],
            "publish_flags": slot["publish_flags"],
            "post_type": slot["post_type"],
            "annotation_address": slot["annotation_address"],
            "annotation_length": slot["annotation_length"],
            "annotation_count": slot["annotation_count"],
            "annotation_stride": slot["annotation_stride"],
            "annotation_dtype": slot["annotation_dtype"],
        }

    def wait_next_metadata(self, timeout=None):
        """Wait for a newly published descriptor without reading its payload."""
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            metadata = self.read_metadata()
            if (metadata is not None and
                    metadata["generation"] != self.last_metadata_generation):
                self.last_metadata_generation = metadata["generation"]
                return metadata

            if self.state == STANDALONE_STATE_ERROR:
                return None
            if deadline is not None and time.monotonic() >= deadline:
                return None
            time.sleep(self.poll_interval)

    def wait_next(self, timeout=None):
        """Wait for a generation newer than the last successful read."""
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            slot = self._read_stable_slot()
            if slot is None:
                if deadline is not None and time.monotonic() >= deadline:
                    return None
                time.sleep(self.poll_interval)
                continue
            if slot["state"] == STANDALONE_STATE_ERROR:
                return None
            if slot["state"] not in (STANDALONE_STATE_READY, STANDALONE_STATE_STARTING):
                return None
            if slot["state"] == STANDALONE_STATE_READY and slot["generation"] != self.last_generation:
                result = self._read_coherent(slot)
                if result is not None:
                    return result

            if deadline is not None and time.monotonic() >= deadline:
                return None
            time.sleep(self.poll_interval)
