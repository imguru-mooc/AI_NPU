import os, sys
import numpy as np

class config_manager:
    def __init__(self, cfg_req, cfg_mem):
        self.cfg_req = cfg_req
        self.cfg_mem = cfg_mem

        del self.cfg_req["NETWORK"]["instruction"]
        del self.cfg_req["NETWORK"]["parameter"]

    def get_interface_code(self):
        return self.cfg_req["FRONTEND"]["mode"]

    def get_spi_type(self):
        ret = ""
        if "spi" in self.cfg_req["INTERFACE"]["mode"]:
            ret = self.cfg_req["INTERFACE"]["mode"].split(':')[-1]

        return ret

    def get_global_name(self):
        return self.cfg_req["GLOBAL"]["name"]

    def get_global_dtype(self):
        return self.cfg_req["GLOBAL"]["data_type"]

    def get_global_data_size(self):
        return 2 if self.cfg_req["GLOBAL"]["data_type"] == DTYPE_FLOAT16 else 1

    def get_global_buf_num(self):
        return self.cfg_req["GLOBAL"]["buf_num"]

    def get_global_npu_mask(self):
        return self.cfg_req["GLOBAL"]["npu_mask"]

    def get_global_max_input(self):
        return self.cfg_req["GLOBAL"]["max_input"]

    def get_global_pre_process(self):
        return self.cfg_req["GLOBAL"]["pre_process"]

    def get_global_std(self):
        return self.cfg_req["GLOBAL"]["std"]

    def get_global_mean(self):
        return self.cfg_req["GLOBAL"]["mean"]

    # def get_global_input_dump(self):
    #     return self.cfg["GLOBAL"]["input_dump"]

    def get_global_init(self):
        return self.cfg_req["GLOBAL"]["init"]

    # def get_sensor_fmt(self):
    #     return self.cfg_req["SENSOR"]["fmt"]

    def get_sensor_tx(self):
        return self.cfg_req["SENSOR"]["tx"]

    # def get_sensor_base(self):
    #     return self.cfg_req["SENSOR"]["base"]

    # def get_sensor_offset(self):
    #     return self.cfg_req["SENSOR"]["offset"]

    def get_sensor_rolling_buf(self):
        return self.cfg_req["SENSOR"]["rolling_buf"]

    def get_sensor_crop_shape(self):
        return self.cfg_req["SENSOR"]["sensor_crop_shape"]

    def get_sensor_ratio_shape(self):
        return self.cfg_req["SENSOR"]["sensor_ratio_shape"]

    def get_sensor_inst_crop_shape(self):
        return self.cfg_req["SENSOR"]["sensor_inst_crop_shape"]

    def get_sensor_inst_input_shape(self):
        return self.cfg_req["SENSOR"]["sensor_inst_input_shape"]

    def get_sensor_inverse_data(self):
        return self.cfg_req["SENSOR"]["inverse_data"]

    def get_sensor_inverse_sync(self):
        return self.cfg_req["SENSOR"]["inverse_sync"]

    def get_sensor_inverse_clock(self):
        return self.cfg_req["SENSOR"]["inverse_clock"]

    # def get_network_inst_pointer(self):
    #     pass

    # def get_network_inst_size(self):
    #     pass

    # def get_network_param_pointer(self):
    #     pass

    # def get_network_param_size(self):
    #     pass

    def get_network_n_block(self):
        return self.cfg_req["NETWORK"]["layer"]["n_block"]

    def get_network_logit_block_num(self):
        count = 0
        num = self.get_network_n_block()
        for i in range(len(num)):
            if self.get_network_block_is_result(i):
                count += 1

        return count

    def get_network_total_logit_size(with_dummy):
        total_size = 0
        logit_block_indexs = self.get_network_logit_block_index()

        for i in logit_block_indexs:
            output_shape = self.get_network_block_output_shape(i)
            kernel_shape = self.get_network_block_kernel_shape(i)
            h = output_shape[0]
            w = output_shape[1]
            d = kernel_shape[2] if with_dummy else output_shape[2]
            total_size += (h * w * d)

        return total_size

    def get_network_block_mode(self):
        pass
    def get_network_block_input_from(self):
        pass
    def get_network_block_input_offset(self):
        pass
    def get_network_block_param_offset(self):
        pass
    def get_network_block_residual_with(self):
        pass
    def get_network_block_is_start(self):
        pass
    def get_network_block_is_residual(self):
        pass
    def get_network_block_is_result(self, i):
        return self.cfg_req["NETWORK"]["layer"][str(i)]["is_result"]

    def get_network_block_output_length(self, with_dummy, is_size):
        pass

    def get_network_block_output_to(self):
        pass

    def get_network_block_output_shape(self):
        pass

    def get_network_block_kernel_shape(self):
        pass

    def get_network_logit_block_index(self):
        indexs = []
        num = self.get_network_n_block()
        for i in range(len(num)):
            if self.get_network_block_is_result(i):
                indexs.append(i)

        return indexs

    def get_network_use_scaler(self):
        pass

    def get_input_format(self):
        return self.cfg_req["INPUT"][str(0)]["method"]

    def get_output_copy(self):
        pass

    def get_output_reorder(self):
        pass

    def get_mem_frontend(self):
        pass

    def get_mem_backend(self):
        pass

    def get_mem_input(self):
        return self.cfg_mem["mem_input"]

    def get_mem_input_addr(self):
        pass

    def get_mem_input_size(self):
        pass

    def get_mem_input_offset(self):
        pass

    def get_mem_input_num(self):
        pass

    def get_mem_inst_scaler_addr(self):
        pass

    def get_mem_inst_scaler_size(self):
        pass

    def get_mem_inst_scaler_offset(self):
        pass

    def get_mem_inst_scaler_num(self):
        pass

    def get_mem_inst_network_addr(self):
        pass

    def get_mem_inst_network_size(self):
        pass

    def get_mem_inst_network_offset(self):
        pass

    def get_mem_inst_network_num(self):
        pass

    def get_mem_param_addr(self):
        pass

    def get_mem_param_size(self):
        pass

    def get_mem_layer_addr(self):
        pass

    def get_mem_layer_size(self):
        pass

    def get_mem_layer_offset(self):
        pass

    def get_mem_layer_num(self):
        pass

    def get_mem_output_addr(self):
        pass

    def get_mem_output_size(self):
        pass

    def get_mem_output_num(self):
        pass

    def set_mem_summary(self, mem_cfg):
        pass
