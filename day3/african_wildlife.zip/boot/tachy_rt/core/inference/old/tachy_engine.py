import time
import math
import commentjson
import ctypes
import numpy as np
from queue import Queue
from tachy_rt.utils.logger import *
from tachy_rt.utils.constants import *
from tachy_rt.utils.app_class import *
# from tachy_rt.core.inference.inputmanager import *
# from tachy_rt.core.inference.logitmanager import *
from threading import Thread

class tachy_engine:
    def __init__(self, fe, be, config, init_config, im, lm):
        '''Set default values of properties

        Properties
        ----------
        self.fe          : pipe,   path for request
        self.be          : pipe,   path to get result
        self.config_static      : dict,   configuration with default values
        self.config_runtime : dict,   information about the memory allocated to the Network currently in use
        self.status      : int,    status for inference(STATUS_MANUAL or STATUS_AUTO)
        self.process_cnt : int,    the number of times the process method has been called (also indicates the current buffer number)
        self.done_cnt    : int,    the number of times the get_result method was called to get the result
        self.max_buf     : int,    max number of buffer
        self.pre_process : string, inference mode
        self.lm          : class,  logit manager
        self.im          : class,  input manager
        self.stt_q       : queue,  stores numbers of buffers that can be processed
        '''
        self.fe = fe
        self.be = be
        self.config_static = config
        self.config_runtime = init_config
        self.process_cnt = -1
        self.done_cnt = -1
        self.max_buf = -1
        self.pre_prcess = None
        self.im = None
        self.stt_q = None
        self.debug_cnt = 0
        self.im = im
        self.lm = lm

        self._init()

    def _init(self):
        '''Initialize tachy engine

        The initialization sequence is as follows
         1) Init properties
         2) Get configuration
         3) create logit mamanger, input manager object

        '''
        self.process_cnt = 0
        self.done_cnt = 0
        self.max_buf = self.config_static["GLOBAL"]["buf_num"]
        self.max_input = self.config_static["GLOBAL"]["max_input"]
        self.pre_process = self.config_static["GLOBAL"]["pre_process"]
        self.itf = self.config_static["INTERFACE"]["mode"]

        q_size = self.max_buf
        self.stt_q = Queue(maxsize=q_size)
        for i in range(q_size): self.stt_q.put(i)

    def _write(self, index, n_input, cmd, _length, data):
        '''Send request to tachy_rt

        Arguments
        ---------
        index   : buffer index
        n_input : num of inputs(only valid when process method is called)
        cmd     : command
        data    : data about command

        '''
        protocol = ApplicationProtocol(index=index,
                                       n_input=n_input,
                                       cmd=cmd,
                                       length=_length)
        self.fe.send(ctypes.sizeof(protocol), bytearray(protocol))
        if _length > 0: self.fe.send(_length, data.tobytes())

    def _read(self):
        ''' Receive data from interface layer

        Returns
        -------
        dict : dictionary
            dictionary have 5 information
            dict['index']   = index for current buffer(only valid when read reply of process method)
            dict['n_input'] = number of input(only valid when read reply of process method)
            dict['cmd']     = command for request
            dict['length']  = length for arguments
            dict['buf']     = arguments for reply

        '''
        ret = ApplicationProtocol()
        protocol_recv = self.be.receive(ctypes.sizeof(ApplicationProtocol))
        ctypes.memmove(ctypes.pointer(ret), protocol_recv, ctypes.sizeof(ApplicationProtocol))
        buf = np.zeros(ret.length, np.uint8)

        read_len = 0
        while read_len < ret.length:
            tmp = np.frombuffer(self.be.receive(ret.length - read_len), np.uint8)
            buf[read_len:read_len+tmp.nbytes] = tmp
            read_len += tmp.nbytes

        _dict = {
            'index': ret.index,
            'n_input': ret.n_input,
            'cmd': ret.cmd,
            'length': ret.length,
            'buf': buf
        }
        return _dict

    def _get_cur_idx(self):
        return self.process_cnt % self.max_buf

    def _set_input(self, inputs):
        '''Set input binary to current buffer

        Arguments
        ---------
        inputs :  Binary data about input, must be numpy type and must be 4 shape(B, H, W, D)

        TODO: receive result code
        '''
        index = self._get_cur_idx()

        # if n_input is bigger than max_input, return false
        if inputs.shape[0] > self.max_input:
            return False

        self.im.set_input(index, inputs)

    def process(self, data=None, n_input=1):
        ''' Send request to tachy_rt for inference

        Arguments
        ---------
        data    : numpy data to inference
            type must be numpy array(ex: if use CROP pre_process, you must send data in the following format
            [roi_x0, roi_y0, roi_x1, roi_y1, target_w, target_h, ratio_w*100, ratio_h*100] # ratio == roi / target
        n_input : num of input to inference

        '''
        self.stt_q.get()
        index = self._get_cur_idx()

        if n_input > self.max_input:
            logger.error("n_input({}) is bigger than max_input({})".format(n_input, self.max_input))
            exit(-1)

        if n_input == 0:
            cmd = CMD_APPLICATION_INFERENCE_DUMMY
            nbytes = 0
        else:
            cmd = CMD_APPLICATION_INFERENCE
            if self.pre_process == DICT_PRE_PROCESS["NONE_S"] or self.pre_process == DICT_PRE_PROCESS["NONE_M"]:
                if data is not None and len(data.shape) == 4:
                    self._set_input(data)
                    n_input = data.shape[0]
                nbytes = 0
            elif self.pre_process == DICT_PRE_PROCESS["CROP"]:
                assert(data is not None)
                n_input = data.shape[0]
                nbytes = data.nbytes
            else:
                print("unrecognized pre_process :", self.pre_process)
                exit(-1)

        self._write(index=index, n_input=n_input, cmd=cmd, _length=nbytes, data=data)
        self.process_cnt += 1

    # For batch -> width case(TODO: merge with process method)
    def _process_batch(self, total_batch, n_batch, data):
        total_batch = data.shape[0]
        cmd = CMD_APPLICATION_INFERENCE
        for i in range(math.ceil(total_batch / n_batch)):
            self.stt_q.get()
            index = self._get_cur_idx()

            d = data[i*n_batch:(i+1)*n_batch].transpose(2, 1, 0, 3) # (B,H,W,D -> W,H,B,D)

            if (d.shape[2] % n_batch) > 0:
                d_shape = d.shape
                dummy = np.zeros((d_shape[0], d_shape[1], n_batch, d_shape[3]), dtype=d.dtype)
                dummy[:,:,:d.shape[2],...] = d[:]
                d = dummy

            self._set_input(d)
            n_input = 1

            self._write(index=index, n_input=n_input, cmd=cmd, _length=0, data=d)
            self.process_cnt += 1

    # TODO: if NONE_S, NONE_M mode, _length of _write method must be 0 (sending input data is occuring in set_input method)
    def process_batch(self, data):
        batch = data.shape[0]
        n_batch = self.config_static["NETWORK"]["input_shape"][0][1]
        loop_cnt = math.ceil(batch / n_batch)

        th = Thread(target=self._process_batch, args=(batch, n_batch, data))
        th.start()

        logits = []
        for i in range(loop_cnt):
            _dict = self._read()
            logits.append(self.lm.get_logit(_dict))
            self.stt_q.put(_dict['index'])
            self.done_cnt += 1
        th.join()

        out_d = self.config_runtime["cfg_mem"]["mem_logit_output_shape"][-1][-1]
        valid = loop_cnt * n_batch
        if (batch % n_batch) > 0:
            valid -= (n_batch - (batch % n_batch))
        return np.array(logits, np.float16).reshape(-1, out_d)[:valid, ...]

        ''' Send request to tachy_rt for inference

        Arguments
        ---------
        data    : numpy data to inference
            type must be numpy array(ex: if use CROP pre_process, you must send data in the following format
            [roi_x0, roi_y0, roi_x1, roi_y1, target_w, target_h, ratio_w*100, ratio_h*100] # ratio == roi / target
        n_input : num of input to inference

        '''

    def get_result(self):
        '''Get inference done signal from tachy_rt and read logit from logit manager

        On local environment, uses shared memory for performance

        Returns
        -------
        dict : Dictionary
            same as the return value of the self._read method

        '''
        _dict = self._read()
        _dict['buf'] = self.lm.get_logit(_dict)

        self.stt_q.put(_dict['index'])
        self.done_cnt += 1
        return _dict
