import os
import mmap
import numpy as np

class Mapper:
    def __init__(self, cfg, dtype, fd_name='/dev/blackswan'):
        self.fd_name = fd_name
        self.dtype = dtype
        self.base = cfg["base"]
        self.size = cfg["offset"]
        self.n_buf  = cfg["num"]
        self.fd = self._get_fd()
        self.arrs = self._mapping()

    def _get_fd(self):
        return os.open(self.fd_name, os.O_RDWR | os.O_SYNC)

    def __del__(self):
        os.close(self.fd)

    def _mapping(self):
        arrs = []
        if self.size <= 0: return arrs
        for i in range(self.n_buf):
            mm = mmap.mmap(
                self.fd, self.size, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE, offset=self.base + (self.size * i)
            )
            # arr = np.ndarray(self.size >> 1, self.dtype, buffer=mm)
            arr = np.ndarray(self.size >> 1, np.float16, buffer=mm)
            arrs.append(arr)

        return arrs

    def get(self, index, size):
        return self.arrs[index][:size]

