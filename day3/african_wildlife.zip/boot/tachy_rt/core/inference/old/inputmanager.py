import os
import mmap
import time
import ctypes
import numpy as np
from turbojpeg import TurboJPEG, TJPF_RGB, TJPF_BGR, TJFLAG_PROGRESSIVE, TJFLAG_FASTUPSAMPLE, TJFLAG_FASTDCT

from tachy_rt.core.inference.mapper import Mapper
from tachy_rt.utils.constants import *
from tachy_rt.utils.app_class import ApplicationProtocol

class input_manager:
    def __init__(self, args):
        self.itf       = args[0]
        self.mem_input = args[1]
        self.dtype     = args[2]
        self.max_input = args[3]
        self.fe        = args[4] # tcp frontend
        self.spi_type  = args[5] # ftdi type
        self.input_fmt = args[6]
        self.jpeg = TurboJPEG()

        if self.itf == INTERFACE_PIPE:
            self.input =  Mapper(self.mem_input[0], self.dtype)
            self.set_input = self.set_input_local

        elif self.itf == INTERFACE_SPI:
            self.base = self.mem_input[0]["base"]
            self.offset = self.mem_input[0]["offset"]
            self.set_input = self.set_input_spi
            if self.spi_type == 'host':
                from tachy_rt.utils.spi_bs_host import spi
                self.spi = spi
            elif self.spi_type == 'ftdi':
                # from tachy_rt.utils import tachy_api
                # self.spi = tachy_api.spi
                from tachy_rt.utils import spi_bs_ftdi
                self.spi = spi_bs_ftdi.spi
        elif self.itf == INTERFACE_TCP:
            self.set_input = self.set_input_itf
        else:
            print("ERR, INPUTMANAGER")
            exit(-1)

        if self.input_fmt == INPUT_FMT_BINARY:
            self.cvt_input = self.cvt_inputs_binary
        elif self.input_fmt == INPUT_FMT_SENSOR:
            self.cvt_input = None
        elif self.input_fmt == INPUT_FMT_JPEG:
            self.cvt_input = self.cvt_inputs_jpeg

    def set_input_spi(self, index, inputs):
        inputs = self.cvt_input(inputs)
        self._write(index=index, n_input=inputs.shape[0], cmd=CMD_APPLICATION_SET_INPUT, _length=inputs.nbytes, data=inputs)

        # batch, h, d, w = inputs.shape
        # for i, _input in zip(range(batch), inputs):
        #     write_addr = self.base + (self.offset * (index * self.max_input + i))
        #     self.spi.spi_write(write_addr, _input)
        #     self._write(index=index, n_input=inputs.shape[0], cmd=CMD_APPLICATION_SET_INPUT, _length=0, data=None)

    def set_input_local(self, index, inputs):
        inputs = self.cvt_input(inputs)
        batch, h, d, w = inputs.shape
        for i, _input in zip(range(batch), inputs):
            self.input.arrs[(index * self.max_input) + i][:h*w*d] = inputs[i, :].reshape(-1)

    def set_input_itf(self, index, inputs):
        inputs = self.cvt_input(inputs)
        self._write(index=index, n_input=inputs.shape[0], cmd=CMD_APPLICATION_SET_INPUT, _length=inputs.nbytes, data=inputs)

    def cvt_inputs_binary(self, inputs):
        if self.dtype == DTYPE_FLOAT16 : inputs = inputs.transpose(0, 1, 3, 2).astype(np.float16).byteswap() # (b, h, d, w)
        elif self.dtype == DTYPE_UINT8 : inputs = inputs.transpose(0, 1, 3, 2) # (b, h, d, w)
        else:
            print("error dtype :". self.dtype)
            exit()

        return inputs

    def cvt_inputs_jpeg(self, inputs):
        enc_img = self.jpeg.encode(inputs[0], pixel_format=TJPF_BGR, quality=80) # img(rgb), format(bgr)
        enc_img = np.frombuffer(enc_img, np.uint8)
        enc_img = np.concatenate([np.array([enc_img.size], np.uint32).view(np.uint8), enc_img]).reshape(1,1,1,enc_img.size+4) # [b, h, d, w]

        return enc_img

    def _write(self, index, n_input, cmd, _length, data):
        '''Send request to tachy_rt

        Arguments
        ---------
        index   : buffer index
        n_input : num of inputs(only valid when process method is called)
        cmd     : command
        data    : data about command

        '''
        protocol = ApplicationProtocol(index=index,
                                       n_input=n_input,
                                       cmd=cmd,
                                       length=_length)
        self.fe.send(ctypes.sizeof(protocol), bytearray(protocol))
        if _length > 0:
            self.fe.send(_length, data.tobytes())
