import copy
import numpy as np
from easydict import EasyDict
from tachy_rt.core.sender import *
from tachy_rt.core.inference.config_functions import *
from tachy_rt.core.inference.inputmanager import input_manager
from tachy_rt.core.inference.logitmanager import logit_manager
from tachy_rt.core.inference.tachy_engine import tachy_engine
from tachy_rt.core.inference.config_manager import config_manager
from tachy_rt.utils.logger import *
from tachy_rt.utils.constants import *
from tachy_rt.utils.app_class import *
from tachy_rt.utils.functions_global import *
from tachy_rt.utils.tachyrt_model import tachyrt_model
from tachy_rt.interface.interface_spi import SPI as itf_spi
from tachy_rt.interface.interface_tcp_c import TCP as itf_tcp_c
from tachy_rt.interface.interface_pipe import PIPE as itf_pipe

req_inf = {}
req_inf["channel"] = {}
req_inf["function"] = "inference"
req_inf["parameter"] = {}

def _make_engine(config):
    ''' load deep learning model '''
    model = load_model(config)
    config = copy_model(config, model)

    ''' set configuration '''
    config = set_default_config(config, model) # (config, idb)
    config = update_legacy_config(config)

    ''' verify configuration '''
    verify_config(config)

    ''' create interface object '''
    fe = create_interface_obj(config["FRONTEND"])
    be = create_interface_obj(config["BACKEND"])

    ''' create request json '''
    request_json, itf = make_request_json(config)

    ''' send request json '''
    code, status, reply = send(request_json, itf)

    ''' allocate tachy engine '''
    if status:
        cfg_m = config_manager(config, reply["parameter"]["cfg_mem"])
        im = create_input_manager(cfg_m, fe)
        lm = create_logit_manager(cfg_m, reply["parameter"], config, model.output_shape, be)
        engine = alloc_tachy_engine(reply, config, model, fe, be, im, lm)
    else:
        engine = None

    return code, engine

def load_model(config):
    logger.info("load tachyrt model")

    path = config["NETWORK"]["network_path"]
    logger.debug("path for model : {}".format(path))

    loader = tachyrt_model()
    model = loader.load_model(path)
    if model is None:
        raise ValueError("Cannot load model...")

    return model

def copy_model(config, model):
    logger.info("copy tachyrt model")
    input_shape = model.input_shape if type(model.input_shape[0]) == list else [model.input_shape]
    config["NETWORK"]["input_shape"] = input_shape
    config["NETWORK"]["instruction"] = base64_encode(model.instruction.tobytes()).decode() # do not have endcode
    config["NETWORK"]["parameter"] = base64_encode(model.parameter_rgb.tobytes()).decode()
    config["NETWORK"]["layer"] = model.descriptor

    return config

def set_default_config(config, model):
    '''Set default values for configs that are missing from the config passed in when calling the init function'''
    logger.info("set default config")

    set_interface_config(config, "FRONTEND")
    set_interface_config(config, "BACKEND")
    set_global_config(config)
    set_network_config(config)
    # set_sensor_config(config, model)
    set_input_config(config, model)
    set_output_config(config)

    return config

def update_legacy_config(config):
    logger.info("update legacy config")

    config = update_legacy_global_config(config)
    config = update_legacy_sensor_config(config)
    config = update_legacy_network_config(config)

    return config

def verify_config(config):
    logger.info("verify config")

def create_interface_obj(config):
    logger.info("create frontend object")

    if config["mode"] == INTERFACE_PIPE:
        return itf_pipe(config)
    elif config["mode"] == INTERFACE_TCP:
        return itf_tcp_c(config)
    elif config["mode"] == INTERFACE_SPI:
        return itf_spi(config)

def make_request_json(config):
    logger.info("create request json")

    itf_mode = config["INTERFACE"]["mode"]
    if itf_mode == "ethernet": itf = "{}:{}".format(itf_mode, config["INTERFACE"]["ip"])
    elif "ethernet" in itf_mode or "tcp" in itf_mode: itf = itf_mode
    else:                      itf = itf_mode

    request_json = copy.deepcopy(req_inf)
    request_json["sub_function"] = "build_model"

    if "ethernet" in itf or "tcp" in itf:
        request_json["channel"]["type"] = INTERFACE_TCP
        request_json["channel"]["ip"] = itf.split(':')[1]
        request_json["channel"]["port"] = 40000
    elif "spi" in itf:
        request_json["channel"] = {}
        request_json["channel"]["type"] = INTERFACE_SPI
        request_json["channel"]["mode"] = itf.split(':')[1]
    elif "local" in itf:
        request_json["channel"] = {}
        request_json["channel"]["type"] = INTERFACE_PIPE

    request_json["parameter"] = config

    return np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8), itf

def create_input_manager(cfg_m, fe):
    args = [cfg_m.get_interface_code(),
            cfg_m.get_mem_input(),
            cfg_m.get_global_dtype(),
            cfg_m.get_global_max_input(),
            fe,
            cfg_m.get_spi_type(),
            cfg_m.get_input_format()
            ]
    return input_manager(args)

def create_logit_manager(cfg_m, config_runtime, config_static, output_shape, be):
    itf = config_static["INTERFACE"]["mode"]
    if "local" in itf:
        logit_size = config_runtime['cfg_mem']['mem_output'][0]['valid_size']
        args = [config_static["GLOBAL"]["name"], logit_size, config_static["GLOBAL"]["buf_num"], config_static["GLOBAL"]["max_input"]]
    elif "spi" in itf:
        args = [config_runtime['cfg_mem']]
    else:
        args = [output_shape]
    return logit_manager(itf, args)

def alloc_tachy_engine(reply, config, model, fe, be, im, lm):
    logger.info("initialization success. create tachy engine...")
    fe.set_memory_config(reply["parameter"]["frontend"])
    be.set_memory_config(reply["parameter"]["backend"])

    engine = tachy_engine(fe, be, config, reply["parameter"], im, lm)
    logger.info("tachy engine creation success")

    return engine
