import random
from tachy_rt.utils.logger import *
from tachy_rt.utils.constants import *
from tachy_rt.utils.functions_global import *

def set_interface_config(config, target):
    index = 'INTERFACE'
    if index in config and "mode" in config[index]:
        if config[index]["mode"] == "local":
            config[target] = {
                "mode": INTERFACE_PIPE,
                "name": os.path.join('/tmp', get_random_string(10))
            }
            logger.debug("Interface({}), Mode(local) Name({})".format(target, config[target]["name"]))
        elif config[index]["mode"] == "ethernet":
            assert("ip" in config[index])
            config[target] = {
                "mode": INTERFACE_TCP,
                "ip": config[index]["ip"],
                "port": random.randrange(41000, 42000)
            }
            logger.debug("Interface({}), Mode(tcp) ip({}) port({})".format(target, config[target]["ip"], config[target]["port"]))
        elif "ethernet" in config[index]["mode"] or "tcp" in config[index]["mode"]:
            config[target] = {
                "mode": INTERFACE_TCP,
                "ip": config[index]["mode"].split(":")[-1],
                "port": random.randrange(41000, 42000)
            }
            logger.debug("Interface({}), Mode(tcp) ip({}) port({})".format(target, config[target]["ip"], config[target]["port"]))
        elif "spi" in config[index]["mode"]:
            config[target] = {
                "type": config[index]["mode"].split(":")[-1],
                "mode": INTERFACE_SPI,
                "interval_read": 0,
                "interval_write": 0,
                "interval_tmout": 0
            }
            logger.debug("Interface({}), Mode(spi), it_r({}), it_w({}), it_tout({})".format(target,0,0,0))
        else:
            raise ValueError("Unsupported interface {}".format(config[index]))
    else:
        config[index] = {"mode": "local"}
        config[target] = {
            "mode": INTERFACE_PIPE,
            "name": os.path.join('/tmp', get_random_string(10))
        }
        logger.debug("Interface({}), Mode(local) Name({})".format(target, config[target]["name"]))

def set_global_config(config):
    '''Set default values for GLOBAL config'''
    index = 'GLOBAL'
    if "name"        not in config[index]: config[index]["name"] = get_random_string(19)
    if "data_type"   not in config[index]: config[index]["data_type"] = DTYPE_FLOAT16
    if "buf_num"     not in config[index]: config[index]["buf_num"] = 5
    if "npu_mask"    not in config[index]: config[index]["npu_mask"] = -1
    if "max_input"   not in config[index]: config[index]["max_input"] = 1
    if "pre_process" not in config[index]: config[index]["pre_process"] = PRE_NONE_S
    if "std"         not in config[index]: config[index]["std"] = 1.0
    if "mean"        not in config[index]: config[index]["mean"] = 0.0
    if "input_dump"  not in config[index]: config[index]["input_dump"] = False
    if "init"        not in config[index]: config[index]["init"] = True

    if config[index]["input_dump"]:
        logger.info("input_dump option has bug... disable input_dump option")
        config[index]["input_dump"] = False

    logger.debug("global config: name : {}".format(config[index]["name"]))
    logger.debug("global config: data_type : {}".format(config[index]["data_type"]))
    logger.debug("global config: buf_num : {}".format(config[index]["buf_num"]))
    logger.debug("global config: npu_mask : {}".format(config[index]["npu_mask"]))
    logger.debug("global config: max_input : {}".format(config[index]["max_input"]))
    logger.debug("global config: pre_process : {}".format(config[index]["pre_process"]))
    logger.debug("global config: std : {}".format(config[index]["std"]))
    logger.debug("global config: mean : {}".format(config[index]["mean"]))
    logger.debug("global config: input_dump : {}".format(config[index]["input_dump"]))
    logger.debug("global config: init : {}".format(config[index]["init"]))

def set_network_config(config):
    '''Set default values for NETWORK config'''

    index = 'NETWORK'
    if "network_path" not in config[index]: config[index]["network_path"] = "./"

    logger.debug("network config: network_path : {}".format(config[index]["network_path"]))

def set_sensor_config(config, model):
    index = 'SENSOR'
    if index not in config: config[index] = {}
    if "tx"                 not in config[index]: config[index]["tx"] = -1
    if "base"               not in config[index]: config[index]["base"] = "-1"
    if "crop_shape"         not in config[index]: config[index]["crop_shape"] = hwd_2_xywh([1080,1920,3])[0].tolist()
    if "ratio"              not in config[index]: config[index]["ratio"] = 1
    if "inverse_data"       not in config[index]: config[index]["inverse_data"] = True
    if "inverse_sync"       not in config[index]: config[index]["inverse_sync"] = False
    if "inverse_clock"      not in config[index]: config[index]["inverse_clock"] = False
    if "fmt"                not in config[index]: config[index]["fmt"] = SENSOR_FMT_BT1120
    if "data_type"          not in config[index]: config[index]["data_type"] = DTYPE_FLOAT16
    if "rolling_buf"        not in config[index]: config[index]["rolling_buf"] = False
    if "rolling_buf_num"    not in config[index]: config[index]["rolling_buf_num"] = 0
    if "rolling_buf_rule"   not in config[index]: config[index]["rolling_buf_rule"] = 0

def set_input_config(config, model):
    index = 'INPUT'
    if index not in config:
        config["INPUT"] = {
            "0": {
                "method": "binary",
                "tx": 0
            }
        }

    n_input = len(config["INPUT"])
    for i in range(n_input):
        cfg = config["INPUT"][str(i)]
        if cfg["method"] == "binary":
            cfg["method"]= INPUT_FMT_BINARY
        elif cfg["method"] == "sensor":
            cfg["method"] = INPUT_FMT_SENSOR
        elif cfg["method"] == "jpeg":
            cfg["method"] = INPUT_FMT_JPEG
        else:
            return False

def set_output_config(config):
    config["OUTPUT"] = {}
    mode = config["FRONTEND"]["mode"]

    if mode == INTERFACE_PIPE:
        config["OUTPUT"]["copy"]      = True
        config["OUTPUT"]["reorder"]   = True
    elif mode == INTERFACE_TCP:
        config["OUTPUT"]["copy"]      = False
        config["OUTPUT"]["reorder"]   = False
    elif mode == INTERFACE_SPI:
        config["OUTPUT"]["copy"]      = False
        config["OUTPUT"]["reorder"]   = False
    else:
        print("error set output config")
        exit(-1)

def update_legacy_global_config(config):
    dtype = config["GLOBAL"]["data_type"]
    if dtype == "float16":
        config["GLOBAL"]["data_type"] = DTYPE_FLOAT16
    elif dtype == "uint8_t":
        config["GLOBAL"]["data_type"] = DTYPE_UINT8
        
    pre_process = config["GLOBAL"]["pre_process"]
    if pre_process == "NONE_S":
        config["GLOBAL"]["pre_process"] = PRE_NONE_S
    elif pre_process == "NONE_M":
        config["GLOBAL"]["pre_process"] = PRE_NONE_M
    elif pre_process == "CROP":
        config["GLOBAL"]["pre_process"] = PRE_CROP

    return config

def update_legacy_sensor_config(config):
    return config
    # index_s = "SENSOR"
    # index_g = "GLOBAL"
    # tx = config[index_s]["tx"]
    # pre = config[index_g]["pre_process"]

    # if tx == -1: # if image mode
    #     config[index_s]["sensor_ratio_shape"] = config[index_s]["inst_input_shape"]
    # else: # if sensor mode
    #     h = config[index_s]["sensor_crop_shape"][3] - config[index_s]["sensor_crop_shape"][1] + 1
    #     w = config[index_s]["sensor_crop_shape"][2] - config[index_s]["sensor_crop_shape"][0] + 1
    #     ratio_h = int(h / config[index_s]["inst_input_shape"][0])
    #     ratio_w = int(w / config[index_s]["inst_input_shape"][1])
    #     ratio = min(ratio_h, ratio_w)

    #     sensor_h = int(h / ratio)
    #     sensor_w = int(w / ratio)
    #     sensor_d = config[index_s]["inst_input_shape"][2]

    #     config[index_s]["sensor_ratio_shape"] = [sensor_h, sensor_w, sensor_d]

    # config[index_s]["inst_crop_shape"] = hwd_2_xywh(config[index_s]["sensor_ratio_shape"])[0].tolist()

    # if (tx != -1) and (pre == PRE_CROP):
    #     config[index_s]["sensor_ratio_shape"]  = xywh_2_hwd(config[index_s]["sensor_crop_shape"])[0].tolist()

    # return config

def update_legacy_network_config(config):
    return config

