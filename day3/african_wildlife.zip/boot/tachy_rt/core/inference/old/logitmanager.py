import os
import mmap
import numpy as np
from tachy_rt.interface.interface_spi import SPI

class Shm:
    def __init__(self, name, size, flags=0):
        import posix_ipc
        self.name = name
        self.size = size
        self.mode = 0o666
        self.flags = flags
        self.arr = None
        self.shmem = None
        try:
            self.shmem = posix_ipc.SharedMemory(self.name, flags=self.flags, mode=self.mode, size=size)
            self.mm = mmap.mmap(self.shmem.fd, size)
            self.arr = np.ndarray((size), np.uint8, buffer=self.mm)
        except Exception as e:
            print("Shm except occur" + str(e))

    # delete operation will occurs in rt
    def __del__(self):
        os.close(self.shmem.fd)

    def read(self, size):
        return self.arr[:size]

#TODO: itf별 class를 나누기
class logit_manager:
    def __init__(self, itf, args):
        if 'local' in itf:
            self.shms = []
            self.name = args[0]
            self.size = args[1]
            self.n_buf = args[2]
            self.max_input = args[3]
            for i in range(self.n_buf):
                self.shms.append(Shm(name="{}_logit_{}".format(self.name, i), size=self.size*self.max_input*4, flags=0))
            self.get_logit = self.get_logit_shm
            
        elif 'spi' in itf:
            self.config_runtime = args[0]
            self.get_logit = self.get_logit_spi
            self.base = self.config_runtime["mem_output"][0]["base"]
            self.offset = self.config_runtime["mem_output"][0]["offset"]
            self.size = self.config_runtime["mem_output"][0]["valid_size"] * 2 # float16
            self.shapes = self.config_runtime["mem_logit_output_shape"]

            if 'host' in itf:
                from tachy_rt.utils.spi_bs_host import spi
                self.spi = spi
            if 'ftdi' in itf:
                # from tachy_rt.utils import tachy_api
                # self.spi = tachy_api.spi
                from tachy_rt.utils import spi_bs_ftdi
                self.spi = spi_bs_ftdi.spi
        else:
            self.logit_shape = args[0]
            self.shapes = self.logit_shape
            self.get_logit = self.get_logit_dummy

    def _transpose(self, logit, n_input):
        arr = []
        offset = 0

        for i in range(n_input):
            for shape in self.shapes:
                h, w, dummy_d, valid_d = shape
                arr.append(logit[offset : offset+h*w*dummy_d].byteswap().reshape(h, dummy_d, w)[:, :valid_d, :].transpose(0, 2, 1).reshape(-1))
                offset += h*w*dummy_d

        if len(arr) > 0: ret = np.concatenate(arr)
        else:            ret = np.empty((0), dtype=np.float32)
        return ret.astype(np.float32)

    def get_logit_spi(self, _dict):
        idx     = _dict['index']
        n_input = _dict['n_input']
        read_addr = self.base + (self.offset * idx)
        read_size = self.size * n_input
        ret = self._transpose(self.spi.spi_read(read_addr, read_size).view(np.float16), n_input).astype(np.float32)
        return ret

    def get_logit_shm(self, _dict):
        idx     = _dict['index']
        n_input = _dict['n_input']
        assert(n_input <= self.max_input)
        data = self.shms[idx].read(self.size * n_input * 4).view(np.float32)
        return data.copy()

    def get_logit_dummy(self, _dict):
        n_input = _dict['n_input']
        data = _dict['buf'].view(np.float16)# .astype(np.float32)

        ret = self._transpose(data, n_input).astype(np.float32)
        return ret
        # offset = 0
        # arr = []
        # for i in range(n_input):
        #     for shape in self.logit_shape:
        #         h, w, dummy_d, valid_d = shape
        #         arr.append(data[offset:offset + h*w*dummy_d].reshape(h,dummy_d,w)[:, :valid_d, :].transpose(0,2,1).reshape(h,w,valid_d).reshape(-1))
        #         offset += h * w * dummy_d

        # if len(arr) > 0: ret = np.concatenate(arr)
        # else:            ret = np.empty((0), dtype=np.float32)
        # return ret.astype(np.float32)
