import os, sys
import ctypes
import numpy as np
from tachy_rt.core.system.system_function       import _boot, _get_device_status, _pin_select, _save_model, _delete_model
from tachy_rt.core.debug.debug_function         import _get_model_info, _eval_throughput, _eval_latency, _dump_inference_time, _dump_layer, _dump_height_split_layer, _verify_height_split_timing
from tachy_rt.core.sensor.sensor_function       import _init_zeeahn, _dump_sensor, _enable_sensor
from tachy_rt.core.inference.inference_function import _make_instance, _make_standalone_instance, _connect_instance, _deinit_instance
from tachy_rt.utils.logger                      import *
from tachy_rt.utils.constants                   import *
from tachy_rt.utils.tachyrt_model               import tachyrt_model

global last_error_code
last_error_code = 0

################################################################
##################   Tachy-Runtime Util API   ##################
################################################################
def load_model(path:str):
    model = tachyrt_model()
    return model.load_model(path)

def get_sensor_ratio(h, w, org_h=1080, org_w=1920):
    ratio_w = -1
    ratio_h = -1
    for i in range(1, 7):
        if (org_w // i) >= w and (org_h // i) >= h:
            ratio_w = i
            ratio_h = i
    ratio = max(ratio_w, ratio_h)

    return ratio

def set_print_level(level):
    if   level == 'error': console_handler.setLevel(logging.ERROR)
    elif level == 'warn':  console_handler.setLevel(logging.WARNING)
    elif level == 'info':  console_handler.setLevel(logging.INFO)
    elif level == 'debug': console_handler.setLevel(logging.DEBUG)
    else:                  return False

    return True

def mem_write(address, binary, spi_type="ftdi"):
    def load_spi(spi_type):
        if spi_type == "ftdi":
            from tachy_rt.utils import spi_bs_ftdi
            spi = spi_bs_ftdi.spi
            return True, spi
        elif spi_type == "host":
            from tachy_rt.utils import spi_bs_host
            spi = spi_bs_host.spi
            return True, spi
        else:
            logger.error("spi type must be ftdi or host")
            return False, None

    is_suc, spi = load_spi(spi_type)
    spi.spi_write(address, binary)

def mem_read(address, size, spi_type="ftdi"):
    def load_spi(spi_type):
        if spi_type == "ftdi":
            # from tachy_rt.utils import tachy_api
            # spi = tachy_api.spi
            from tachy_rt.utils import spi_bs_ftdi
            spi = spi_bs_ftdi.spi
            return True, spi
        elif spi_type == "host":
            from tachy_rt.utils import spi_bs_host
            spi = spi_bs_host.spi
            return True, spi
        else:
            logger.error("spi type must be ftdi or host")
            return False, None

    is_suc, spi = load_spi(spi_type)
    return spi.spi_read(address, size)

def set_ftdi(chip_name, spi_ch=2, cs=0, freq=20E6, mode=3, interval=0.003):
    from tachy_rt.utils import spi_bs_ftdi
    spi = spi_bs_ftdi.spi

    return spi.initialize(chip_name, spi_ch, cs, freq, mode, interval)

def get_last_error_code():
    return last_error_code

################################################################
################### Tachy-Runtime Public API ###################
################################################################
'''
Tachy-Runtime Sytsem API
'''
def boot(spi_type:str, device_type:int, data:dict) -> bool: # Python
    """Upload a firmware to tachy device for host spi booting

    Arguments
    ---------
    spi_type(str)    : ftdi(ftdi api) or host(tachy host driver, ex:raspiberry pi)
    device_type(int) : DEV_TACHY_SHIELD or DEV_TACHY_LEPTON_TAU_M2

    Returns:
    --------
    True or False
    """
    return _boot(spi_type, device_type, data)

def get_device_status(itf:str) -> (bool, dict):
    """Get a information about device

    Arguments
    ---------
    itf(string) : Configuration for interface(local or ethernet:<ip> or spi:<type>)

    Returns:
    --------
    Dict
     - dict['parameter']['runtime_version'] : version of runtime
     - dict['parameter']['serial_number']   : serial number(TODO)
     - dict['parameter']['models']          : list of models(dict type)
        => model['name']                    : name of model
        => model['date']                    : uploaded date for model
        => model['type']                    : storage where model is saved
    """
    global last_error_code

    code, status, _dict = _get_device_status(itf)
    last_error_code = code

    return status, _dict

def save_model(itf:str, name:str, storage:int, model:str, overwrite:bool) -> bool:
    """Save tachyrt model to memory or nor

    Arguments
    ---------
    itf(string)     : Configuration for interface(local or ethernet:<ip> or spi:<type>)
    name(string)    : Name for model
    storage(int)    : Storage to save model(rt_core.MODEL_STORAGE_MEMORY or rt_core.MODEL_STORAGE_NOR)
    model(str)      : Path for model
    overwrite(bool) : true(overwrite an already saved model), false(returns failure if there is already a model saved with the same name)

    Returns:
    --------
    Bool
    True or False
    """
    global last_error_code

    assert(os.path.exists(model))

    code, status = _save_model(itf, name, storage, model, overwrite)
    last_error_code = code

    return status

def delete_model(itf:str, name:str) -> bool:
    """Delete tachyrt model from memory or nor

    Arguments
    ---------
    itf(string)     : Configuration for interface(local or ethernet:<ip> or spi:<type>)
    name(string)    : Name for model

    Returns:
    --------
    Bool
    True or False
    """
    global last_error_code

    code, status = _delete_model(itf, name)
    last_error_code = code
    return status

'''
Tachy-Runtime Debug API
'''
def get_model_info(path):
    """Get an information about tachyrt model

    Arguments
    ---------
    path(str) : path of tachy(rt) model

    Returns:
    --------
    Dict
    TODO
    """
    return _get_model_info(path)

def eval_throughput(itf:str, model:str, loop:int=100, hz:int=297, show:bool=True, dump:bool=False):
    """Do evaluate throughput for model

    Arguments
    ---------
    itf   (str)  : interface for tachy device
    model (str)  : path of tachy(rt) model
    loop  (int)  : looping count
    hz    (int)  : npu hz
    show  (bool) : print evaluation result for throughput
    dump  (bool) : dump evaluation result for throughput on current directory(./eval_throughput.csv)

    Returns:
    --------
    True or False
    """
    global last_error_code

    assert(os.path.exists(model))

    code, status = _eval_throughput(itf, model, loop, hz, show, dump)
    last_error_code = code
    return status

def eval_latency(itf:str, model:str, hz:int=297, show:bool=True, dump:bool=False):
    """Do evaluate latency for model

    Arguments
    ---------
    itf   (str)  : interface for tachy device
    model (str)  : path of tachy(rt) model
    show  (bool) : print evaluation result for performance
    dump  (bool) : dump evaluation result for performance on current directory(./eval_perf.csv)

    Returns:
    --------
    True or False
    """
    global last_error_code

    assert(os.path.exists(model))

    code, status = _eval_latency(itf, model, hz, show, dump)
    last_error_code = code
    return status

'''
Tachy-Runtime Sensor API
'''
def enable_sensor(itf:str,
                  tx:int,
                  ratio_w:int=1,
                  ratio_h:int=1,
                  crop:list=[0,0,1919,1079],
                  dtype:int=DTYPE_FLOAT16,
                  rgb:bool=True,
                  fmt:int=SENSOR_FMT_BT1120,
                  rolling_buf:bool=False,
                  rolling_buf_num:int=5,
                  rolling_buf_rule:int=ROLLING_BUF_MASTER,
                  inverse_data:bool=True,
                  inverse_sync:bool=False,
                  inverse_clock:bool=False,
                  reset:bool=False
                  ) -> bool:
    """Do enable sensor

    Arguments
    ---------
    itf              (str)  : interface for tachy device
    tx               (str)  : tx number for sensor interface(must be 0 ~ 3)
    ratio_w          (int)  : ratio for width(if 3, width will be crop_width / 3)
    ratio_h          (int)  : ratio for height(if 3, height will be crop_height / 3)
    crop             (list) : crop shape([x0,y0,x1,y1])
    dtype            (int)  : sensor data type(rt_core.DTYPE_UINT8 or rt_core.DTYPE_FLOAT16)
    rgb              (bool) : rgb or bgr(true=rgb, false=bgr)
    fmt              (int)  : format for sensor input(rt_core.SENSOR_FMT_BT1120 or rt_core.SENSOR_FMT_BT656 or rt_core.SENSOR_FMT_BAYER)
    rolling_buf      (bool) : rolling buf enable
    rolling_buf_num  (bool) : buffer of rolling buf(max 5)
    rolling_buf_rule (bool) : rolling buf rule(rt_core.ROLLING_BUF_MASTER or rt_core.ROLLING_BUF_SLAVE)
    inverse_data     (bool) : y <-> c inverse
    inverse_sync     (bool) : sensor sync inverse
    inverse_clock    (bool) : sensor clock inverse
    reset            (bool) : If the tx you want to use is already in use, disable and initialize it

    * ROLLING BUF has 2 meanings
       1. to prevent tearing of the video (perform inference only when the video is exhausted in memory)
       2. when 2 stage inference is required (ex: find an object in Scale Down video and perform separate inference on that object in FHD video)
        - In the second case, the model using the Scale Down video is the Master and the model using the FHD video is the Slave.

    Returns:
    --------
    True or False
    """
    global last_error_code

    code, status = _enable_sensor(itf,
                                  tx,
                                  ratio_w,
                                  ratio_h,
                                  crop,
                                  dtype,
                                  rgb,
                                  fmt,
                                  rolling_buf,
                                  rolling_buf_num,
                                  rolling_buf_rule,
                                  inverse_data,
                                  inverse_sync,
                                  inverse_clock,
                                  reset)

    last_error_code = code
    return status

def dump_sensor(itf:str,
                tx:int,
                ratio_w:int=1,
                ratio_h:int=1,
                crop:list=[0,0,1919,1079],
                dtype:int=DTYPE_FLOAT16,
                rgb:bool=True,
                fmt:int=SENSOR_FMT_BT1120,
                rolling_buf:bool=False,
                rolling_buf_num:int=5,
                rolling_buf_rule:int=ROLLING_BUF_MASTER,
                inverse_data:bool=True,
                inverse_sync:bool=False,
                inverse_clock:bool=False,
                reset:bool=False
                ) -> (bool, np.ndarray):
    """Do enable sensor

    Arguments
    ---------
    itf              (str)  : interface for tachy device
    tx               (str)  : tx number for sensor interface(must be 0 ~ 3)
    ratio_w          (int)  : ratio for width(if 3, width will be crop_width / 3)
    ratio_h          (int)  : ratio for height(if 3, height will be crop_height / 3)
    crop             (list) : crop shape([x0,y0,x1,y1])
    dtype            (int)  : sensor data type(rt_core.DTYPE_UINT8 or rt_core.DTYPE_FLOAT16)
    rgb              (bool) : rgb or bgr(true=rgb, false=bgr)
    fmt              (int)  : format for sensor input(rt_core.SENSOR_FMT_BT1120 or rt_core.SENSOR_FMT_BT656 or rt_core.SENSOR_FMT_BAYER)
    rolling_buf      (bool) : rolling buf enable
    rolling_buf_num  (bool) : buffer of rolling buf(max 5)
    rolling_buf_rule (bool) : rolling buf rule(rt_core.ROLLING_BUF_MASTER or rt_core.ROLLING_BUF_SLAVE)
    inverse_data     (bool) : y <-> c inverse
    inverse_sync     (bool) : sensor sync inverse
    inverse_clock    (bool) : sensor clock inverse
    reset            (bool) : If the tx you want to use is already in use, disable and initialize it

    * ROLLING BUF has 2 meanings
       1. to prevent tearing of the video (perform inference only when the video is exhausted in memory)
       2. when 2 stage inference is required (ex: find an object in Scale Down video and perform separate inference on that object in FHD video)
        - In the second case, the model using the Scale Down video is the Master and the model using the FHD video is the Slave.

    Returns:
    --------
    numpy image array
    """
    global last_error_code

    code, status, image = _dump_sensor(itf,
                                       tx,
                                       ratio_w,
                                       ratio_h,
                                       crop,
                                       dtype,
                                       rgb,
                                       fmt,
                                       rolling_buf,
                                       rolling_buf_num,
                                       rolling_buf_rule,
                                       inverse_data,
                                       inverse_sync,
                                       inverse_clock,
                                       reset)

    last_error_code = code
    return status, image

'''
Tachy-Runtime Inference API
'''
def make_instance(itf:str, model:str, instance:str, algorithm:str, config:dict) -> bool:
    """Creates a new instance

    Arguments
    ---------
    itf   (str)    : interface for tachy device
    model (str)    : name for model
    instance(str)  : name for instance
    algorithm(str) : must be "frame_spliter"
    config(dict)   : configuration for instance
        config = \
        {
            "global": {
                "name": str(internal model name, don't care)
                "data_type": inference data type(rt_core.DTYPE_FLOAT16 or rt_core.DTYPE_UINT8),
                "buf_num": num of buffer (max=5, ideal=5)
                "max_batch": num of match(recommand=1)
                "npu_mask": masking for npu(recommand=-1, it means use all npu, if 0x3, use npu0,1)
            },
            "input": [ // model input configuration
                {
                    "method": rt_core.INPUT_FMT_BINARY, // model'sfirst input is binary(do not use sensor)
                    "std": std value(it depends on model)
                    "mean": mean value(it depends on model)
                }
            ],
            "output": {
                "reorder": True or False(recommand=True)
            }
        }


    Returns:
    True or False
    """
    global last_error_code

    code, status = _make_instance(itf, model, instance, algorithm, config)
    last_error_code = code
    return status

def make_standalone_instance(itf:str,
                             model:str,
                             instance:str,
                             algorithm:str,
                             config:dict,
                             spi_type:str="host",
                             poll_interval:float=0.005):
    """Create and immediately start a sensor-driven standalone inference instance.

    Result payloads are read directly from physical memory through SPI.  The
    runtime control protocol is only used to create and deinitialize the
    instance; connect_instance(), process(), and get_result() are not used.

    Sensor input must use max_batch=1. rolling_buf=true keeps the hardware
    limit of five buffers; rolling_buf=false supports buf_num=2 through 10
    (default 5), subject to the model's instruction and global-memory use.

    output.post_process.type="yolov9" enables device-side decoding and forces
    the effective logit reorder setting to true. output.publish selects
    "raw", "annotation", or "both"; YOLOv9 defaults to "annotation".

    Returns:
        (True, StandaloneReader) on success, otherwise (False, None).
    """
    global last_error_code

    code, status, reader = _make_standalone_instance(itf,
                                                      model,
                                                      instance,
                                                      algorithm,
                                                      config,
                                                      spi_type,
                                                      poll_interval)
    last_error_code = code
    return status, reader

def connect_instance(itf:str, instance:str) -> (bool, ):
    """Connects with instance

    Arguments
    ---------
    itf   (str)    : interface for tachy device
    instance(str)  : name for instance

    Returns:
    (True or False, if true, instance, if false, None)
    """
    global last_error_code

    code, status, instance = _connect_instance(itf, instance)
    last_error_code = code
    return status, instance

def deinit_instance(itf:str, instance:str) -> bool:
    """Deinit instance

    Arguments
    ---------
    itf   (str)    : interface for tachy device
    instance(str)  : name for instance

    Returns:
    True or False
    """
    global last_error_code

    code, status = _deinit_instance(itf, instance)
    last_error_code = code
    return status



#################################################################
################### Tachy-Runtime Private API ###################
#################################################################
'''
Tachy-Runtime Sytsem API
'''
def pin_select(itf:str, pin_name:int) -> bool:
    global last_error_code

    code, status = _pin_select(itf, pin_name)
    last_error_code = code
    return status


'''
Tachy-Runtime Debug API
'''
def dump_layer(inst:np.ndarray,
               param:np.ndarray,
               input1_shape:list,
               input2_shape:list,
               input3_shape:list,
               output_shape:list,
               itf:str,
               input1:np.ndarray=None,
               input2:np.ndarray=None,
               input3:np.ndarray=None,
               input_offset:int=0
               ):
    """Dump a logit for requested inst and param and input

    Arguments
    ---------
    inst(numpy)         : instruction in numpy array
    param(numpy)        : parameter in numpy array
    input1_shape(list)  : shape for conv input
    input2_shape(list)  : shape for concat input
    input3_shape(list)  : shape for residual input
    output_shape(list)  : shape for output logit
    itf(str)            : interface for tachy_runtime
    input1(numpy)       : conv input binary
    input2(numpy)       : concat input binary
    input3(numpy)       : residual input binary

    Returns:
    --------
    Dict
    """
    global last_error_code

    code, status, output = _dump_layer(inst,
                                       param,
                                       input1_shape,
                                       input2_shape,
                                       input3_shape,
                                       output_shape,
                                       itf,
                                       input1,
                                       input2,
                                       input3,
                                       input_offset)
    last_error_code = code
    return output

def dump_inference_time(itf:str, inst:np.ndarray, param:np.ndarray, n_loop:int=500, npu_num:int=0):
    """Evaluate a time for requested inst and param and input

    Arguments
    ---------
    inst(numpy)         : instruction in numpy array
    param(numpy)        : parameter in numpy array
    itf(str)            : interface for tachy_runtime
    n_loop(int)         : 

    Returns:
    --------
    Dict
    """
    global last_error_code

    code, status, output = _dump_inference_time(itf,
                                                inst,
                                                param,
                                                n_loop,
                                                npu_num)
    last_error_code = code
    return output

def dump_height_split_layer(itf:str,
                            insts:np.ndarray,
                            param:np.ndarray,
                            _input:np.ndarray,
                            resi_input:np.ndarray,
                            output_addr:int=-1,
                            output_size:int=-1):
    """Evaluate a time for requested inst and param and input

    Arguments
    ---------
    inst(numpy)         : instruction in numpy array
    param(numpy)        : parameter in numpy array
    itf(str)            : interface for tachy_runtime
    n_loop(int)         : 

    Returns:
    --------
    Dict
    """
    global last_error_code

    code, status, output = _dump_height_split_layer(itf,
                                                    insts,
                                                    param,
                                                    _input,
                                                    resi_input,
                                                    output_addr,
                                                    output_size)

    last_error_code = code
    return output

def verify_height_split_timing(itf:str,
                               insts:np.ndarray,
                               param:np.ndarray,
                               input_addr:int,
                               input_shape:list,
                               output_addr:int,
                               output_shape:list,
                               dump:bool=False):
    """Evaluate a time for requested inst and param and input

    Arguments
    ---------
    inst(numpy)         : instruction in numpy array
    param(numpy)        : parameter in numpy array
    itf(str)            : interface for tachy_runtime

    Returns:
    --------
    Dict
    """
    global last_error_code

    code, status, valid, diff_h, out_1, out_2 = _verify_height_split_timing(itf,
                                                                            insts,
                                                                            param,
                                                                            input_addr,
                                                                            input_shape,
                                                                            output_addr,
                                                                            output_shape,
                                                                            dump)

    last_error_code = code

    return [valid, diff_h, out_1, out_2]


'''
Tachy-Runtime Sensor API
'''
def init_zeeahn(itf, i2c_num=0):
    global last_error_code

    code, status = _init_zeeahn(itf, i2c_num)
    last_error_code = code
    return status


'''
Tachy-Runtime Inference API
'''
...
