import os
import copy
import time
import numpy as np
import commentjson
from tachy_rt.core.sender import *
from tachy_rt.utils.logger import *
from tachy_rt.utils.constants import *
from tachy_rt.utils.tachyrt_model import tachyrt_model

req_sys  = {}
req_sys ["channel"] = {}
req_sys ["function"] = "system"
req_sys ["parameter"] = {}

def _boot(spi_type:str, device_type:int, data:dict):
    def load_spi(spi_type):
        if spi_type == "ftdi":
            from tachy_rt.utils import spi_bs_ftdi
            spi = spi_bs_ftdi.spi
            return True, spi
        elif spi_type == "host":
            from tachy_rt.utils import spi_bs_host
            spi = spi_bs_host.spi
            return True, spi
        else:
            logger.error("spi type must be ftdi or host")
            return False, None

    def upload_firmware(spi, device_type, upload):
        try:
            if device_type == DEV_TACHY_SHIELD:
                '''
                data = {
                    "spl": {
                        "path": path for spl.bin,
                        "addr": 0x0
                    }
                    "uboot": {
                        "path": path for u-boot.bin,
                        "addr": 0x2000_0000
                    }
                    "kernel": {
                        "path": path for image.ub,
                        "addr": 0x4000_0000
                    }
                    "fpga": {
                        "path": path for fpga_top.bin,
                        "addr": 0x3000_0000
                    }
                }
                '''
                info_spl    = data['spl']
                info_uboot  = data['uboot']
                info_kernel = data['kernel']
                info_fpga   = data['fpga']

                # 1. Reset Clock Speed
                spi.spi_write(0x0421B300, np.array([0x10, 0x10, 0x2, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x3], dtype=np.uint32))
                time.sleep(0.01)

                # 2. Disable boot done
                spi.dis_boot_done()
                time.sleep(0.01)

                # 3. Disable boot done
                spi.cpu_reset()
                time.sleep(0.1)

                # 4. Write spl
                logger.info("write spl")
                spi.spi_write(int(info_spl["addr"], 16), np.fromfile(info_spl["path"], np.uint8))
                spi.cpu_reset()

                # 5. Wait until ddr init is done
                cnt = 0
                while True:
                    cnt += 1
                    value = spi.spi_read(0x041160B0, 4).view(np.uint32)
                    if value == 1: break
                    if cnt > 50: return False
                    time.sleep(0.1)

                # 6. Write u-boot to dram
                logger.info("write uboot")
                spi.spi_write(int(info_uboot["addr"], 16), np.fromfile(info_uboot["path"], np.uint8))

                # 7. Write kernel to dram
                logger.info("write kernel")
                spi.spi_write(int(info_kernel["addr"], 16), np.fromfile(info_kernel["path"], np.uint8))

                # 8. Write fpga to dram
                logger.info("write fpga")
                spi.spi_write(int(info_fpga["addr"], 16), np.fromfile(info_fpga["path"], np.uint8))

                # 9. Write fpga to dram
                logger.info("write jump signal")
                spi.spi_write(0x041160B0, np.array([0x20000000], np.uint32))

                # 10. Reset runtime done register
                logger.info("reset runtime done value")
                spi.spi_write(0x041160C0, np.array([0x0], np.uint32))

            else:
                raise "Invalid device type"
            return True
        except Exception as e:
            logger.error(e)
            return False

    def wait_for_runtime(spi):
        logger.info("waiting until runtime init done..")
        cnt = 0
        while True:
            cnt += 1
            value = spi.spi_read(0x041160C0, 4).view(np.uint32)
            if value == 0xabcdee: break
            if cnt > 100: return False
            time.sleep(0.3)

        return True

    # Load SPI Class
    is_suc, spi = load_spi(spi_type)
    if not is_suc:
        logger.error(f"Invalid spi type : {spi_type}")
        return False

    # Upload firmware
    is_suc = upload_firmware(spi, device_type, data)
    if not is_suc:
        logger.error("Cannot upload firmware...")
        return False

    # Waiting for runtime init done...
    is_suc = wait_for_runtime(spi)
    if is_suc:
        logger.info("Success to boot. Check the status via uart or other api")
        return True
    else:
        logger.error("Runtime is not initialized... Connect uart and Check log")
        return False

def _get_device_status(itf:str):
    request_json = copy.deepcopy(req_sys)
    request_json["sub_function"] = "get_device_status"
    request_json["channel"] = set_interface(itf)

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, itf)

    return code, status, reply

def _pin_select(itf:str, pin_name):
    request_json = copy.deepcopy(req_sys)
    request_json["sub_function"] = "pin_select"
    request_json["channel"] = set_interface(itf)

    request_json["parameter"]["pin_name"] = pin_name

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, itf)

    return code, status

def _save_model(itf:str, name:str, storage:int, model:str, overwrite:bool):
    request_json = copy.deepcopy(req_sys)
    request_json["sub_function"] = "save_model"
    request_json["channel"] = set_interface(itf)

    rt_model = tachyrt_model()
    assert(rt_model.load_model(model))

    request_json["parameter"]["name"] = name
    request_json["parameter"]["storage"] = storage
    request_json["parameter"]["instruction"] = base64_encode(rt_model.instruction.tobytes()).decode()
    request_json["parameter"]["parameter"] = base64_encode(rt_model.parameter.tobytes()).decode()
    request_json["parameter"]["metadata"] = rt_model.descriptor
    request_json["parameter"]["overwrite"] = overwrite

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, itf)

    return code, status

def _delete_model(itf:str, name:str):
    request_json = copy.deepcopy(req_sys)
    request_json["sub_function"] = "delete_model"
    request_json["channel"] = set_interface(itf)

    request_json["parameter"]["name"] = name

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, itf)

    return code, status
