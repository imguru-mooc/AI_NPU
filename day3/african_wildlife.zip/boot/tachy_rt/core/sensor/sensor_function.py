import os
import copy
import time
import numpy as np
import commentjson
from tachy_rt.core.sender import *
from tachy_rt.utils.logger import *
from tachy_rt.utils.constants import *

req_sen  = {}
req_sen ["channel"] = {}
req_sen ["function"] = "sensor"
req_sen ["parameter"] = {}

def _enable_sensor(itf,
                   tx,
                   ratio_w,
                   ratio_h,
                   crop,
                   dtype,
                   rgb,
                   fmt,
                   rolling_buf,
                   rolling_buf_num,
                   rolling_buf_rule,
                   inverse_data,
                   inverse_sync,
                   inverse_clock,
                   reset):
    request_json = copy.deepcopy(req_sen)
    request_json["sub_function"] = "enable_sensor"
    request_json["channel"] = set_interface(itf)

    request_json["parameter"]["tx"] = tx
    request_json["parameter"]["crop"] = crop
    request_json["parameter"]["ratio_w"] = ratio_w 
    request_json["parameter"]["ratio_h"] = ratio_h 
    request_json["parameter"]["rolling_buf"] = rolling_buf
    request_json["parameter"]["rolling_buf_num"] = rolling_buf_num
    request_json["parameter"]["rolling_buf_rule"] = rolling_buf_rule
    request_json["parameter"]["rgb"] = rgb
    request_json["parameter"]["fmt"] = fmt
    request_json["parameter"]["dtype"] = dtype
    request_json["parameter"]["inverse_sync"] = inverse_sync
    request_json["parameter"]["inverse_data"] = inverse_data
    request_json["parameter"]["inverse_clock"] = inverse_clock
    request_json["parameter"]["reset"] = reset
    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, itf)

    return code, status

def _dump_sensor(itf,
                 tx,
                 ratio_w,
                 ratio_h,
                 crop,
                 dtype,
                 rgb,
                 fmt,
                 rolling_buf,
                 rolling_buf_num,
                 rolling_buf_rule,
                 inverse_data,
                 inverse_sync,
                 inverse_clock,
                 reset):
    request_json = copy.deepcopy(req_sen)
    request_json["sub_function"] = "dump_sensor"
    request_json["channel"] = set_interface(itf)

    request_json["parameter"]["tx"] = tx
    request_json["parameter"]["crop"] = crop
    request_json["parameter"]["ratio_w"] = ratio_w 
    request_json["parameter"]["ratio_h"] = ratio_h 
    request_json["parameter"]["rolling_buf"] = rolling_buf
    request_json["parameter"]["rolling_buf_num"] = rolling_buf_num
    request_json["parameter"]["rolling_buf_rule"] = rolling_buf_rule
    request_json["parameter"]["rgb"] = rgb
    request_json["parameter"]["fmt"] = fmt
    request_json["parameter"]["dtype"] = dtype
    request_json["parameter"]["inverse_sync"] = inverse_sync
    request_json["parameter"]["inverse_data"] = inverse_data
    request_json["parameter"]["inverse_clock"] = inverse_clock
    request_json["parameter"]["reset"] = reset

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, itf)

    if status:
        h = (crop[3] - crop[1] + 1) // ratio_h
        w = (crop[2] - crop[0] + 1) // ratio_w
        d = 3
        shape = [h,w,d]
        image = np.frombuffer(base64_decode(reply["parameter"]["image"]), np.uint8)
        image = image.view(np.float16 if dtype == DTYPE_FLOAT16 else np.uint8)
        image = image.reshape(shape[0], shape[2], shape[1]).transpose(0,2,1).byteswap().astype(np.uint8)
    else:
        image = np.empty(0)

    return code, status, image

def _init_zeeahn(itf, i2c_num):
    request_json = copy.deepcopy(req_sen)
    request_json["sub_function"] = "init_zeeahn"
    request_json["channel"] = set_interface(itf)

    request_json["parameter"]["i2c_num"] = i2c_num

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, itf)

    return code, status
