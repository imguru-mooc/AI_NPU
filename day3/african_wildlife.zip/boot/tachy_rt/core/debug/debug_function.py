import os
import copy
import time
import numpy as np
import commentjson
from tachy_rt.core.sender import *
from tachy_rt.utils.logger import *
from tachy_rt.utils.constants import *
from tachy_rt.utils.tachyrt_model import *
from tachy_rt.utils.functions_global import *

req_dbg  = {}
req_dbg ["channel"] = {}
req_dbg ["function"] = "debug"
req_dbg ["parameter"] = {}

def _get_model_info(path):
    rt_model = tachyrt_model()
    return rt_model.get_info(path)

def _eval_throughput(itf, model, loop, hz, show, dump):
    request_json = copy.deepcopy(req_dbg)
    request_json["sub_function"] = "eval_throughput"
    request_json["channel"] = set_interface(itf)

    # check hz
    if hz not in SUPPORT_NPU_HZ:
        logger.error(f"npu hz only supports ({SUPPORT_NPU_HZ})")
        exit()

    rt_model = tachyrt_model()
    rt_model.load_model(model)
    request_json["parameter"]["n_loop"] = loop
    request_json["parameter"]["npu_hz"] = hz
    request_json["parameter"]["instruction"] = base64_encode(rt_model.instruction).decode()
    request_json["parameter"]["parameter"]   = base64_encode(rt_model.parameter).decode()

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, itf)

    if status:
        absolute_times = reply["parameter"]["times"]
        inf_times = ['-']
        for i in range(0, loop-1):
            inf_times.append(absolute_times[i+1] - absolute_times[i])
        avg_time = (sum(inf_times[1:]) / len(inf_times[1:]))
        fps = 1000 / avg_time

        stream = "inf_cnt\tabsolute_time(ms)\tinf_time(ms)\n"
        for i, (ab_tm, inf_tm) in enumerate(zip(absolute_times, inf_times)):
            stream += "{}\t{}\t{}\n".format(i+1, ab_tm, inf_tm)

        stream += "Total Throughput(FPS) : {:.2f}\n".format(fps)
        stream += "Average Inference time : {:.2f}\n".format(avg_time)
        stream += "All information is based on {} MHz".format(hz)

        if show:
            print(stream)
        if dump:
            with open("eval_throughput.csv", "w") as f:
                f.write(stream)

    return code, status

def _eval_latency(itf, model, hz, show, dump):
    request_json = copy.deepcopy(req_dbg)
    request_json["sub_function"] = "eval_latency"
    request_json["channel"] = set_interface(itf)

    # check hz
    if hz not in SUPPORT_NPU_HZ:
        logger.error(f"npu hz only supports ({SUPPORT_NPU_HZ})")
        return -1, False

    try:
        rt_model = tachyrt_model()
        rt_model.load_model(model)
        
        request_json["parameter"] = {
            "npu_hz": hz,
            "instruction": base64_encode(rt_model.instruction).decode(),
            "parameter": base64_encode(rt_model.parameter).decode()
        }

        data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
        code, status, reply = send(data, itf)

        if not status:
            logger.error("Failed to get response from server")
            return code, status

        # Convert microseconds to milliseconds\
        total_time_ms = float(reply["parameter"]["times"][0]) / 1000.0
        
        stream = f"Total Inference Latency : {total_time_ms:.2f}\n"
        stream += f"All information is based on {hz} MHz"

        if show:
            print(stream)
        if dump:
            with open("eval_latency.csv", "w") as f:
                f.write(stream)

        return code, status

    except Exception as e:
        logger.error(f"Evaluation error: {str(e)}")
        return -1, False

'''
input1 : Conv input
input2 : Concat input
input3 : Residual input
'''
def _dump_layer(inst, param, input1_shape, input2_shape, input3_shape, output_shape, itf, input1, input2, input3, input_offset):
    request_json = copy.deepcopy(req_dbg)
    request_json["sub_function"] = "dump_layer"
    request_json["channel"] = set_interface(itf)

    request_json["parameter"]["instruction"]    = base64_encode(inst).decode()
    request_json["parameter"]["parameter"]      = base64_encode(param).decode()
    request_json["parameter"]["output_size"]    = int(np.prod(np.array([output_shape]))) * 2
    request_json["parameter"]["input_offset"]   = input_offset # for depth separate

    if input1 is not None:
        request_json["parameter"]["input1"]          = base64_encode(input1).decode()
        request_json["parameter"]["input1_size"]     = int(np.prod(np.array([input1_shape]))) * 2
    if input2 is not None:
        request_json["parameter"]["input2"]          = base64_encode(input2).decode()
        request_json["parameter"]["input2_size"]     = int(np.prod(np.array([input2_shape]))) * 2
    if input3 is not None:
        request_json["parameter"]["input3"]          = base64_encode(input3).decode()
        request_json["parameter"]["input3_size"]     = int(np.prod(np.array([input3_shape]))) * 2

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, itf)

    if status:
        output = np.frombuffer(base64_decode(reply["parameter"]["output"]), np.uint8)
    else:
        output = None

    return code, status, output

def _dump_inference_time(itf, inst, param, n_loop, npu_num):
    request_json = copy.deepcopy(req_dbg)
    request_json["sub_function"] = "dump_inference_time"
    request_json["channel"] = set_interface(itf)

    request_json["parameter"]["instruction"] = base64_encode(inst).decode()
    request_json["parameter"]["parameter"]   = param if param is None else base64_encode(param).decode()
    request_json["parameter"]["n_loop"]      = n_loop
    request_json["parameter"]["npu_num"]     = npu_num

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)
    code, status, reply = send(data, itf)

    if status:
        times = np.array(reply["parameter"]["times"])
    else:
        times = None

    return code, status, times

def _dump_height_split_layer(itf, insts, param, _input, resi_input, output_addr, output_size):
    request_json = copy.deepcopy(req_dbg)
    request_json["sub_function"] = "dump_height_split_layer"
    request_json["channel"] = set_interface(itf)

    request_json["parameter"]["instructions"] = []
    request_json["parameter"]["parameter"]    = param if param is None else base64_encode(param).decode()
    request_json["parameter"]["input"]        = _input if _input is None else base64_encode(_input).decode()
    request_json["parameter"]["resi_input"]   = resi_input if resi_input is None else base64_encode(resi_input).decode()
    request_json["parameter"]["output_addr"]  = output_addr
    request_json["parameter"]["output_size"]  = output_size

    for inst in insts:
        request_json["parameter"]["instructions"].append(base64_encode(inst).decode())

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)

    code, status, reply = send(data, itf)

    if status:
        output = np.frombuffer(base64_decode(reply["parameter"]["output"]), np.uint8)
    else:
        output = None

    return code, status, output

def _verify_height_split_timing(itf, insts, param, input_addr, input_shape, output_addr, output_shape, dump):
    request_json = copy.deepcopy(req_dbg)
    request_json["sub_function"] = "verify_height_split_timing"
    request_json["channel"] = set_interface(itf)

    request_json["parameter"]["instructions"] = []
    request_json["parameter"]["parameter"]    = param if param is None else base64_encode(param).decode()
    request_json["parameter"]["input_addr"]   = input_addr
    request_json["parameter"]["input_shape"]  = input_shape
    request_json["parameter"]["output_addr"]  = output_addr
    request_json["parameter"]["output_shape"] = output_shape
    request_json["parameter"]["dump"] = dump

    for inst in insts:
        request_json["parameter"]["instructions"].append(base64_encode(inst).decode())

    data = np.frombuffer(commentjson.dumps(request_json).encode(), np.uint8)

    code, status, reply = send(data, itf)

    if dump:
        output_1 = np.frombuffer(base64_decode(reply["parameter"]["output_1"]), np.uint8)
        output_2 = np.frombuffer(base64_decode(reply["parameter"]["output_2"]), np.uint8)
    else:
        output_1 = None
        output_2 = None

    return code, status, reply['parameter']['result'], reply['parameter']['diff_height'], output_1, output_2

def __get_mode(layer):
    map = {
        0: "conv",
        1: "fc",
        2: "reserved",
        3: "scaler",
        4: "max_pool",
        5: "concat",
        6: "tconv",
    }
    mode_int = (((layer[0] >> 16) & 0x1) << 2) | (layer[0] & 0x3)
    return map[mode_int]

def __get_stride(layer):
    stride = ((layer[2] >> 8) & 0x3)
    return stride

def __get_input_shape(layer):
    w = (layer[1] & 0x3FF)
    h = ((layer[1] >> 10) & 0x3FF)
    d = ((layer[1] >> 20) & 0xFFF)
    return [h,w,d]

def __get_output_shape(layer):
    input_shape = __get_input_shape(layer)

    out_w = 0
    out_h = 0
    out_d = 0

    '''
    1. conv + stride(1,1) = same
    2. conv + stride(2,2) = half
    '''
    mode = __get_mode(layer)
    stride = __get_stride(layer)

    if mode == "conv":
        if stride == 1:
            out_h = input_shape[0]
            out_w = input_shape[1]
        elif stride == 2:
            out_h = math.ceil(input_shape[0] / 2)
            out_w = math.ceil(input_shape[1] / 2)
    elif mode == "scaler":
        out_h = input_shape[0]
        out_w = input_shape[1]
    elif mode == "tconv":
        out_h = input_shape[0] * 2
        out_w = input_shape[0] * 2
    else:
        print("Error", mode)
        exit(-1)

    out_d = ((layer[3] >> 16) & 0x3FF)
    return [out_h,out_w,out_d]
