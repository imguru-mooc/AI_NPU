import os
import math
import time
import numpy as np
from tachy_rt.utils.constants import *


class SPI:
    def __init__(self, config):
        self.config = config

        if "ftdi" in self.config["type"]:
            from tachy_rt.utils import spi_bs_ftdi
            self.spi = spi_bs_ftdi.spi
        elif "host" in self.config["type"]:
            from tachy_rt.utils import spi_bs_host
            self.spi = spi_bs_host.spi
        else:
            print("error spi type", self.config)
            exit(-1)

        if "tmout" in self.config:
            self.tm_out = self.config["tmout"]
        else:
            self.tm_out = 0

    def set_memory_config(self, memory_info):
        self.mem_info = memory_info
        self.header_addr        = self.mem_info["header_addr"]        # = 0x00
        # self.header_signal      = self.mem_info["header_signal"]      # = 0x04
        # self.header_total_size  = self.mem_info["header_total_size"]  # = 0x08
        self.buffer_size = self.spi.spi_read(self.header_addr + 0x0C, 4).view(np.int32)[0] # 0x0C

    def send(self, length, buf):
        # 1. Until total size is available
        if not self._wait_until_total_size_available():
            return

        # 2. Write total size if available
        self._set_total_size(length)

        # 3. Wait until cnt is available
        if(not self._calc_cnt()):
            return

        # 6. do read loop
        for i in range(self.cnt):
            # 1. wait until header addr is available
            if not self._wait_until_addr_is_valid():
                return b''

            # 2. reset header(addr)
            self._reset_addr()

            # 3. write data to addr
            self._write_data(buf, i)

            # 4. write done signal
            self._write_done_signal()

    def receive(self, length):
        buf = []

        # 1. Wait until total size is valid
        if not self._wait_until_total_size_is_valid():
            return b''

        # 2. Reset total size as -1
        self._reset_total_size()

        # 3. Calculate cnt and set cnt
        if not self._calc_cnt():
            return b''

        for i in range(self.cnt):
            # 1. wait until value of header addr become -1
            if not self._wait_until_addr_is_valid():
                return b''

            # 2. reset addr
            self._reset_addr()

            # 2. read data from addr
            buf.append(self._read_data(i))

            # 3. set done signal
            self._set_signal()

        return np.concatenate(buf).tobytes()

    def _wait_until_total_size_available(self):
        while True:
            self.total_size = self.spi.spi_read(self.header_addr + 0x8, 4).view(np.int32)[0]
            if self.total_size == -1:
                return True

    '''
    Common Functions
    '''
    def _calc_cnt(self):
        self.cnt = math.ceil(self.total_size / self.buffer_size)
        if self.cnt <= 0:
            return False
        return True

    def _wait_until_addr_is_valid(self):
        while True:
            self.addr = self.spi.spi_read(self.header_addr, 4).view(np.int32)[0]
            if self.addr > 0:
                return True

    def _reset_addr(self):
        self.spi.spi_write(self.header_addr, np.array([-1], np.int32))

    '''
    Write Functions
    '''
    def _set_total_size(self, total_size):
        self.total_size = total_size
        self.spi.spi_write(self.header_addr + 0x8, np.array([total_size], np.int32))

    def _write_data(self, buf, idx):
        stt = 0
        end = 0
        max_size = self.buffer_size * (idx+1)

        if max_size > self.total_size: # Total size를 넘어가는 경우(마지막 Index)
            stt = self.buffer_size * idx
            end = self.total_size
        else:
            stt = self.buffer_size * idx
            end = self.buffer_size * (idx + 1)

        # 3. write data to addr
        self.spi.spi_write(self.addr, np.frombuffer(buf[stt:end], np.uint8))

    def _write_done_signal(self):
        # 4. write 1 to header(signal)
        self.spi.spi_read(self.header_addr, 4).view(np.int32)[0]
        self.spi.spi_write(self.header_addr + 4, np.array([1], np.int32))
        self.spi.spi_read(self.header_addr, 4).view(np.int32)[0]

    '''
    Receive Functions
    '''
    def _wait_until_total_size_is_valid(self):
        while True:
            self.total_size = self.spi.spi_read(self.header_addr + 8, 4).view(np.int32)[0]
            if self.total_size > 0:
                return True

    def _reset_total_size(self):
        self.spi.spi_write(self.header_addr + 8, np.array([-1], np.int32))

    def _read_data(self, idx):
        if self.cnt-1 > idx:
            return self.spi.spi_read(self.addr, self.buffer_size)
        else: # if last index
            return self.spi.spi_read(self.addr, self.buffer_size if self.total_size % self.buffer_size == 0 else self.total_size % self.buffer_size)

    def _set_signal(self):
        self.spi.spi_write(self.header_addr + 4, np.array([1], np.int32))
