import os

class PIPE:
    def __init__(self, config):
        self.name = config['name']
        self._create_pipe()

    def __del__(self):
        os.close(self.fd)

    def set_memory_config(self, memory_info):
        pass

    def receive(self, length):
        data = os.read(self.fd, length)
        return data

    def send(self, length, buf):
        os.write(self.fd, buf)

    def _create_pipe(self):
        os.mkfifo(self.name)

        self.fd = os.open(self.name, os.O_SYNC | os.O_CREAT | os.O_RDWR)
