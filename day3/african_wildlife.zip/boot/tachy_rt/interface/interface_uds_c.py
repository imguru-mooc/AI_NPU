import time
import socket
import threading

class UDS_C:
    def __init__(self, config):
        self.name = config["name"]
        self.init_thread = threading.Thread(target=self._create_socket)
        self.init_thread.start()

    def __del__(self):
        self.sock.close()
        self.init_thread.join()

    def set_memory_config(self, memory_info):
        pass

    def receive(self, length):
        ret = b''
        while len(ret) < length:
            packet = self.sock.recv(length - len(ret))
            if not packet:
                break
            ret += packet

        return ret
        # return self.sock.recv(length, socket.MSG_WAITALL)

    def send(self, length, buf):
        self.sock.send(buf)

    def _create_socket(self):
        time.sleep(1)
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        for i in range(600):
            try:
                self.sock.connect(self.name)
                return
            except Exception as e:
                time.sleep(0.1)
