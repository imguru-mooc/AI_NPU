import time
import socket
import threading

class TCP:
    def __init__(self, config):
        self.ip = config["ip"]
        self.port = config["port"]
        self.init_thread = threading.Thread(target=self._create_socket)
        self.init_thread.start()

    def set_memory_config(self, memory_info):
        pass

    def receive(self, length):
        ret = b''
        while len(ret) < length:
            packet = self.sock.recv(length - len(ret))
            if not packet:
                break
            ret += packet

        return ret

    def send(self, length, buf):
        self.sock.send(buf)

    def _create_socket(self):
        time.sleep(1)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        for i in range(600):
            try:
                self.sock.connect((self.ip, self.port))
                return
            except Exception as e:
                time.sleep(0.1)
