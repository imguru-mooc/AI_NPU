import json
import queue
import threading
import time
from pathlib import Path

import cv2
import numpy as np
import tachy_rt.core.functions as rt_core

from src.detection_utils import (
    create_tracker,
    detections_from_anno,
    print_detections,
    update_tracker,
)


class TachyModelRuntime:
    def __init__(
            self,
            model_path,
            post_process_config_path,
            interface="spi:host",
            model_name="object_detection_yolov9",
            tx=2,
            input_shape=None,
            instance_name=None,
            spi_type="host",
            poll_interval=0.0):
        self.interface = interface
        self.model_name = model_name
        self.model_path = str(model_path)
        self.post_process_config = self._load_post_process_config(
            post_process_config_path
        )
        self.tx = tx
        configured_input_shape = (
            self.post_process_config["SHAPES_INPUT"]
            if input_shape is None
            else input_shape
        )
        self.input_shape = tuple(configured_input_shape)
        self.instance_name = instance_name or model_name
        self.spi_type = spi_type
        self.poll_interval = poll_interval
        self.reader = None
        self.config = self._create_config()

    @staticmethod
    def _load_post_process_config(config_path):
        with open(config_path, "r", encoding="utf-8") as config_file:
            return json.load(config_file)

    def initialize(self):
        # Stop a previous run before changing sensor or model state.
        self.close()
        self._save_model()
        self._enable_sensor()
        self.reader = self._make_instance()
        return self.reader

    def close(self):
        rt_core.deinit_instance(self.interface, self.instance_name)
        self.reader = None

    def _create_config(self):
        return {
            "global": {
                "name": self.model_name,
                "data_type": rt_core.DTYPE_FLOAT16,
                "buf_num": 5,  # max: 5
                "max_batch": 1,
                "npu_mask": -1,
            },
            "input": [
                {
                    "method": rt_core.INPUT_FMT_SENSOR,
                    "std": 255.0,
                    "mean": 0.0,
                    "tx": self.tx,
                }
            ],
            "output": {
                # YOLOv9 post-processing forces the effective value to true.
                "reorder": True,
                "publish": "annotation",
                "post_process": {
                    "type": "yolov9",
                    "pre_threshold": self.post_process_config["PRE_THRESHOLD"],
                    "obj_threshold": self.post_process_config["OBJ_THRESHOLD"],
                    "nms_threshold": self.post_process_config["NMS_THRESHOLD"],
                    "n_max_obj": self.post_process_config["N_MAX_OBJ"],
                },
            },
        }

    def _save_model(self):
        if not rt_core.save_model(
                self.interface,
                self.model_name,
                rt_core.MODEL_STORAGE_MEMORY,
                self.model_path,
                overwrite=True):
            raise RuntimeError(
                "save_model failed: {}".format(
                    rt_core.get_last_error_code()
                )
            )

    def _enable_sensor(self):
        ratio = rt_core.get_sensor_ratio(
            self.input_shape[0],
            self.input_shape[1],
        )
        if not rt_core.enable_sensor(
                itf=self.interface,
                tx=self.config["input"][0]["tx"],
                ratio_w=ratio,
                ratio_h=ratio,
                rolling_buf=True,
                rolling_buf_num=self.config["global"]["buf_num"],
                rolling_buf_rule=rt_core.ROLLING_BUF_MASTER,
                reset=True,
                inverse_data=False,
                inverse_sync=False,
                inverse_clock=False):
            raise RuntimeError(
                "enable_sensor failed: {}".format(
                    rt_core.get_last_error_code()
                )
            )

    def _make_instance(self):
        status, reader = rt_core.make_standalone_instance(
            self.interface,
            self.model_name,
            self.instance_name,
            "frame_split",
            self.config,
            spi_type=self.spi_type,
            poll_interval=self.poll_interval,
        )
        if not status:
            raise RuntimeError(
                "make_standalone_instance failed: {}".format(
                    rt_core.get_last_error_code()
                )
            )
        return reader


class VideoPipeline:
    def __init__(
            self,
            reader,
            device="/dev/video0",
            width=1920,
            height=1080,
            window_name="Tachy YOLOv9 Standalone",
            display_width=None,
            display_height=None):
        self.reader = reader
        self.device = device
        self.width = width
        self.height = height
        self.window_name = window_name
        self.display_width = display_width or width // 3
        self.display_height = display_height or height // 3

        self.capture = None
        self.tracker = create_tracker()
        self.annotation_thread = None
        self.stop_event = threading.Event()
        self.detection_queue = queue.Queue(maxsize=1)
        self.error_queue = queue.Queue(maxsize=1)

    def run(self):
        self.capture = self._open_yuyv_capture()
        self.annotation_thread = threading.Thread(
            target=self._annotation_worker,
            name="standalone-annotation",
            daemon=True,
        )
        self.annotation_thread.start()
        self._camera_worker()

    def close(self):
        self.stop_event.set()
        if self.annotation_thread is not None:
            self.annotation_thread.join(timeout=1.0)
            self.annotation_thread = None
        if self.capture is not None:
            self.capture.release()
            self.capture = None
        cv2.destroyAllWindows()

    def _open_yuyv_capture(self):
        capture = cv2.VideoCapture(self.device, cv2.CAP_V4L2)
        if not capture.isOpened():
            raise RuntimeError("cannot open {} with V4L2".format(self.device))

        if not capture.set(
                cv2.CAP_PROP_FOURCC,
                cv2.VideoWriter_fourcc(*"YUYV")):
            capture.release()
            raise RuntimeError(
                "{} does not accept YUYV format".format(self.device)
            )

        capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
        capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        capture.set(cv2.CAP_PROP_CONVERT_RGB, 1)

        actual_fourcc = int(capture.get(cv2.CAP_PROP_FOURCC))
        actual_format = "".join(
            chr((actual_fourcc >> (8 * index)) & 0xFF) for index in range(4)
        )
        if actual_format not in ("YUYV", "YUY2"):
            capture.release()
            raise RuntimeError(
                "{} opened as {}, not YUYV".format(self.device, actual_format)
            )
        return capture

    @staticmethod
    def _to_bgr(frame, capture_width):
        if frame.ndim == 3 and frame.shape[2] == 3:
            return frame
        if frame.ndim == 3 and frame.shape[2] == 2:
            return cv2.cvtColor(frame, cv2.COLOR_YUV2BGR_YUY2)
        if frame.ndim == 2 and frame.shape[1] == capture_width * 2:
            yuyv = frame.reshape(frame.shape[0], capture_width, 2)
            return cv2.cvtColor(yuyv, cv2.COLOR_YUV2BGR_YUY2)
        if frame.ndim == 2:
            return cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
        raise RuntimeError(
            "unsupported camera frame shape: {}".format(frame.shape)
        )

    def _draw_detections(self, frame, detections):
        frame_height, frame_width = frame.shape[:2]
        scale_x = frame_width / float(self.width)
        scale_y = frame_height / float(self.height)

        for index, (x0, y0, x1, y1) in enumerate(detections.xyxy):
            score = (
                float(detections.confidence[index])
                if detections.confidence is not None
                else 0.0
            )
            class_id = (
                int(detections.class_id[index])
                if detections.class_id is not None
                else -1
            )
            tracker_id = (
                int(detections.tracker_id[index])
                if detections.tracker_id is not None
                else None
            )
            left = int(np.clip(round(x0 * scale_x), 0, frame_width - 1))
            top = int(np.clip(round(y0 * scale_y), 0, frame_height - 1))
            right = int(np.clip(round(x1 * scale_x), 0, frame_width - 1))
            bottom = int(np.clip(round(y1 * scale_y), 0, frame_height - 1))
            if right <= left or bottom <= top:
                continue

            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            label = "class={} score={:.3f}".format(class_id, score)
            if tracker_id is not None:
                label = "track=#{} {}".format(tracker_id, label)
            cv2.putText(
                frame,
                label,
                (left, max(top - 8, 20)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 255, 0),
                2,
                cv2.LINE_AA,
            )

    def _put_latest_detections(self, detections):
        try:
            self.detection_queue.get_nowait()
        except queue.Empty:
            pass
        self.detection_queue.put_nowait(detections)

    def _annotation_worker(self):
        try:
            while not self.stop_event.is_set():
                result = self.reader.wait_next(timeout=0.1)
                if result is None:
                    continue

                annotations = result["annotations"]
                if annotations is None:
                    raise RuntimeError(
                        "runtime did not publish YOLOv9 annotations"
                    )
                detections = detections_from_anno(annotations)
                detections = update_tracker(self.tracker, detections)
                self._put_latest_detections(detections)
                current_time = time.time()
                timestamp = time.strftime(
                    "%Y-%m-%d %H:%M:%S",
                    time.localtime(current_time),
                )
                timestamp = "{}.{:03d}".format(
                    timestamp,
                    int(current_time % 1 * 1000),
                )
                print(
                    "[INFO {}] Detections: {}".format(
                        timestamp,
                        len(detections),
                    )
                )
                print_detections(detections)
        except Exception as error:
            self.error_queue.put(error)
            self.stop_event.set()

    def _camera_worker(self):
        detections = detections_from_anno(
            np.empty((0, 6), dtype=np.float32)
        )
        capture_width = int(self.capture.get(cv2.CAP_PROP_FRAME_WIDTH))

        while True:
            try:
                worker_error = self.error_queue.get_nowait()
            except queue.Empty:
                worker_error = None
            if worker_error is not None:
                raise worker_error
            if self.stop_event.is_set():
                break

            success, camera_frame = self.capture.read()
            if not success:
                raise RuntimeError("failed to read {}".format(self.device))
            frame = self._to_bgr(camera_frame, capture_width)

            try:
                while True:
                    detections = self.detection_queue.get_nowait()
            except queue.Empty:
                pass

            self._draw_detections(frame, detections)
            display_frame = cv2.resize(
                frame,
                (self.display_width, self.display_height),
                interpolation=cv2.INTER_AREA,
            )
            cv2.imshow(self.window_name, display_frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord("q")):
                self.stop_event.set()
                break


def main():
    base_dir = Path(__file__).resolve().parent
    model_path = (
        base_dir
        / "params/face_detection_yolov9_xwn4/model_256x416x3_inv-t.tachyrt"
    )
    post_process_config_path = (
        base_dir
        / "configs/face_detection_yolov9/post_process_256x416.json"
    )
    model_runtime = TachyModelRuntime(
        model_path=model_path,
        post_process_config_path=post_process_config_path,
    )
    video_pipeline = None
    try:
        reader = model_runtime.initialize()
        video_pipeline = VideoPipeline(reader)
        video_pipeline.run()
    except KeyboardInterrupt:
        pass
    finally:
        if video_pipeline is not None:
            video_pipeline.close()
        model_runtime.close()


if __name__ == "__main__":
    main()
